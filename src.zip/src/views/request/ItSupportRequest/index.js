
import { cilArrowCircleLeft } from '@coreui/icons'
import CIcon from '@coreui/icons-react'
import { CContainer, CFormInput } from '@coreui/react'
import { Button } from '@mui/material'
import React, { useState } from 'react'
import CustomTable from 'src/custom/Table'
import { Card, Col, Label, Row, FormGroup } from 'reactstrap'
import "../FoodRequest/Styles.scss"
import CustomSelect from 'src/components/CustomSelect'
import {Box} from '@mui/material'

const ItRequest = (props) => {
    const {open,setOpen}=props;
    const toggle=()=>{
        setOpen(!open)
    }
    let data=[]
    const columns= [
      {
        Header: "SI No",
        id: "index",
        accessor: (row, index) => (
          <div style={{ textAlign: "center" }}>{index + 1}</div>
        ),
      },
      {
        Header: "Employee Name",
        accessor: "employeeName",
      },
      {
        Header: "Support Type",
        accessor: "Support Type",
      },
      {
        Header: "Issue Type",
        accessor: "Issue Type",
      },
      {
        Header: "Description",
        accessor: "Description", 
      },
      {
        Header: "Request to",
        accessor: "Request to",
      },
      {
        Header: "Status",
        accessor: "status",
        disableSortBy: true,
      },
      {
        Header: "Date",
        accessor: "Date",
      },

    ];
  return (
    <div
      style={{
        width: "100%",
        minHeight: "calc(100vh - 190px)",
        backgroundColor: "white",
        borderRadius: "20px",
        position:'absolute',
        top:0
        
      }}>
     {!open ? (
     <>
     <CContainer style={{ display: "contents" }}>
        <CIcon
             icon={cilArrowCircleLeft}
             size="xl"
             style={{
             marginTop: "1rem",
             marginLeft: "1rem",
            cursor: "pointer",
            }}
            onClick={toggle}
            />
            <h1
            style={{
            fontSize: "1.5rem",
            fontWeight: "500",
            marginLeft: "3.8rem",
            position: "absolute",
            top: "13px",
             }}
           >
            It Support
            </h1>
            <Button
            variant="contained"
            style={{
              marginRight: "1rem",
              float: "right",
              marginTop: "1.2rem",
            }}
             onClick={toggle}
            color={"primary"}
          >
            Request
          </Button>
            <Button
            variant="contained"
            style={{
              marginRight: "1rem",
              float: "right",
              marginTop: "1.2rem",
            }}
            // onClick={toggle}
            color={"primary"}
          >
             Create
          </Button>
          </CContainer>
            <CContainer fluid>
              <CustomTable columns={columns} data={data} />
            </CContainer>
            </>
          ) :(
           <div>
           <div
             style={{
               flexDirection: "row",
               position: "relative",
               display: "flex",
               borderRadius: "20px",
               marginLeft: "0.5rem",
               alignItems: "center",
             }}
           >
             <CContainer style={{ display: "contents" }}>
               <CIcon
                 icon={cilArrowCircleLeft}
                 size="xl"
                 style={{
                   marginTop: "1rem",
                   marginLeft: "1rem",
                   cursor: "pointer",
                 }}
                 onClick={toggle}
               />
               <h1
                 style={{
                   fontSize: "1.5rem",
                   fontWeight: "600",
                   marginLeft: "3.8rem",
                   position: "absolute",
                   top: "13px",
                   paddingRight: "0px",
                 }}
               >
                 Create Request
               </h1>
             </CContainer>
           </div>
           <div
             className="cusInpFullCon"
             style={{
               position: "relative",
               marginTop: "3rem",
               marginRight: "5rem",
             }}
           >
             <CContainer
               className="cusInpFullWrap"
               style={{ marginLeft: "3.2rem" }}
             >
               <Row>
                 <Col
                   md={6}
                   className="cusInpCon"
                   style={{ minWidth: "300px", maxWidth: "300px" }}
                 >
                   {" "}
                   <FormGroup>
                     <Label>
                       Select the Asset Type
                       <span
                         style={{
                           paddingLeft: "5px",
                           color: "red",
                           fontSize: "15px",
                         }}
                       >
                         *
                       </span>
                     </Label>
                     <CustomSelect
                       // styles={{ width: "18rem" }}
                      //  option={assetName}
                      //  selectedOptions={selected}
                      //  setSelectedOptions={setSelected}
                       isSearchable={true}
                       isMulti={false}
                       placeholder={"Select The Asset Type"}
                       style={{ marginButtom: "0.5rem" }}
                     />
                   </FormGroup>
                   {/* {depErr ? (
                   <Typography style={{ color: "red" }}>
                     {depErr}
                   </Typography>
                 ) : null} */}
                 </Col>
                 <Col
                   md={6}
                   className="cusInpCon"
                   style={{ minWidth: "300px", maxWidth: "300px" }}
                 >
                   <Label>
                     Reason
                     <span
                       style={{
                         paddingLeft: "5px",
                         color: "red",
                         fontSize: "15px",
                       }}
                     >
                       *
                     </span>
                   </Label>
                   <CFormInput
                     id="exampleFormControlInput1"
                     placeholder="Enter Reason"
                     // value={des}
                     // onChange={(e) => setDes(e.target.value)}
                   />
                   {/* {err ? (
                   <Typography style={{ color: "red" }}>
                     {err}
                   </Typography>
                 ) : null} */}
                 </Col>
               </Row>
             </CContainer>
           </div>
           <Box
             mt={"30px"}
             sx={{
               display: "flex",
               flexDirection: "row",
               flexWrap: "wrap",
               justifyContent: "end",
             }}
           >
             <Button
               type="reset"
               variant="outlined"
               aria-label="fingerprint"
               sx={{
                 display: "flex",
                 margin: "12px",
                 alignSelf: "left",
               }}
               color="primary"
              //  onClick={reset}
             >
               Reset
             </Button>
             <Button
               variant="contained"
               aria-label="fingerprint"
               sx={{
                 display: "flex",
                 margin: "12px",
                 alignSelf: "left",
               }}
               color={"primary"}
               // onClick={initiateDes}
             >
               Submit
             </Button>
           </Box>
         </div>) }
           
    </div>

  )
}

export default ItRequest;
