import React, { useState } from "react";
import { Container, Row, Col, Card, CardFooter } from "reactstrap";
import System from "../../assets/images/computer.jpg";
import Food from "../../assets/images/food.jpg";
import It from "../../assets/images/system.jpg";
import "./styles.css";
import FoodRequest from "./FoodRequest/FoodRequest";
import AssetRequest from "./AssetRequest";
import ItRequest from "./ItSupportRequest";
const Request = ({menuId}) => {
  const [food, setFood] = useState(false);
  const [asset, setAsset] = useState(false);
  const [it, setIt] = useState(false);
  const onMouseEnter = (e) => {
    e.target.style.transform = "scale(1.05)";
    e.target.style.transition = "all 0.3s ease-in-out";
  };
  const onMouseLeave = (e) => {
    e.target.style.transform = "scale(1)";
    e.target.style.transition = "all 0.3s ease-in-out";
  };
  
  return (
    <>
      <div
        style={{
          width: "100%",
          minHeight: "calc(100vh - 190px)",
          backgroundColor: "white",
          borderRadius: "20px",
        }}
      >
        <h1
          style={{
            fontSize: "1.5rem",
            fontWeight: "500",
            padding: "20px",
            paddingRight: "5px",
            wordWrap: "break-word",
          }}
        >
          Request
        </h1>
        <Container style={{ paddingTop: "10%" }}>
          <Row style={{justifyContent:"space-evenly"}} className={"imgBox"}>
            <Col md={4}>
              <Card
                onClick={() => setFood(!food)}
                onMouseOver={(e) => onMouseEnter(e)}
                onMouseLeave={(e) => onMouseLeave(e)}
                className={"cardout"}
                
              >
                <img src={Food} className={"cardImg"} />
                <b
                  style={{
                    position: "absolute",
                    marginLeft: "32%",
                    marginTop: "22%",
                    fontSize: 20,
                    padding: 2,
                  }}
                  className={"title"}
                >
                  Food Request
                </b>
                {/* <CardFooter style={{height:40,textAlign:"center"}}>
              Food Request
            </CardFooter> */}
              </Card>
            </Col>
            <Col md={4}>
              <Card
                onClick={() => setAsset(!asset)}
                onMouseOver={(e) => onMouseEnter(e)}
                onMouseLeave={(e) => onMouseLeave(e)}
                className={"cardout"}
              >
                <img src={System} className={"cardImg"} />
                <b
                  style={{
                    position: "absolute",
                    marginLeft: "32%",
                    marginTop: "22%",
                    fontSize: 20,
                    padding: 2,
                  }}
                  className={"title"}
                >
                  Assets Request
                </b>
              </Card>
            </Col>
            <Col md={4}>
              <Card
                onClick={() => setIt(!it)}
                onMouseOver={(e) => onMouseEnter(e)}
                onMouseLeave={(e) => onMouseLeave(e)}
                className={"cardout"}
              >
                <img src={It} className={"cardImg"}/>
                <b
                  style={{
                    position: "absolute",
                    marginLeft: "36%",
                    marginTop: "22%",
                    fontSize: 20,
                    padding: 2,
                  }}
                  className={"title"}
                >
                  IT Request
                </b>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
      {food && <FoodRequest open={food} setOpen={setFood}  menuId={menuId} />}
      {asset && <AssetRequest open={asset} setOpen={setAsset} menuId={menuId} />}
      {/* {it && <ItRequest open={it} setOpen={setIt} menuId={menuId} />} */}
    </>
  );
};

export default Request;
