import React, { useContext, useEffect, useState } from "react";
import { toast, Toaster } from "react-hot-toast";
import CIcon from "@coreui/icons-react";
import { cilArrowCircleLeft } from "@coreui/icons";
import { CContainer, CFormInput, CFormText } from "@coreui/react";
import {MdDeleteSweep} from 'react-icons/md' 
import {GiReturnArrow} from 'react-icons/gi'
import {
  getAccessForMenu,
  getAllStoreAssets,
  newStoreAsset,
} from "src/utility/apiService";
import CustomTable from "src/custom/Table";
import { AssetRecover, AssetDelete, AssetUpdate } from "./EditModal";
import View1 from '../view/index'
import { Col, Form, FormGroup, Label, Row } from "reactstrap";
import { Typography } from "@mui/material";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box/Box";
import { MdAddCircle } from "react-icons/md";
import { FaEye } from "react-icons/fa";
import { IconContext } from "react-icons";
import { RoleMenuAccessContext } from "src/context/roleMenuContext";

const CreateAsset = ({menuId}) => {
  const [open, setOpen] = useState(false);
  const [open2, setOpen2] = useState(false);
  const [recover, setRecover] = useState(false);
  const [update, setUpdate] = useState(false);
  const [id, setId] = useState({});
  const [modal, setModal] = useState(false);
  const [modal2, setModal2] = useState(false);
  const [assmodel, setAssmodel] = useState(false);

  const [assetName, setAName] = useState("");
  const [stock, setAStock] = useState("");

  const [aNameErr, setANameErr] = useState("");
  const [aStockErr, setAStockErr] = useState("");

  const [getAccess, setGetAccess] = useState( );
  const [storeId, setStoreId] = useState( );
  const [data, setData] = useState([]);
  const [data2, setData2] = useState([]);
  const blockInvalidChar = e => ['e', 'E', '+', '-'].includes(e.key) && e.preventDefault();
  const reset = () => {
    setAName("");
    setAStock("");

    setAStockErr("");
    setANameErr("");
  };
  const toggle = () => setOpen(!open);
  const toggleForShow = (id) => {
    setStoreId(id)
    setAssmodel(!assmodel)
  }
  
  let [columns,setColumns ]= useState([
    {
      Header: "SI No",
      id: "index",
      accessor: (row, index) => (
        <div style={{ textAlign: "center" }}>{index + 1}</div>
      ),
    },
    {
      Header: "Assets Name",
      accessor: "assetsName",
    },
    {
      Header: "Total Product",
      accessor: "totalStock",
    },
    {
      Header: "Stock",
      accessor: "stock",
    },
    {
      Header: "Add",
      accessor: "add",
      disableSortBy: true,
    },
    {
      Header: "View",
      accessor: "view",
      disableSortBy: true,
    },
    // {
    //   Header: "Delete",
    //   accessor: "delete",
    //   disableSortBy: true,
    // },
  ]);
  // columns2
  let [columns2,setColumns2 ] = useState([
    {
      Header: "SI No",
      id: "index",
      accessor: (row, index) => (
        <div style={{ textAlign: "center" }}>{index + 1}</div>
      ),
    },
    {
      Header: "Assets Type",
      accessor: "assetsType",
    },
    {
      Header: "Assets Name",
      accessor: "assetsName",
    },
    {
      Header: "Assets Code",
      accessor: "assetsNumber",
    },
    {
      Header: "Recover",
      accessor: "edit",
      disableSortBy: true,
    },
  ]);

  
  let roleMenuAccess = useContext(RoleMenuAccessContext);
  // ***********************  api's  ***********************
  
  useEffect(() => {
    let fetchData = async () => {
      try {
        let res = await getAccessForMenu(roleMenuAccess?.roleId, menuId);
        setGetAccess(res.data.data);
        if ( !res.data.data?.isOwner && res.data.data?.update == false ) {
          setColumns((pState) =>
            pState.filter((item) => item.Header != "Add")
          );
          setColumns((pState) =>
            pState.filter((item) => item.Header != "Delete")
          );
        }
        if ( !res.data.data?.isOwner && res.data.data?.get == false ) {
          setColumns((pState) =>
            pState.filter((item) => item.Header != "View")
          );
          
        }
      } catch (error) {
        console.log(error.message);
      }
    };
    fetchData();
  }, [menuId]);


  useEffect(() => {
    const assetData = async () => {
      try {
        let response = await getAllStoreAssets();
        let arr = [];
        let arr2 = [];
        response.data?.map((item, index) => {
            arr.push({
              ...item,
              add: (
                <center>
                  <MdAddCircle
                    style={{ cursor: "pointer" }}
                    size={25}
                    onClick={() => {
                      setUpdate(!update), setId(item);
                    }}
                  ></MdAddCircle>
                </center>
              ),
              view: (
                <center>
                 <IconContext.Provider
                    value={{ color: "#000", size: "20" }}
                    >
                 <FaEye
                   style={{ cursor: "pointer" }}
                   size={25}
                 onClick={()=>{
                  toggleForShow(item._id)
                 }}
                 />
                 </IconContext.Provider>
                </center>
              ),
              delete: (
                <center>
                  <MdDeleteSweep
                    size={25}
                    style={{ cursor: "pointer" }}
                    onClick={() => {
                      setModal2(!modal2), setId(item);
                    }}
                  ></MdDeleteSweep>
                </center>
              ),
            });

          // Deleted data
          if (item.isBlock == true) {
            arr2.push({
              ...item,
              edit: (
                <center>
                  <GiReturnArrow
                    size={25}
                    style={{ cursor: "pointer" }}
                    onClick={() => {
                      setOpen2(!open2), setId(item), console.log(item);
                    }}
                  ></GiReturnArrow>
                </center>
              ),
            });
          } else {
            return null;
          }
        });
        setData2(arr2);
        setData(arr);
      } catch (error) {
        console.log(error);
      }
    };
    assetData();
  }, [open, modal, modal2, open2, update, getAccess]);
  const handleSubmit = async () => {
    if (!assetName) {
      setANameErr("Asset Name is required!");
    } else {
      setANameErr("");
    }
    if (!stock) {
      setAStockErr("Stock is required!");
    } else {
      setAStockErr("");
    }
   
    if (assetName  && stock) {
      try {
        let response = await newStoreAsset({
          assetsName: assetName,
          totalStock: stock,
          menuId
        });
        if (!response.ok) {
          return toast.error(response.data.message);
        }
        toast.success(response.data.message);
        setOpen(!open);
      } catch (error) {
        console.log(error);
      }
    }
  };
  return (
    <div
      style={{
        width: "100%",
        minHeight: "calc(100vh - 190px)",
        backgroundColor: "white",
        borderRadius: "20px",
      }}
    >
      {!update ? (
        <>
          {!recover ? (
            <>
              {!open ? (
                <>
                  <div
                    style={{
                      display: "flex",
                      flexWrap: "wrap",
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    <h1
                      style={{
                        fontSize: "1.5rem",
                        fontWeight: "500",
                        padding: "20px",
                        paddingRight: "5px",
                        wordWrap: "break-word",
                      }}
                    >
                      Asset Store 
                    </h1>
                    {getAccess?.isOwner || getAccess?.create ?<Button
                      variant="contained"
                      color="primary"
                      style={{ marginRight: "1rem", marginLeft: "10px" }}
                      onClick={toggle}
                    >
                      Create
                    </Button>:null}
                  </div>
                  {modal2 && (
                    <AssetDelete
                      open1={modal2}
                      setOpen1={setModal2}
                      data={id}
                      menuId={menuId}
                    />
                  )}
                  {assmodel && (
                    <View1
                      open1={assmodel}
                      setOpen1={setAssmodel}
                      data={data}
                      storeId={storeId}
                      menuId={menuId}
                    />
                  )}   
                  <CContainer fluid>
                    <CustomTable
                      columns={columns}
                      data={data}
                      // onClick={getAccess?.isOwner || getAccess?.update ? () => setRecover(!recover) : null}
                    />
                  </CContainer>
                </>
              ) : (
                <>
                  <div>
                    <div
                      style={{
                        flexDirection: "row",
                        position: "relative",
                        display: "flex",
                        borderRadius: "20px",
                        marginLeft: "0.5rem",
                        alignItems: "center",
                      }}
                    >
                      <CContainer style={{ display: "contents" }}>
                        <CIcon
                          icon={cilArrowCircleLeft}
                          size="xl"
                          style={{
                            marginTop: "1rem",
                            marginLeft: "1rem",
                            cursor: "pointer",
                          }}
                          onClick={toggle}
                        />
                        <h1
                          style={{
                            fontSize: "1.5rem",
                            fontWeight: "500",
                            marginLeft: "3.8rem",
                            position: "absolute",
                            top: "13px",
                            paddingRight: "0px",
                          }}
                        >
                          Create Store Assets
                        </h1>
                      </CContainer>
                    </div>
                    <Form>
                      <div
                        className="cusInpFullCon"
                        style={{
                          position: "relative",
                          marginTop: "3rem",
                          // width: "50%",
                          marginRight: "5rem",
                        }}
                      >
                        <CContainer
                          className="cusInpFullWrap"
                          style={{ marginLeft: "3.2rem" }}
                        >
                          <Row>
                            <Col
                              md={6}
                              className="cusInpCon"
                              style={{ minWidth: "250px", maxWidth: "300px" }}
                            >
                              <FormGroup>
                                <Label>
                                  Asset Name
                                  <span
                                    style={{
                                      paddingLeft: "5px",
                                      color: "red",
                                      fontSize: "15px",
                                    }}
                                  >
                                    *
                                  </span>
                                </Label>
                                <CFormInput
                                  id="exampleFormControlInput1"
                                  placeholder="Enter Asset Name"
                                  value={assetName}
                                  onChange={(e) => setAName(e.target.value)}
                                />
                                {aNameErr ? (
                                  <Typography style={{ color: "red" }}>
                                    {aNameErr}
                                  </Typography>
                                ) : null}
                              </FormGroup>
                            </Col>
                            <Col
                              md={6}
                              className="cusInpCon"
                              style={{ minWidth: "250px", maxWidth: "300px" }}
                            >
                              <FormGroup>
                                <Label>
                                 Total Product
                                  <span
                                    style={{
                                      paddingLeft: "5px",
                                      color: "red",
                                      fontSize: "15px",
                                    }}
                                  >
                                    *
                                  </span>
                                </Label>
                                <CFormInput
                                  min="0"
                                  id="exampleFormControlInput1"
                                  type="number"
                                  placeholder="Enter Total Product"
                                  value={stock}
                                  onChange={(e) => setAStock(e.target.value)}
                                  onKeyDown={blockInvalidChar}
                                />
                                {aStockErr ? (
                                  <Typography style={{ color: "red" }}>
                                    {aStockErr}
                                  </Typography>
                                ) : null}
                              </FormGroup>
                            </Col>
                          </Row>
                        </CContainer>
                      </div>
                    </Form>
                    <Box
                      mt={"30px"}
                      sx={{
                        display: "flex",
                        flexDirection: "row",
                        flexWrap: "wrap",
                        justifyContent: "end",
                      }}
                    >
                      <Button
                        type="reset"
                        variant="outlined"
                        aria-label="fingerprint"
                        sx={{
                          display: "flex",
                          margin: "12px",
                          alignSelf: "left",
                        }}
                        color="primary"
                        onClick={reset}
                      >
                        Reset
                      </Button>
                      <Button
                        variant="contained"
                        aria-label="fingerprint"
                        sx={{
                          display: "flex",
                          margin: "12px",
                          alignSelf: "left",
                        }}
                        color={"primary"}
                        onClick={handleSubmit}
                      >
                        Submit
                      </Button>
                    </Box>
                  </div>
                </>
              )}
            </>
          ) : (
            <>
              <div
                style={{
                  flexDirection: "row",
                  position: "relative",
                  display: "flex",
                  borderRadius: "20px",
                  marginLeft: "0.5rem",
                  alignItems: "center",
                }}
              >
                <CContainer fluid style={{ display: "contents" }}>
                  <CIcon
                    icon={cilArrowCircleLeft}
                    size="xl"
                    style={{
                      marginTop: "1rem",
                      marginLeft: "1rem",
                      cursor: "pointer",
                    }}
                    onClick={() => setRecover(!recover)}
                  />
                  <h1
                    style={{
                      fontSize: "1.5rem",
                      fontWeight: "500",
                      marginLeft: "3.8rem",
                      position: "absolute",
                      top: "13px",
                    }}
                  >
                    Deleted StoreAssets
                  </h1>
                </CContainer>
              </div>
              {open2 && (
                <AssetRecover open={open2} setOpen={setOpen2} data={id} menuId={menuId} />
              )}
              <CContainer fluid>
                <CustomTable columns={columns2} data={data2} />
              </CContainer>
            </>
          )}
        </>
      ) : (
        <>
          <AssetUpdate open={update} setOpen={setUpdate} data={id} menuId={menuId} />
        </>
      )}

      <Toaster />
    </div>
  );
};

export default CreateAsset;
