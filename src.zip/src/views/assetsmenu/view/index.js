// import { Button } from "@coreui/coreui";
// import { CButton, CModal, CModalBody, CModalFooter, CModalHeader, CModalTitle } from "@coreui/react";

import { CContainer } from "@coreui/react";
import { FormGroup } from "@mui/material";
import {
  MDBBtn,
  MDBCol,
  MDBContainer,
  MDBModal,
  MDBModalBody,
  MDBModalContent,
  MDBModalDialog,
  MDBModalFooter,
  MDBModalHeader,
  MDBModalTitle,
  MDBCard,
  MDBRow,
} from "mdb-react-ui-kit";
import React, { useEffect, useState } from "react";
import { Toaster } from "react-hot-toast";
import { IconContext } from "react-icons";
import { HiCheckCircle } from "react-icons/hi";
import { MdCancel } from "react-icons/md";

import CustomSelect from "src/components/CustomSelect";
import CustomTable from "src/custom/Table";
import { getAllassets, getAssetsUsingStoreId } from "src/utility/apiService";
const View1 = (props) => {
  const [select, setSelect] = useState([
    { value: "Available", label: "Available" },
    { value: "Unavailable", label: "Unavailable" },
    { value: "damaged", label: "damaged" },
  ]);
  const [selected, setSelected] = useState("");
  const [data1, setData1] = useState([]);
  const { open1, setOpen1, data ,storeId,menuId} = props;
  const toggle = () => setOpen1(!open1);

  let columns = [
    {
      Header: "SI No",
      id: "index",
      accessor: (row, index) => (
        <div style={{ textAlign: "center" }}>{index + 1}</div>
      ),
    },
    {
      Header: "Assets Type",
      accessor: "type",
    },
    {
      Header: "Assets Name",
      accessor: "BrandName",
    },
    {
      Header: "Assets Code",
      accessor: "assetsId",
    },
    {
      Header: "Available",
      accessor: "ava",
      disableSortBy: true,
    },
    {
      Header: "User",
      accessor: "userName",
      disableSortBy: true,
    },
  ];

  const Allassets = async () => {
    let arr = [];
    let response = await getAssetsUsingStoreId(storeId,menuId);
    response?.data?.data?.map((item, index) => {
      arr.push({
        ...item,
        ava: (
          <center>
          <h6 style={{color:item.isAvailable ? item.type=="damaged" ? "red" : "green":"red"}} >
            {item.type=="damaged"? "---" : item.isAvailable ? "Available":"Unavailable"}
          </h6>
        </center>
        ),
        userName: item?.userId!=null ? item?.userId?.firstName + " " + item?.userId?.lastName:("Null"),
      });
    });
    setData1(arr);

    if (selected.value === "Unavailable") {
      let ava = [];
      let availableData = response?.data?.data?.filter((i) => !i.isAvailable);
      availableData.map((i) => {
        ava.push({
          ...i,
          ava: (
            <center>
            <h6 style={{color:"red"}} >
              {i.isAvailable  ? "Available":"Unavailable"}
              </h6>
          </center>
          ),
          userName: i?.userId!=null ? i?.userId?.firstName + " " + i?.userId?.lastName:("Null"),
        });
      });
      setData1(ava);
    } else if (selected.value === "Available") {
      let unAva = [];
      let unavailavleData = response?.data?.data?.filter((i) => i.isAvailable && i.type!="damaged");
      unavailavleData.map((i) => {
        unAva.push({
          ...i,
          ava: (
            <center>
            <h6 style={{color:"green"}} >
              {i.type==="damaged" ?( "--"):i.isAvailable ? "Available":"Unavailable"}
              </h6>
          </center>
          ),
          userName: i?.userId!=null ? i?.userId?.firstName + " " + i?.userId?.lastName:("Null"),
        });
      });
      setData1(unAva);
    } else if (selected.value === "damaged") {
      let damaged = [];
      let damagedData = response?.data?.data?.filter( (i) => i.type == "damaged");
      damagedData.map((i) => {
        damaged.push({
          ...i,
          ava: (
            <center>
          <h6 style={{color:"red"}} >
            {i.type=="damaged"? "---" : item.isAvailable ? "Available":"Unavailable"}
          </h6>
        </center>
          ),
         userName:i.isAvailable?( i?.userId
            ? i?.userId?.firstName + " " + i?.userId?.lastName
            : "---"):("Null"),
        });
      });
      setData1(damaged);
    } else {
      setData1(arr);
    }
  };

  useEffect(() => {
    Allassets();
  }, [selected]);

  return (
    <>
      {data1 ? (
        <div className="w-75 p-3">
          <MDBModal show={open1} setShow={setOpen1} tabIndex="-1">
            <MDBModalDialog centered size="xl">
              <MDBModalContent>
                <MDBCard>
                  <MDBModalHeader>
                    <MDBModalTitle>Available & Unavailable</MDBModalTitle>
                    <MDBBtn
                      className="btn-close"
                      color="none"
                      onClick={toggle}
                    ></MDBBtn>
                  </MDBModalHeader>
                  <MDBContainer className="px-4">
                    <>
                      <FormGroup
                        style={{
                          width: "300px",
                          marginLeft: "10px",
                          marginTop: "10px",
                        }}
                      >
                        <CustomSelect
                          option={select}
                          selectedOptions={selected}
                          setSelectedOptions={setSelected}
                          isSearchable={true}
                          isMulti={false}
                          placeholder={"Select Type"}
                          style={{ marginButtom: "0.5rem" }}
                        />
                      </FormGroup>
                      <CContainer fluid>
                        <CustomTable columns={columns} data={data1} />
                      </CContainer>
                    </>
                  </MDBContainer>
                  <MDBModalFooter></MDBModalFooter>
                </MDBCard>
              </MDBModalContent>
            </MDBModalDialog>
          </MDBModal>
        </div>
      ) : (
        <h1>No Mapping </h1>
      )}
      <Toaster />
    </>
  );
};

export default View1;
