import React, { useEffect, useState } from "react";
import {
  MDBBtn,
  MDBModal,
  MDBModalDialog,
  MDBModalContent,
  MDBModalHeader,
  MDBModalTitle,
  MDBModalBody,
  MDBModalFooter,
} from "mdb-react-ui-kit";
import CustomTable from "src/custom/Table";
import { getUserAssetsById } from "src/utility/apiService";
import { Icon, Box } from "@mui/material";
import { toast, Toaster } from "react-hot-toast";
import { HiPencilSquare } from "react-icons/hi2";

export default function AccessModel({
  gridModal,
  setGridModal,
  id,
  openUnMap,
  setOpenUnMap,
  setUserItemForUnMap,
  setAssetsItemForUnMap,
  getAccess,
  menuId,
}) {
  const [toggleModal, setToggleModal] = useState(false);
  const [data, setData] = useState([]);

  let [columns,setColumns ]= useState([
    {
      Header: "SI No",
      id: "index",
      accessor: (row, index) => (
        <div style={{ textAlign: "center" }}>{index + 1}</div>
      ),
    },
    {
      Header: "Employee Name",
      accessor: "name",
    },
    {
      Header: "Assets Name",
      accessor: "assetName",
    },
    {
      Header: "Assets ID",
      accessor: "assetId",
    },
    {
      Header: "Asset Type",
      accessor: "typeOfAsset",
    },
    {
      Header: "Any User Used",
      accessor: "anyUserUsed",
    },
    {
      Header: "Start Date",
      accessor: "startDate",
    },
    {
      Header: "End Date",
      accessor: "endDate",
    },
    {
      Header: "Un Mapping",
      accessor: "edit",
    },
  ]);
  const toggleShow = () => setGridModal(!gridModal);
  const openUserAssetUnmap = (item) => {
    setGridModal(!gridModal);
    setUserItemForUnMap(item.userId);
    setOpenUnMap(!openUnMap);
    setAssetsItemForUnMap(item.assetId);
  };

  useEffect(() => {
    const userAssData = async () => {
      if ( !getAccess.isOwner && getAccess?.update == false ) {
        setColumns((pState) =>
          pState.filter((item) => item.Header != "Un Mapping")
        );
        setColumns((pState) =>
          pState.filter((item) => item.Header != "Delete")
        );
      }
    }
    userAssData();
  }, [getAccess]);

  useEffect(() => {
    const userAssData = async () => {
      try {
        let res = await getUserAssetsById(id,menuId);
        let rows = [];
        if (!res.ok) {
          toast.error(res.data.message);
          return;
        }
        res.data.data.map((item) => {
          rows.push({
            name: item.userId.firstName + " " + item.userId.lastName,
            assetName: item?.storeId?.assetsName,
            assetId: item?.assetId?.assetsId,
            typeOfAsset: item?.assetId?.type ,
            anyUserUsed: item.isUsed ? "---" : item.assetId?.userId==null ? "No" : "Yes",
            edit: item.isUsed ? (
              <center>
                <HiPencilSquare
                  size={25}
                  style={{ cursor: "pointer" }}
                  onClick={() => openUserAssetUnmap(item)}
                ></HiPencilSquare>
              </center>
            ) : (
              <center>
                Unmapped
              </center>
            ),
            startDate: new Date(item.createdAt)?.toLocaleDateString()+"("+new Date(item.createdAt)?.toLocaleTimeString()+ ")",
            endDate: item.isUsed
              ? "---"
              : new Date(item.updatedAt)?.toLocaleDateString()+"("+new Date(item.updatedAt)?.toLocaleTimeString()+ ")",
          });
        });

        setData(rows);
      } catch (error) {
        console.log(error.message);
      }
    };
    userAssData();
  }, [toggleModal,openUnMap,getAccess]);
  return (
    <>
      <MDBModal
        style={{ display: "flex", alignItems: "center", marginTop: "85px" }}
        show={gridModal}
        setShow={setGridModal}
      >
        <MDBModalDialog scrollable style={{ minWidth: "80%" }}>
          <MDBModalContent
            style={{ minHeight: "80%" }}
            className="modelRoleMenuTable"
          >
            <MDBModalHeader>
              <MDBModalTitle style={{ fontWeight: "600" }}>
                User Assets Mapping
              </MDBModalTitle>
              <MDBBtn
                type="button"
                className="btn-close"
                color="none"
                onClick={toggleShow}
              ></MDBBtn>
            </MDBModalHeader>
            <MDBModalBody>
              <Box sx={{ display: "flex", justifyContent: "center" }}>
                <Box sx={{ width: "100%" }}>
                  <CustomTable columns={columns} data={data} />
                </Box>
              </Box>
            </MDBModalBody>
          </MDBModalContent>
        </MDBModalDialog>
      </MDBModal>
    </>
  );
}
