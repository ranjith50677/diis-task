import React, { useState, useEffect } from "react";
import { toast, Toaster } from "react-hot-toast";
import { CContainer, CFormInput } from "@coreui/react";
import CIcon from "@coreui/icons-react";
import { Col, Row, Label } from "reactstrap";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box/Box";
import { cilArrowCircleLeft } from "@coreui/icons";
import CustomSelect from "src/components/CustomSelect";
import { userAssetUnmapping } from "src/utility/apiService";

export default function AssetUnmapModal(props) {
  const { openUnMap, setOpenUnMap, userItem, assetItem, getAccess, menuId } = props;
  const [reason, setReason] = useState("");
  const [seleTypeForAss, setSeleTypeForAss] = useState();
  const [typeForAss, setTypeForAss] = useState([
    { value: "Working", label: "Working" },
    { value: "Damaged", label: "Damaged" },
  ]);
  const [selectUser, setSelectUser] = useState({
    value: userItem.firstName + " " + userItem.lastName,
    label: userItem.firstName + " " + userItem.lastName,
  });
  const [selectAsset, setSelectAsset] = useState({
    value: assetItem.assetsId,
    label: assetItem.assetsId,
  });
  const [error, setError] = useState({
    type: "",
    reason: ""
  });
  const toggle = () => setOpenUnMap(!openUnMap);
  const reset = () => {
    setError({
      type: "",
      reason: ""
    })
    setReason("");
    setSeleTypeForAss("");
  };

  const handleUpdate = async () => {
    let success=false;
    if(!seleTypeForAss){
      setError(()=>({...error,type:"Please select a type"}))
    }else{
      setError(()=>({...error,type:""}))
    }
    if(seleTypeForAss.value==="Damaged"){
      if(!reason){
        setError(()=>({...error,reason:"Please enter a reason"}))
      }else{
        success=true;
        setError(()=>({...error,reason:""}))
      }
    }
    if(seleTypeForAss.value==="Working"){
      success=true;
    }
    if(success && seleTypeForAss){
      let obj = {userId:userItem._id,assetId:assetItem._id,type:seleTypeForAss.value,reason:reason,menuId}
      let unMap=await userAssetUnmapping(obj);
      if(!unMap.ok){
        return toast.error(unMap.data.message);
      }
      setTimeout(() => {
        toggle();
        reset();
      }, 500);
      toast.success(unMap.data.message);
    }
  };
  
  return (
    <>
      <div
        style={{
          width: "100%",
          minHeight: "calc(100vh - 190px)",
          backgroundColor: "white",
          borderRadius: "20px",
          position: "absolute",
          top: "0",
          marginRight: "30px",
          maxWidth: "-webkit-fill-available",
          zIndex: "5",
          height: "100%",
        }}
      >
        <>
          <div>
            <div
              style={{
                flexDirection: "row",
                position: "relative",
                display: "flex",
                borderRadius: "20px",
                marginLeft: "0.5rem",
                alignItems: "center",
              }}
            >
              <CContainer style={{ display: "contents" }}>
                <CIcon
                  icon={cilArrowCircleLeft}
                  size="xl"
                  style={{
                    marginTop: "1rem",
                    marginLeft: "1rem",
                    cursor: "pointer",
                  }}
                  onClick={toggle}
                />
                <h1
                  style={{
                    fontSize: "1.5rem",
                    fontWeight: "600",
                    marginLeft: "3.8rem",
                    position: "absolute",
                    top: "13px",
                  }}
                >
                  User Asset Unmapping
                </h1>
              </CContainer>
            </div>
            <Box sx={{ paddingLeft: "4%" }}>
              <Box
                sx={{
                  width: "100%",
                  display: "flex",
                  flexDirection: "column",
                  flexWrap: "wrap",
                  alignItems: "flex-start",
                  justifyContent: "center",
                }}
              >
                <Box
                  mt={10}
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    flexWrap: "wrap",
                    justifyContent: "start",
                    marginTop: "3rem",
                    width: "100%",
                    alignItems: "baseline",
                  }}
                >
                  <Box className="cusInpRoleMenu">
                    <Label style={{ margin: 0 }}>
                      Select The User
                    </Label>
                    <CustomSelect
                      widthForSelect="100%"
                      placeholder={"Select The User"}
                      selectedOptions={selectUser}
                      isSearchable={true}
                      isMulti={false}
                      disabled={true}
                      star={"*"}
                      width="300px"
                    />
                  </Box>
                  <Box className="cusInpRoleMenu">
                    <Label style={{ margin: 0, paddingLeft: "8px" }}>
                      Select The Assets Id
                    </Label>
                    <CustomSelect
                      widthForSelect="100%"
                      placeholder={"Select The Asset"}
                      selectedOptions={selectAsset}
                      isSearchable={true}
                      isMulti={false}
                      star={"*"}
                      disabled={true}
                      width="300px"
                    />
                  </Box>
                  <Box className="cusInpRoleMenu">
                    <Label style={{ margin: 0, paddingLeft: "8px" }}>
                      Unassembled Reason
                      <span
                        style={{
                          paddingLeft: "5px",
                          color: "red",
                          fontSize: "15px",
                        }}
                      >
                        *
                      </span>
                    </Label>
                    <CustomSelect
                      widthForSelect="100%"
                      option={typeForAss}
                      placeholder={"Select The Reason"}
                      selectedOptions={seleTypeForAss}
                      setSelectedOptions={setSeleTypeForAss}
                      isSearchable={true}
                      isMulti={false}
                      star={"*"}
                      required={true}
                      width="300px"
                    />
                    {error.type ? (
                      <p
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                      >
                        {error.type}
                      </p>
                    ) : null}
                  </Box>
                  {seleTypeForAss?.value =="Damaged" && <Box
                    className="cusSwiRoleMenuCon"
                    sx={{
                      width: "300px",
                      display: "flex",
                      flexDirection: "row",
                      flexWrap: "wrap",
                      alignItems: "center",
                      justifyContent: "start",
                      padding: "8px",
                    }}
                  >
                    <Label style={{ marginBottom: "12px" }}>
                      Reason For Damage
                      <span
                        style={{
                          paddingLeft: "5px",
                          color: "red",
                          fontSize: "15px",
                        }}
                      >
                        *
                      </span>
                    </Label>
                    <CFormInput
                      id="exampleFormControlInput1"
                      placeholder="Enter Brand Name"
                      value={reason}
                      onChange={(e) => setReason(e.target.value) }
                    />
                    {seleTypeForAss?.value =="Damaged" && error.reason ? (
                            <p
                              style={{
                                paddingLeft: "14px",
                                color: "red",
                                fontSize: "14px",
                              }}
                            >
                              {error.reason}
                            </p>
                          ) : null}
                  </Box>}
                </Box>
              </Box>
              <Box
                mt={"30px"}
                sx={{
                  display: "flex",
                  flexDirection: "row",
                  flexWrap: "wrap",
                  justifyContent: "end",
                }}
              >
                <Button
                  type="reset"
                  variant="outlined"
                  aria-label="fingerprint"
                  sx={{ display: "flex", margin: "15px", alignSelf: "left" }}
                  color="primary"
                  onClick={reset}
                >
                  Reset
                </Button>
                <Button
                  variant="contained"
                  aria-label="fingerprint"
                  sx={{ display: "flex", margin: "15px", alignSelf: "left" }}
                  color={"primary"}
                  onClick={handleUpdate}
                >
                  Submit
                </Button>
              </Box>
            </Box>
          </div>
        </>
      </div>
      <Toaster />
    </>
  );
}
