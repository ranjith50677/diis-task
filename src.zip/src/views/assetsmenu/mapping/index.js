import { CContainer, CFormInput, CFormText } from "@coreui/react";
import React, { useState, useEffect, useContext } from "react";
import { Row, Col, Label } from "reactstrap";
import CustomTable from "src/custom/Table";
import CIcon from "@coreui/icons-react";
import { toast, Toaster } from "react-hot-toast";
import { cilArrowCircleLeft } from "@coreui/icons";
import { Box, Switch } from "@mui/material";
import "./styles.css";
import {
  assetMapping,
  getAllStoreAssets,
  getAllUsers,
  getAllAssets,
  createAssets,
  getAccessForMenu,
} from "src/utility/apiService";
import CustomSelect from "../../../components/CustomSelect";
// import CustomSwitch from "src/custom/Switch";
import { FaEye } from "react-icons/fa";
import AccessModel from "./AccessModal";
import Button from "@mui/material/Button";
import AssetUnmap from "./AssetUnmap";
import { RoleMenuAccessContext } from "src/context/roleMenuContext";

const AssetMapping = ({ menuId }) => {
  const [userItemForUnMap, setUserItemForUnMap] = useState("");
  const [data, setData] = useState([]);
  const [id, setId] = useState();
  const [userId, setUserId] = useState("");
  const [gridModal, setGridModal] = useState(false);
  const [open, setOpen] = useState(false);
  const [openUnMap, setOpenUnMap] = useState(false);
  const [icon, setIcons] = useState(false);
  const [assetsItemForUnMap, setAssetsItemForUnMap] = useState();
  const [getAllStoreAssts, setGetAllStoreAssts] = useState();
  const [getAllStoreAssts1, setGetAllStoreAssts1] = useState();
  const [getAllAssetByStoreName, setGetAllAssetByStoreName] = useState();
  const [store, setStore] = useState("");
  const [selectedAssetstore, setSelectedAssetStore] = useState("");
  const [store1, setStore1] = useState("");
  const [selected, setSelected] = useState("");
  const [brandName, setBrandName] = useState("");
  const [getAccess, setGetAccess] = useState();
  const [error, setError] = useState({
    user:"",
    store:"",
    asset:"",
  });
  

  const [err, setErr] = useState("");
  const [storeErr, setStoreErr] = useState("");
  const [newAsset, setNewAsset] = useState(false);
  const [getAccessAll, setGetAccessAll] = useState();
  const [columns, setColumns] = useState([
    {
      Header: "SI No",
      id: "index",
      accessor: (row, index) => (
        <div style={{ textAlign: "center" }}>{index + 1}</div>
      ),
    },
    {
      Header: "First Name",
      accessor: "firstName",
      disableSortBy: true,
      filter: "equals",
    },
    {
      Header: "Last Name",
      accessor: "lastName",
    },
    {
      Header: "Email",
      accessor: "email",
    },
    {
      Header: "Staus",
      accessor: "status",
    },
  ]);
  
  const reset = () => {
    setStore1("");
    setNewAsset(false);
    setSelectedAssetStore("");
    setStore("");
    setSelected("");
    setBrandName("");
    setError({
      user:"",
      store:"",
      asset:"",
      brand:"",
    });

  };
  const toggle = () =>{
    setOpen(!open)
    reset()
  };

  const toggleShow = (id) => {
    setId(id);
    setGridModal(!gridModal);
  };
  
  let roleMenuAccess = useContext(RoleMenuAccessContext);

  useEffect(() => {
    let fetchData = async () => {
      try {
        let res = await getAccessForMenu(roleMenuAccess?.roleId, menuId);
        setGetAccess(res.data.data);
        if ( !res.data.data?.isOwner && res.data.data?.update == false ) {
          setColumns((pState) =>
            pState.filter((item) => item.Header != "Edit")
          );
          setColumns((pState) =>
            pState.filter((item) => item.Header != "Delete")
          );
        }
      } catch (error) {
        console.log(error.message);
      }
    };
    fetchData();
  }, [menuId]);

  useEffect(() => {
    const userData = async () => {
      try {
        let response = await getAllUsers();
        let arr = [];
        response?.data?.data?.map((item) => {
          if (item.isBlock == false && item.isOwner == false) {
            arr.push({
              id: item._id,
              value: item.firstName + " " + item.lastName,
              label: item.firstName + " " + item.lastName,
            });
          }
          setUserId(arr);
        });
      } catch (error) {
        console.log(error);
      }
    };
    const assetsData = async () => {
      try {
        let response = await getAllStoreAssets();
        let arr = [];
        response.data?.map((item, index) => {
          arr.push({
            id: item._id,
            value: item.assetsName || " ",
            label: item.assetsName || " ",
          });
        });
        setGetAllStoreAssts(arr);
        setGetAllStoreAssts1(arr);
      } catch (error) {
        console.log(error);
      }
    };
    userData();
    assetsData();
  }, [getAccess]);

  useEffect(() => {
    const getAssetsData = async () => {
      let obj = {isAvailable:true,type:"working"};
      let res = await getAllAssets(obj);
      if (!res.ok) {
        return toast.error(res.data.message);
      }
      let arr = [];
      res.data.data.map((item) => {
        if (
          item.storeId.assetsName?.toLowerCase() == store?.label?.toLowerCase()
        ) {
          arr.push({
            id: item._id,
            value: item.assetsId,
            label: item.assetsId,
          });
        }
      });
      setGetAllAssetByStoreName(arr);
    };
    getAssetsData();
  }, [store,getAccess]);

  const handleSubmit = async () => {
    let success=false
    if (!selected) {
      setError((prev) => ({ ...prev, user: "User is required" }))
    } else {
      setError((prev) => ({ ...prev, user: "" }))
    }
    if(!newAsset) {
      if(!store) {
        setError((prev)=>({ ...prev, store: "Store is required!" }));
      } else {
        setError((prev)=>({ ...prev, store: "" }));
      }
      if(!selectedAssetstore) {
        setError((prev)=>({ ...prev, asset: "Asset is required!" }));
      } else {
        setError((prev)=>({ ...prev, asset: "" }));
      }
      if(store && selectedAssetstore){ 
        success=true
      }
    }else{
      setError((prev)=>({ ...prev, store: "" }));
      setError((prev)=>({ ...prev, asset: "" }));
    }
    if(newAsset) {
      if(!brandName) {
        setError((prev)=>({ ...prev, brand: "Brand Name is required!" }));
      } else {
        setError((prev)=>({ ...prev, brand: "" }));
      }
      if(!store1) {
        setError((prev)=>({ ...prev, store: "Store is required!" }));
      } else {
        setError((prev)=>({ ...prev, store: "" }));
      }
      if(store1 && brandName){ 
        success=true
      }
    }else{
      setError((prev)=>({ ...prev, brand: "" }));
    }

    if (success && selected) {
      try {
        let res
        if (newAsset) {
          let obj = {
            userId: selected.id,
            storeId: store1.id,
            type:"working",
            BrandName: brandName,
            menuId
          };
          res = await createAssets(obj);
          if (!res.ok) {
            return toast.error(res.data.message);
          }
        } 
        let obj = {
          userId: selected.id,
          storeId: store.id,
          assetsId: newAsset ? res.data.data?.assetId : selectedAssetstore.id,
          menuId
        };
        let response = await assetMapping(obj);
        if (!response.ok) {
          return toast.error(response.data.message);
        }
        setOpen(() => {
          !open;
          reset();
        }, 500);
        toast.success(response.data.message);
      } catch (error) {
        console.log(error);
      }
    }
  };

  useEffect(() => {
    const AssetData = async () => {
      try {
        const Users = await getAllUsers();
        const UsersData = Users?.data?.data?.filter((item) => {
          return item.isOwner === false;
        });
        let arr = [];
        UsersData?.map((item) => {
          arr.push({
            ...item,
            status: (
              <center>
              <FaEye
                size={"20px"}
                style={{ cursor: "pointer" }}
                onClick={() => toggleShow(item?._id)}
                fontSize="small"
                onMouseEnter={setIcons(!icon)}
              ></FaEye></center>
            ),
          });
        });

        setData(arr);
      } catch (error) {
        console.log(error.message);
      }
    };
    AssetData();
  }, []);

  return (
    <>
      <div
        style={{
          width: "100%",
          minHeight: "calc(100vh - 190px)",
          backgroundColor: "white",
          borderRadius: "20px",
        }}
      >
        {!open ? (
          <>
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <h1
                style={{
                  fontSize: "1.5rem",
                  fontWeight: "500",
                  padding: "20px",
                  paddingRight: "5px",
                }}
              >
                User Assets
              </h1>
              {getAccess?.isOwner || getAccess?.create ? <Button
                style={{
                  marginRight: "1rem",
                }}
                onClick={toggle}
                text={"Mapping"}
                color={"primary"}
                variant="contained"
              >
                Mapping
              </Button>:null}
            </div>
            <CContainer fluid>
              <CustomTable columns={columns} data={data} />
            </CContainer>
          </>
        ) : (
          <>
            <div>
              <div
                style={{
                  flexDirection: "row",
                  position: "relative",
                  display: "flex",
                  borderRadius: "20px",
                  marginLeft: "0.5rem",
                  alignItems: "center",
                }}
              >
                <CContainer style={{ display: "contents" }}>
                  <CIcon
                    icon={cilArrowCircleLeft}
                    size="xl"
                    style={{
                      marginTop: "1rem",
                      marginLeft: "1rem",
                      cursor: "pointer",
                    }}
                    onClick={toggle}
                  />
                  <h1
                    style={{
                      fontSize: "1.5rem",
                      fontWeight: "500",
                      marginLeft: "3.8rem",
                      position: "absolute",
                      top: "13px",
                    }}
                  >
                    Asset Mapping
                  </h1>
                </CContainer>
              </div>
              <Box sx={{ paddingLeft: "4%" }}>
                <Box
                  sx={{
                    width: "100%",
                    display: "flex",
                    flexDirection: "column",
                    flexWrap: "wrap",
                    alignItems: "flex-start",
                    justifyContent: "center",
                  }}
                >
                  <Box
                    mt={10}
                    sx={{
                      display: "flex",
                      flexDirection: "row",
                      flexWrap: "wrap",
                      justifyContent: "start",
                      marginTop: "3rem",
                      width: "100%",
                      alignItems:"baseline"
                    }}
                  >
                    <Box className="cusInpRoleMenu">
                      <Label style={{ margin: 0 }}>
                        Select The User
                        <span
                          style={{
                            paddingLeft: "5px",
                            color: "red",
                            fontSize: "15px",
                          }}
                        >
                          *
                        </span>
                      </Label>
                      <CustomSelect
                        widthForSelect="100%"
                        placeholder={"Select The User"}
                        option={userId}
                        selectedOptions={selected}
                        setSelectedOptions={setSelected}
                        isSearchable={true}
                        isMulti={false}
                        star={"*"}
                        width="300px"
                        required={true}
                      />
                      {error.user ? (
                        <p
                          style={{
                            paddingLeft: "14px",
                            color: "red",
                            fontSize: "14px",
                          }}
                        >
                          {error.user}
                        </p>
                      ) : null}
                    </Box>
                    <Box className="cusInpRoleMenu">
                      <Label style={{ margin: 0, paddingLeft: "8px" }}>
                        Select The Store
                        {!newAsset &&  <span
                          style={{
                            paddingLeft: "5px",
                            color: "red",
                            fontSize: "15px",
                          }}
                        >
                          *
                        </span>}
                      </Label>
                      <CustomSelect
                        widthForSelect="100%"
                        placeholder={"Select The Store"}
                        option={getAllStoreAssts}
                        selectedOptions={store}
                        setSelectedOptions={setStore}
                        isSearchable={true}
                        isMulti={false}
                        star={"*"}
                        disabled={!newAsset ? false : true}
                        width="300px"
                      />
                      {!newAsset && error.store ? (
                        <p
                          style={{
                            paddingLeft: "14px",
                            color: "red",
                            fontSize: "14px",
                          }}
                        >
                          {error.store}
                        </p>
                      ) : null}
                    </Box>
                    <Box
                      className="cusSwiRoleMenuCon"
                      sx={{
                        width: "300px",
                        display: "flex",
                        flexDirection: "row",
                        flexWrap: "wrap",
                        alignItems: "center",
                        justifyContent: "start",
                      }}
                    >
                      <Label style={{ margin: 0 }}>
                        Select The Asset Id
                        {!newAsset &&  <span
                          style={{
                            paddingLeft: "5px",
                            color: "red",
                            fontSize: "15px",
                          }}
                        >
                          *
                        </span>}
                      </Label>
                      <CustomSelect
                        widthForSelect="100%"
                        placeholder={"Select The Asset Id"}
                        option={getAllAssetByStoreName}
                        selectedOptions={selectedAssetstore}
                        setSelectedOptions={setSelectedAssetStore}
                        isSearchable={true}
                        isMulti={false}
                        star={"*"}
                        disabled={newAsset ? true : false}
                        width="300px"
                      />
                      {!newAsset && error.asset ? (
                        <p
                          style={{
                            paddingLeft: "14px",
                            color: "red",
                            fontSize: "14px",
                          }}
                        >
                          {error.asset}
                        </p>
                      ) : null}
                    </Box>
                  </Box>
                  <Box
                    className="cusSwiRoleMenuCon"
                    sx={{
                      display: "flex",
                      flexDirection: "row",
                      flexWrap: "wrap",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  ></Box>
                  <Box
                    className="cusSwiRoleMenuCon"
                    sx={{
                      display: "flex",
                      flexDirection: "row",
                      flexWrap: "wrap",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Box
                      className="cusSwiRoleMenuCon"
                      sx={{
                        width: "300px",
                        display: "flex",
                        flexDirection: "row",
                        flexWrap: "wrap",
                      }}
                    >
                      <p
                        style={{
                          fontSize: "18px",
                          fontWeight: "400",
                          marginTop: "10px",
                          paddingLeft: "10px",
                        }}
                      >
                        Want new assets
                        <Switch
                          onChange={(e) => {}}
                          checked={newAsset}
                          onClick={() => {
                            setNewAsset(!newAsset);
                            setStore("");
                            setSelectedAssetStore("");
                          }}
                          color="success"
                        />
                      </p>
                    </Box>
                  </Box>
                  {newAsset && (
                    <>
                      <Box
                        className="cusSwiRoleMenuCon"
                        sx={{
                          display: "flex",
                          flexDirection: "row",
                          flexWrap: "wrap",
                          alignItems: "baseline",
                          justifyContent: "start",
                        }}
                      >
                        <Box
                          className="cusSwiRoleMenuCon"
                          sx={{
                            width: "300px",
                            display: "flex",
                            flexDirection: "row",
                            flexWrap: "wrap",
                            alignItems: "center",
                            justifyContent: "start",
                          }}
                        >
                          <Label style={{ margin: 0 }}>
                            Select The Store
                            <span
                              style={{
                                paddingLeft: "5px",
                                color: "red",
                                fontSize: "15px",
                              }}
                            >
                              *
                            </span>
                          </Label>
                          <CustomSelect
                            widthForSelect="100%"
                            placeholder={"Select Store"}
                            option={getAllStoreAssts1}
                            selectedOptions={store1}
                            setSelectedOptions={setStore1}
                            isSearchable={true}
                            isMulti={false}
                            star={"*"}
                            // name="Select the Store"
                            width="300px"
                            required={true}
                          />
                          {newAsset && error.store ? (
                            <p
                              style={{
                                paddingLeft: "14px",
                                color: "red",
                                fontSize: "14px",
                              }}
                            >
                              {error.store}
                            </p>
                          ) : null}
                        </Box>
                        <Box
                          className="cusSwiRoleMenuCon"
                          sx={{
                            width: "300px",
                            display: "flex",
                            flexDirection: "row",
                            flexWrap: "wrap",
                            alignItems: "center",
                            justifyContent: "start",
                            padding: "8px",
                          }}
                        >
                          <Label style={{marginBottom:"12px"}}>
                            Brand Name
                            <span
                              style={{
                                paddingLeft: "5px",
                                color: "red",
                                fontSize: "15px",
                              }}
                            >
                              *
                            </span>
                          </Label>
                          <CFormInput
                            id="exampleFormControlInput1"
                            placeholder="Enter Brand Name"
                            value={brandName}
                            onChange={(e) => setBrandName(e.target.value) }
                          />
                          {newAsset && error.brand ? (
                            <p
                              style={{
                                paddingLeft: "14px",
                                color: "red",
                                fontSize: "14px",
                              }}
                            >
                              {error.brand}
                            </p>
                          ) : null}
                        </Box>
                      </Box>
                    </>
                  )}
                </Box>
                <Box
                  mt={"30px"}
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    flexWrap: "wrap",
                    justifyContent: "end",
                  }}
                >
                  <Button
                    type="reset"
                    variant="outlined"
                    aria-label="fingerprint"
                    sx={{ display: "flex", margin: "15px", alignSelf: "left" }}
                    color="primary"
                    onClick={reset}
                  >
                    Reset
                  </Button>
                  <Button
                    variant="contained"
                    aria-label="fingerprint"
                    sx={{ display: "flex", margin: "15px", alignSelf: "left" }}
                    color={"primary"}
                    onClick={handleSubmit}
                  >
                    Submit
                  </Button>
                </Box>
              </Box>
            </div>
          </>
        )}
      </div>
      <Toaster />
      {gridModal && (
        <AccessModel
          gridModal={gridModal}
          setGridModal={setGridModal}
          id={id}
          openUnMap={openUnMap}
          setUserItemForUnMap={setUserItemForUnMap}
          userItemForUnMap={userItemForUnMap}
          setOpenUnMap={setOpenUnMap}
          setAssetsItemForUnMap={setAssetsItemForUnMap} 
          getAccess={getAccess}
          menuId={menuId}
        />
      )}
      {openUnMap && (
        <AssetUnmap menuId={menuId} openUnMap={openUnMap} setOpenUnMap={setOpenUnMap} getAccess={getAccess} userItem={userItemForUnMap} assetItem={assetsItemForUnMap} />
      )}
    </>
  );
};

export default AssetMapping;
