import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {Flex} from "@chakra-ui/react";

import ProfileCard from '../../components/profilecard'
import DashboardCard from 'src/components/DashboardCard' 
// import { 
  // getallAssets,
  //  getAllUsers, getProfile, myProfile } from 'src/utility/apiService'

import CustomTable from 'src/custom/Table';
import { Typography } from 'antd';
const Dashboard = ({user}) => {
  // const [totalWorkingDays, setTotalWorkingDays] = useState(24)
  // const [userFromProfile, setUserFromProfile] = useState({})
  // const [totalLeaveTaken, setTotalLeaveTaken] = useState(2)
  // const [totalAttendence, setTotalAttendence] = useState(totalWorkingDays - totalLeaveTaken)
  // const [data, setData] = useState([])

  // const [assetdata, setAssetData] = useState([])
  // const [profileData, setProfileData] = useState()
  // const [profile, setProfile] = useState()
  // const [column, setColumn] = useState([
  //   {
  //     Header: 'SI No',
  //     id: 'index',
  //     accessor: (row,index) => <div style={{textAlign:"center"}}>{index+1}</div> 
  //   },
  //   {
  //     Header: "First Name",
  //     accessor: "firstName",
  //     disableSortBy: true,
  //     filter: "equals",
  //   },
  //   {
  //     Header: "Last Name",
  //     accessor: "lastName",
  //   },
  //   {
  //     Header: "Email",
  //     accessor: "email",
  //   },
  //   {
  //     Header: "Phone No",
  //     accessor: "mobileNo",
  //   },
  // ])

  // let columns2 = [
  //   {
  //     Header: "SI No",
  //     id: "index",
  //     accessor: (row, index) => (
  //       <div style={{ textAlign: "center" }}>{index + 1}</div>
  //     ),
  //   },
  //   {
  //       Header: "Assets Type",
  //       accessor: "assetsType",
  //   },
  //   {
  //       Header: "Assets Name",
  //       accessor: "assetsName",
  //   },
  //   {
  //       Header: "Assets Code",
  //     accessor: "assetsNumber"
  //   }
  // ];
  // let token = localStorage.getItem("hrmsv2-token");
  // if (token) {
  //   token = JSON.parse(token);
  // }


  // let navigate=useNavigate()
  // useEffect(() => {
  //   let getToken = localStorage.getItem('hrmsv2-token')
  //   let token;
  //   if (getToken) {
  //     token = JSON.parse(getToken)
  //   }
  //   if (!token) {
  //     navigate("/login")
  //   }
  // }, [])

  // useEffect(() => {
  //   let fetch=async()=>{
  //     try {
  //       const Users = await getAllUsers();
  //       const UsersData = Users?.data?.data?.filter((item) => {
  //         return item.isOwner === false;
  //       });
  //       setData(UsersData);
        
  //     } catch (error) {
  //       console.log(error.message);
  //     }
  //     try {
  //       let profile=await getProfile(token)
        
  //       setProfileData(profile.data.data);
  //       if(!profile.ok){
  //         return alert(profile.data.message)
  //       }
  //       let Myprofile=await myProfile(token)
  //        setProfile(Myprofile?.data?.data?.work)
  //     } catch (error) {
  //       console.log(error.message);
  //     }
  //   }

  //   // let asset=async()=>{
  //   //   try {
  //   //     const assets=await getallAssets()
  //   //     const assetsData = assets.data?.data.filter((item) => {
  //   //       return item.isBlock === false;
  //   //     });
  //   //     setAssetData(assetsData)

  //   //   } catch (error) {
  //   //   }
  //   // }
  //   // asset()
  //   fetch()
  // } , [] );

  // let color="#43A047"
  // if(totalLeaveTaken <= 2) color="#43A047"
  // else if(totalLeaveTaken <= 5) color="orange"
  // else if(totalLeaveTaken > 5) color="#e73531"

  return (
    <>
    <h1>Assiganment</h1>
      
    </>
  )
}

export default Dashboard
