import React, { createContext, useEffect, useState } from "react";
import {
  CButton,
  CCard,
  CCardBody,
  CCardImage,
  CCardTitle,
  CContainer,
} from "@coreui/react";
import { Step, StepLabel, Stepper, Typography } from "@material-ui/core";
import { Button } from "@coreui/coreui";
import UserForm from "./forms/UserForm";
import EducationForm from "./forms/EducationForm";
import WorkForm from "./forms/WorkForm";
import DocumentForm from "./forms/DocumentForm";
import Autocomplete, {
  createFilterOptions,
} from "@material-ui/lab/Autocomplete";
import CIcon from "@coreui/icons-react";
import { cilArrowCircleLeft } from "@coreui/icons";
import { MdDashboard, MdPersonAddAlt1 } from "react-icons/md";
import {
  getAddressById,
  getDocumentById,
  getEducationById,
  getExperienceById,
  getFamilyById,
  getUserById,
  getWorkByid,
} from "src/utility/apiService";
import "./styles.css"

const filter = createFilterOptions();
export const Testcase = createContext();
const AddOptions = () => {
  // Our sample dropdown options
  const options = ["candidat1", "candidat2"];

  return (
    <div style={{ marginLeft: "40%", marginTop: "60px" }}>
      <Autocomplete
        filterOptions={(options, params) => {
          const filtered = filter(options, params);
          if (params.inputValue !== "") {
            filtered.push(`Add "${params.inputValue}"`);
          }
          return filtered;
        }}
        selectOnFocus
        clearOnBlur
        handleHomeEndKeys
        options={options}
        renderOption={(option) => option}
        style={{ width: 300 }}
        freeSolo
        renderInput={(params) => (
          <TextField
            {...params}
            label="Introdu nume candidat"
            variant="outlined"
          />
        )}
      />
    </div>
  );
};

export default function Test({ setOpen, useage, id, menuId }) {
  const [activeStep, setActiveStep] = React.useState(0);
  const [skipped, setSkipped] = React.useState(new Set());
  const [error, setError] = useState(false);
  function getSteps() {
    return ["General", "Education", "WorkInfo", "Document"];
  }
console.log("menuIdmAS", menuId);

  const [values, setValue] = useState({
    firstName: "",
    lastName: "",
    email: "",
    dob: "",
    mobileNo: "",
    bloodGroup: "",
    gender: "",
    marriageStatus: "",
    password: "codiis@123",
    Doorno: "",
    streetName: "",
    landmark:"",
    postalCode: null,
    city: "",
    state: "",
    country: "",
    familyMembers: [
      {
        name: "",
        relationship: "",
        occupation: "",
        dob: "",
        adhaarNo: null,
        emergencyContact: null,
      },
    ],
  });

  const [education, setEducation] = useState({
    sslcSchoolName: "",
    sslcBoard: "",
    sslcYearOfPassing: "",
    sslcPercentage: null,

    hscSchoolName: "",
    hscBoard: "",
    hscYearOfPassing: "",
    hscPercentage: null,

    ugInstituteName: "",
    ugUniversityName: "",
    ugYearOfPassing: "",
    ugDepartmentCourse: "",
    ugCgpa: null,

    pgInstituteName: "",
    pgUniversityName: "",
    pgYearOfPassing: "",
    pgDepartmentCourse: "",
    pgCgpa: null,

    phdInstituteName: "",
    phdUniversityName: "",
    phdYearOfPassing: "",
    phdDepartmentCourse: "",
    phdCgpa: null,
  });

  const [work, setWork] = useState({
    department: "",
    designation: "",
    role: "",
    reportedTo: "",
    joiningDate: "",
    salary: null,
    isFresher: true,
    previousCompany: [
      {
        companyName: "",
        designation: "",
        description: "",
        salary: null,
        startDate: "",
        endDate: "",
        experience: "",
      },
    ],
  });

  const [document, setDocument] = useState({
    accountNo: "",
    ifsc: "",
    branch: "",
    bankName: "",
    accountHolderName: "",

    aadhaarNo: "",
    panNo: "",
    passportNo: "",
    uanNo: "",
    pfNo: "",
    esiNo: "",

    vaccination1Date: "",
    vaccination2Date: "",
  });

  useEffect(() => {
    let fetch = async () => {
      let responce = await getUserById(id);
      let data = responce.data.data;
      let valueEdit = {
        ...values,
        ...data,
        bloodGroup: { value: data.bloodGroup, label: data.bloodGroup },
        marriageStatus: {
          value: data.marriageStatus,
          label: data.marriageStatus,
        },
        gender: { value: data.gender, label: data.gender },
      };
        // setValue(valueEdit);

      let add = await getAddressById(id, menuId);
      let addData = add.data.data;
      valueEdit = {
        ...valueEdit,
        ...addData,
      };
      let fam = await getFamilyById(id, menuId);
      let famArr = fam.data.data;
      valueEdit = { ...valueEdit, familyMembers: famArr };
      setValue(valueEdit);

      let edu = await getEducationById(id, menuId);
      let eduData = edu.data.data;
      let eduObj = {
        ...eduData.sslc,
        ...eduData.hsc,
        ...eduData.ug,
        ...eduData.pg,
        ...eduData.phd,
         
      };
      eduObj = {
        ...eduObj,
        sslcBoard: { value: eduObj.sslcBoard, label: eduObj.sslcBoard },
        hscBoard: { value: eduObj.hscBoard, label: eduObj.hscBoard },

      };
      setEducation(eduObj);

      let Documents = await getDocumentById(id,menuId);
      let documentData = Documents.data.data;
      let docObj = {
        ...documentData,
        ...documentData.bankDetails,
        ...documentData.identificationDetails,
        ...documentData.medicalDetails,
      };
      setDocument(docObj);

      let work = await getWorkByid(id, menuId);
      let workData = work.data.data;
      let workEdit = {
        ...work,
        ...workData,
        department: { value: workData.department, label: workData.department },
        designation: {
          value: workData.designation,
          label: workData.designation,
        },
        role: {
          value: workData.roleId.roleName,
          label: workData.roleId.roleName,
        },
        reportedTo: { value: workData.reportedTo, label: workData.reportedTo },
      };
      let experience = await getExperienceById(id, menuId);
      let expData = experience.data.data;
      workEdit = { ...workEdit, previousCompany: expData };
      setWork(workEdit);
    };

    if (!id) {
      setError(true);
    } else {
      setError(false);
    }

    if (useage) {
      fetch();
    }
  }, []);

  function getStepContent(step) {
    switch (step) {
      case 0:
        return (
          <UserForm
            inputValues={values}
            setValue={setValue}
            activeStep={activeStep}
            setActiveStep={setActiveStep}
            errorState={error}
            menuId={menuId}
            useage={useage}
            userId={id}
          />
        );
      case 1:
        return (
          <EducationForm
            eduValues={education}
            setEdu={setEducation}
            activeStep={activeStep}
            setActiveStep={setActiveStep}
            errorState={error}
            menuId={menuId}
            userId={id}
            useage={useage}
          />
        );
      case 2:
        return (
          <WorkForm
            workValues={work}
            setWork={setWork}
            activeStep={activeStep}
            setActiveStep={setActiveStep}
            errorState={error}
            menuId={menuId}
            userId={id}
            useage={useage}
          />
        );
      case 3:
        return (
          <DocumentForm
            activeStep={activeStep}
            setActiveStep={setActiveStep}
            user={values}
            fam={values.familyMembers}
            edu={education}
            work={work}
            exp={work.previousCompany}
            id={id}
            documentValues={document}
            setDocuValues={setDocument}
            open={open}
            setOpen={setOpen}
            useage={useage}
            userId={id}
            errorState={error}
            menuId={menuId}
          />
        );
      default:
        return "Unknown step";
    }
  }

  const steps = getSteps();
  const isStepSkipped = (step) => {
    return skipped.has(step);
  };

  const handleNext = () => {
    let newSkipped = skipped;
    if (isStepSkipped(activeStep)) {
      newSkipped = new Set(newSkipped.values());
      newSkipped.delete(activeStep);
    }

    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    setSkipped(newSkipped);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleReset = () => {
    setActiveStep(0);
  };
  return (
    <CCard className="TestCon" style={{ width: "100%"}}>
      <CCardBody style={{ width: "100%" }}>
        <CContainer style={{ display: "flex", marginLeft: "-0.5rem" }}>
          <CIcon
            icon={cilArrowCircleLeft}
            size="xl"
            style={{ marginTop: "1rem", cursor: "pointer" }}
            onClick={() => setOpen(false)}
          />
          <CCardTitle
            style={{
              fontSize: "1.5rem",
              marginTop: "10px",
              marginLeft: "1rem",
            }}
          >
            {useage ? "Update Employee" : "Create Employee"}
          </CCardTitle>
        </CContainer>
        <div
          style={{
            width: "100%",
            minHeight: "calc(100vh - 190px)",
            backgroundColor: "white",
            marginTop: "3rem",
            borderRadius: "20px",
          }}
        >
          <div>
            <Stepper
              activeStep={activeStep}
              style={{ overflow: "auto"}}
            >
              
              {steps.map((label, index) => {
                const stepProps = {};
                const labelProps = {};
                if (isStepSkipped(index)) {
                  labelProps.optional = (
                    <Typography key={index} variant="caption">
                      Skipped
                    </Typography>
                  );
                }

                return (
                  <Step key={label} {...stepProps} >
                    <StepLabel {...labelProps}
                    //  icon={<MdDashboard color="red" />}  
                    >{label}</StepLabel>
                  </Step>
                );
              })}
            </Stepper>
            <div>
              {activeStep === steps.length ? (
                <div>
                  <Typography>
                    {" "}
                    All steps completed - you&apos;re finished
                  </Typography>
                  <Button onClick={handleReset}>Reset</Button>
                </div>
              ) : (
                <div>
                  <Typography>{getStepContent(activeStep)}</Typography>
                </div>
              )}
            </div>
          </div>
        </div>
      </CCardBody>
    </CCard>
  );
}
