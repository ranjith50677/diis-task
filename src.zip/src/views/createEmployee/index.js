import CIcon from "@coreui/icons-react";
import {
  CButton,
  CCard,
  CCardBody,
  CCardImage,
  CCardTitle,
  CContainer,
  CFormSwitch,
  CFormText,
} from "@coreui/react";
import React, { useContext, useEffect, useState } from "react";
import CustomTable from "src/custom/Table";
import { getAccessForMenu, getAllUsers } from "src/utility/apiService";
import Test from "./Test";
import UserProfile from "src/components/profileViewModal/profileViewModal";
import SwitchButton from "src/custom/SwitchButton";
import { IconContext } from "react-icons/lib";
import { FaEye, FaPen } from "react-icons/fa";
import { EditUserModal } from "./components/EditUserModal";
import moment from "moment";
import { RoleMenuAccessContext } from "src/context/roleMenuContext";
import { Button, Switch } from "@mui/material";
import {HiPencilSquare} from 'react-icons/hi2'

const CraeteEmployee = ({ menuId }) => {
  console.log("menuId", menuId); 
  let roleMenuAccess = useContext(RoleMenuAccessContext);
  const [open, setOpen] = useState(false);
  const [getAccess, setGetAccess] = useState();
  const [userUpopen, setUserUpOpen] = useState(false);
  const [userProfileModal, setUserProfileModal] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [checked, setChecked] = useState(false);
  const [data, setData] = useState([]);
  const [user, setUser] = useState();
  const [userUpId, setUserUpId] = useState();
  const [columnsArr, setColumnsArr] = useState([
    {
      Header: "SI No",
      id: "index",
      accessor: (row, index) => (
        <div style={{ textAlign: "center" }}>{index + 1}</div>
      ),
    },
    {
      Header: "Name",
      accessor: "fullName",
    },
    {
      Header: "Date of Birth",
      accessor: (row, index) => {
        return (
          <div id={"dob_" + index}>
            {!moment(row.dob).isValid()
              ? row.dob
              : moment(row.dob).format("DD-MM-YYYY")}
          </div>
        );
      },
    },
    {
      Header: "Phone Number",
      accessor: "mobileNo",
    },
    {
      Header: "E-Mail",
      accessor: "email",
    },
    {
      Header: "Status",
      accessor: "status",
    },
    {
      Header: "Action",
      accessor: "action",
    },
  ]);

  useEffect(() => {
    let fetchData = async () => {
      try {
        let res = await getAccessForMenu(roleMenuAccess?.roleId, menuId);
        setGetAccess(res.data.data);
        if (
          !res.data.data?.isOwner &&
          res.data.data?.get == false &&
          res.data.data?.update == false
        ) {
          setColumnsArr((pState) =>
            pState.filter((item) => item.Header != "Action")
          );
        }
      } catch (error) {
        console.log(error.message);
      }
    };
    fetchData();
  }, [menuId]);

  const getAllEmployee = async () => {
    try {
      let response = await getAllUsers();
      let arr = [];
      response?.data?.data?.map((item, index) => {
        if (item.isOwner == false) {
          if (item.isBlock == false) {
            arr.push({
              ...item,
              status: (
                <center key={index}>
                  <Switch
                    disabled={!getAccess?.isOwner && getAccess?.update == false}
                    onChange={(e) => {}}
                    checked={item?.isActive}
                    onClick={() => {
                      setChecked(item.isActive);
                      setUser(item);
                      setEditMode(true);
                    }}
                    color="success"
                  />
                </center>
              ),
              fullName: item.firstName + " " + item.lastName,
              action: (
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-evenly",
                    alignItems: "center",
                    marginTop: "10px",
                  }}
                >
                  {getAccess?.isOwner || getAccess?.update ? (
                    <IconContext.Provider
                      value={{ color: "#000" }}
                    >
                      <HiPencilSquare
                        style={{ cursor: "pointer" }}
                        size={20}
                        onClick={() => {
                          setUserUpId(item._id);
                          setUserUpOpen(true);
                        }}
                      />
                  </IconContext.Provider>
                  ) : null}
                  {getAccess?.isOwner || getAccess?.get ? (
                    <IconContext.Provider
                      value={{ color: "#000" }}
                    >
                      <FaEye
                        style={{ cursor: "pointer" }}
                        size={20}
                        onClick={() => {
                          setUser(item);
                          setUserProfileModal(true);
                        }}
                      />
                  </IconContext.Provider>
                  ) : null}
                </div>
              ),
            });
          }
        } else {
          return null;
        }
      });
      setData(arr);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getAllEmployee();
  }, [editMode, getAccess, open, userUpopen]);

  return (
    <>
      {!userUpopen ? (
        !open ? (
          <CCard style={{ width: "100%", minHeight: "calc(100vh - 190px)" ,borderStyle:"none"}}>
            <CCardBody
              style={{ width: "100%", display: "flex", flexDirection: "row" }}
            >
              <CCardTitle style={{ fontSize: "1.5rem" }}>Employee</CCardTitle>
              {getAccess?.create == true || getAccess?.isOwner ? (
                <Button
                variant="contained"
                  color="primary"
                  style={{ marginLeft: "auto", height: "40px" }}
                  onClick={() => setOpen(true)}
                >
                  Create
                </Button>
              ) : null}
            </CCardBody>
            
              <CContainer style={{ maxWidth: "100%", padding: 0,paddingBottom:'400px' }}>
                <CustomTable
                  columns={columnsArr}
                  data={data}
                />
              </CContainer>
          </CCard>
        ) : (
          <Test setOpen={setOpen} open={open}  menuId={menuId} />
        )
      ) : (
        <Test
          setOpen={setUserUpOpen}
          useage="update"
          id={userUpId}
          menuId={menuId}
        />
      )}
      {userProfileModal && (
        <UserProfile
          setUserProfileModal={setUserProfileModal}
          user={user}
          userProfileModal={userProfileModal}
          menuId={menuId}
        />
      )}
      {editMode && (
        <EditUserModal
          setOpen={setEditMode}
          menuId={menuId}
          data={user}
          open={editMode}
        />
      )}
    </>
  );
};

export default CraeteEmployee;
