import React, { useState } from "react";
import {
  MDBBtn,
  MDBModal,
  MDBModalDialog,
  MDBModalContent,
  MDBModalHeader,
  MDBModalTitle,
  MDBModalBody,
  MDBModalFooter,
} from "mdb-react-ui-kit";
import CustomButton from "src/custom/Button";
import CustomSwitch from "src/custom/Switch";
import {  updateUser } from "src/utility/apiService";
import { toast, Toaster } from "react-hot-toast";
import CustomInput from "src/custom/Input";
import { CContainer, CFormInput } from "@coreui/react";
import CIcon from "@coreui/icons-react";
import { Col, Row } from "reactstrap";
import { cilArrowCircleLeft } from "@coreui/icons";
import { Button, Typography } from "@mui/material";
export const EditUserModal = (props) => {
  const { open, setOpen, data } = props;
  const [active, setActive] = useState(data.isActive);
  const [block, setBlock] = useState(data.isBlock);
  const [role, setRole] = useState(data.roleName);
  const toggle = () => setOpen(!open);
  const update = async () => {
    let updates = { isActive: !active };
    try {
      let response = await updateUser(data._id, updates);
      if (!response.ok) {
        return toast.error("User not Updated");
      }
      //   toast.success("User Updated Successfully");
      setOpen(!open);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      <MDBModal show={open} setShow={setOpen} tabIndex="-1">
        <MDBModalDialog centered>
          <MDBModalContent>
            <MDBModalHeader>
              <MDBModalTitle>Update</MDBModalTitle>
              <MDBBtn
                className="btn-close"
                color="none"
                onClick={toggle}
              ></MDBBtn>
            </MDBModalHeader>
            <MDBModalBody>
              <Typography>
                Are you sure you wanna {active == true ? "Block" : "Activate"}
              </Typography>
            </MDBModalBody>

            <MDBModalFooter>
              {/* <CustomButton text="cancel" onClick={toggle} color={"danger"} /> */}
              <Button variant="contained" color="primary"  onClick={update}  >
                {active == true ? "Block" : "Activate"}
              </Button>
            </MDBModalFooter>
          </MDBModalContent>
        </MDBModalDialog>
      </MDBModal>
      <Toaster />
    </>
  );
};
