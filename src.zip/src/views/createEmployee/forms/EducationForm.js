import { CButton, CCard, CCardBody, CCardTitle, CFormSwitch } from "@coreui/react";
import { Button } from "@mui/material";
import React, { useState } from "react";
import {
  Col,
  Container,
  FormGroup,
  Input,
  Label,
  Row,
  Form,
  FormText,
} from "reactstrap";
import CustomSelect from "src/custom/Select";
import "./styles.css"
export default function EducationForm(props) {
  const { activeStep, setActiveStep, eduValues, setEdu } = props;
  /****  ERROR MESSAGE  ***/
  const [sSchoolNameerrorMessage, setSSchoolNameErrorMessage] = useState("");
  const [syoperrorMessage, setSyopErrorMessage] = useState("");
  const [spercenterrorMessage, setSpercentErrorMessage] = useState("");
  const [sboarderrorMessage, setSboardErrorMessage] = useState("");
  const [hsnerrorMessage, setHsnErrorMessage] = useState("");
  const [hyoperrorMessage, setHyopErrorMessage] = useState("");
  const [hpercenterrorMessage, setHpercentErrorMessage] = useState("");
  const [hboarderrorMessage, setHboardErrorMessage] = useState("");
  const [ugunerrorMessage, setUgunErrorMessage] = useState("");
  const [uginerrorMessage, setUginErrorMessage] = useState("");
  const [ugdcerrorMessage, setUgdcErrorMessage] = useState("");
  const [ugyoperrorMessage, setUgyopErrorMessage] = useState("");
  const [ugpererrorMessage, setUgperErrorMessage] = useState("");
  const[pgyoperrormessage,setPgyopErrorMessage]=useState("");
  const[phdyoperrormessage,setPhdyopErrorMessage]=useState("");
  const[pgpererrormessage,setPgperErrorMessage]=useState("");
  const[phdpererrormessage,setPerErrorMessage]=useState("");
  const [ugDepartmentCourseerrorMessage, setugDepartmentCourseErrorMessage] = useState("");
  const blockInvalidChar = e =>{['e', 'E', '+', '-'].includes(e.key) && e.preventDefault()};
  // const A1=()=>{
  //   if(eduValues.sslcPercentage > 100) 
  //       alert("Percentage is required")
  // }
  const [showForm, setShowForm] = useState(false);
  const [showphD, setShowPhD] = useState(false);

  const toggleForm1 = () => {
    setShowForm(!showForm);
    setShowPhD(showphD);
  }
  const toggleForm2 = () => {
    setShowPhD(!showphD);
  }
  const toggleForm3 = () => {
    setShowForm(!showForm);
    setShowPhD(showphD);
  }

  const [sslcBoard, setSslcBoard] = useState([
    { value: "State Board", label: "State Board" },
    { value: "CBSE", label: "CBSE" },
    { value: "ISC", label: "ISC" },
    { value: "ICSE", label: "ICSE" },
    { value: "NIOS", label: "NIOS" },
  ]);
  const [hscBoard, setHscBoard] = useState([
    { value: "State Board", label: "State Board" },
    { value: "CBSE", label: "CBSE" },
    { value: "ISC", label: "ISC" },
    { value: "ICSE", label: "ICSE" },
    { value: "NIOS", label: "NIOS" },
  ]);

  const handelSubmit = (e) => {
    e.preventDefault();
    if (!eduValues.sslcSchoolName) {
      setSSchoolNameErrorMessage("School Name is required");
    } else {
      setSSchoolNameErrorMessage("");
    }
    if (!eduValues.sslcBoard) {
      setSboardErrorMessage("Board is required");
    } else {
      setSboardErrorMessage("");
    }

    if (!eduValues.sslcYearOfPassing) {
      setSyopErrorMessage("Year of Passing is required");
    } 
    else if(eduValues.sslcYearOfPassing.toString().length > 4 || eduValues.sslcYearOfPassing.toString().length < 4 ){
      setSyopErrorMessage("Enter valid year");
    }
    else {
      setSyopErrorMessage("");
    }
    if (!eduValues.sslcPercentage) {
      setSpercentErrorMessage("Percentage is required");   
    } 
    else if( eduValues.sslcPercentage > 100 || eduValues.sslcPercentage < 35){
      setSpercentErrorMessage("Enter Valid percentage");
    }
  else {
      setSpercentErrorMessage("");
    }

    if (!eduValues.hscSchoolName) {
      setHsnErrorMessage("School Name is required");
    } else {
      setHsnErrorMessage("");
    }
    if (!eduValues.hscBoard) {
      setHboardErrorMessage("Board is required");
    } else {
      setHboardErrorMessage("");
    }
    if (!eduValues.hscPercentage) {
      setHpercentErrorMessage("Percentage is required");
    }
    else if(eduValues.hscPercentage > 100 || eduValues.hscPercentage < 33){
      setHpercentErrorMessage("Enter valid percentage");
    } 
    else {
      setHpercentErrorMessage("");
    }
    if (!eduValues.hscYearOfPassing) {
      setHyopErrorMessage("Year of Passing is required");
    } 
    else if(eduValues.hscYearOfPassing.toString().length > 4 || eduValues.hscYearOfPassing.toString().length < 4  ){
      setHyopErrorMessage("Enter valid year");
    }
    else {
      setHyopErrorMessage("");
    }
    if (!eduValues.ugUniversityName) {
      setUgunErrorMessage("University Name is required");
    } else {
      setUgunErrorMessage("");
    }
    if (!eduValues.ugInstituteName) {
      setUginErrorMessage("Institute Name is required");
    } else {
      setUginErrorMessage("");
    }
    if (!eduValues.ugYearOfPassing) {
      setUgyopErrorMessage("Year of Passing is required");
    } 
    else if(eduValues.ugYearOfPassing < 1000 || eduValues.ugYearOfPassing > 9999  ){
      setUgyopErrorMessage("Enter valid year");
    }
    else {
      setUgyopErrorMessage("");
    }
    if (!eduValues.ugCgpa) {
      setUgperErrorMessage("Percentage is required");
      }  
      else if(eduValues.ugCgpa > 100){
        setUgperErrorMessage("Enter valid percentage");
      }
    else {
      setUgperErrorMessage("");
    }
    if (!eduValues.ugDepartmentCourse) {
      setugDepartmentCourseErrorMessage("Course is required");
    } else {
      setugDepartmentCourseErrorMessage("");
    }
    if(eduValues.pgYearOfPassing < 1000  || eduValues.pgYearOfPassing > 9999 ){
      setPgyopErrorMessage("Enter valid year");
    }
    else {
      setPgyopErrorMessage("");
    }
    if(eduValues.pgCgpa > 100  ){
      setPgperErrorMessage("Enter valid percentage");
    }
    else {
      setPgperErrorMessage("");
    }
    if(eduValues.phdYearOfPassing < 1000 || eduValues.phdYearOfPassing > 9999  ){
      setPhdyopErrorMessage("Enter valid Year");
    }
    else {
      setPhdyopErrorMessage("");
    }
    if(eduValues.phdCgpa > 100  ){
      setPerErrorMessage("Enter valid percentage");
    }
    else {
      setPerErrorMessage("");
    }
    if (
      !eduValues.sslcSchoolName ||
      !eduValues.sslcBoard ||
      !eduValues.sslcYearOfPassing ||
      !eduValues.sslcPercentage ||
      !eduValues.hscSchoolName ||
      !eduValues.hscBoard ||
      !eduValues.hscPercentage ||
      !eduValues.hscYearOfPassing ||
      !eduValues.ugUniversityName ||
      !eduValues.ugInstituteName ||
      !eduValues.ugDepartmentCourse ||
      !eduValues.ugYearOfPassing ||
      !eduValues.ugCgpa
    ) {
      console.log("error");
    } else {
      setActiveStep(activeStep + 1);
    }
  };
  return (
    <CCard>
      <Container style={{ padding: "20px" }}>
        <Form>
          {/* *********************************************** Sslc *************************************************** */}
          <h4>SSLC</h4>
          <hr style={{ padding: "5px"}}></hr>
          <Row  style={{  display:"flex",padding:"5px"}} >
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>
                  School / Universty Name
                  <span
                    style={{
                      paddingLeft: "5px",
                      color: "red",
                      fontSize: "15px",
                    }}
                  >
                    *
                  </span>
                </Label>
                <Input
                  type="text"
                  placeholder="School / Universty Name"
                  value={eduValues.sslcSchoolName}
                  onChange={(e) =>
                    setEdu({ ...eduValues, sslcSchoolName: e.target.value })
                  }
                />
                {sSchoolNameerrorMessage ? (
                  <Label
                    className="error"
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                  >
                    {" "}
                    {sSchoolNameerrorMessage}{" "}
                  </Label>
                ) : null}
              </FormGroup>
            </Col>
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>
                  Board
                  <span
                    style={{
                      paddingLeft: "5px",
                      color: "red",
                      fontSize: "15px",
                    }}
                  >
                    *
                  </span>
                </Label>
                <CustomSelect
                  option={sslcBoard}
                  selectedOptions={eduValues.sslcBoard} 
                  setSelectedOptions={(e) =>
                    setEdu({ ...eduValues, sslcBoard: e })
                  }
                  isSearchable={true}
                  isMulti={false}
                />
                {sboarderrorMessage && (
                  <Label
                    className="error"
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                  >
                    {" "}
                    {sboarderrorMessage}{" "}
                  </Label>
                )}
              </FormGroup>
            </Col>
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>
                  Year Of Passing
                  <span
                    style={{
                      paddingLeft: "5px",
                      color: "red",
                      fontSize: "15px",
                    }}
                  >
                    *
                  </span>
                </Label>
                <Input
                  type="number"
                  min={0}
                  placeholder="Year Of Passing"
                  onKeyDown={blockInvalidChar}
                  value={eduValues.sslcYearOfPassing}
                  onChange={(e) =>
                    setEdu({ ...eduValues, sslcYearOfPassing: e.target.value })
                  }
                />
                {syoperrorMessage && (
                  <Label
                    className="error"
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                  >
                    {" "}
                    {syoperrorMessage}{" "}
                  </Label>
                )}
              </FormGroup>
            </Col>            
          </Row>
          <Row  style={{  display:"flex",padding:"5px"}} >         
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>
                  Percentage
                  <span
                    style={{
                      paddingLeft: "5px",
                      color: "red",
                      fontSize: "15px",
                    }}
                  >
                    *
                  </span>
                </Label>
                <Input
                  type="number"
                  min={0}
                  max={100}
                  placeholder="Percentage"
                  onKeyDown={blockInvalidChar}
                  value={eduValues.sslcPercentage}
                  onChange={(e) =>
                    setEdu({ ...eduValues, sslcPercentage: e.target.value })
                  }
                />
                {spercenterrorMessage && (
                  <Label
                    className="error"
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                  >
                    {" "}
                    {spercenterrorMessage}{" "}
                  </Label>
                )}
              </FormGroup>
            </Col>
            
          </Row>
          
          {/* *********************************************** Hsc *************************************************** */}
          <h4>HSC</h4>
          <hr style={{ padding: "5px"}}></hr>
          <Row  style={{  display:"flex",padding:"5px"}} >
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>
                  School / Universty Name
                  <span
                    style={{
                      paddingLeft: "5px",
                      color: "red",
                      fontSize: "15px",
                    }}
                  >
                    *
                  </span>
                </Label>
                <Input
                  type="text"
                  placeholder="School/Universty Name"
                  value={eduValues.hscSchoolName}
                  onChange={(e) =>
                    setEdu({ ...eduValues, hscSchoolName: e.target.value })
                  }
                />
                {hsnerrorMessage && (
                  <Label
                    className="error"
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                  >
                    {" "}
                    {hsnerrorMessage}{" "}
                  </Label>
                )}
              </FormGroup>
            </Col>
            <Col md={4} className="CreateEmpInpCon" >
              <FormGroup>
                <Label>
                  Board
                  <span
                    style={{
                      paddingLeft: "5px",
                      color: "red",
                      fontSize: "15px",
                    }}
                  >
                    *
                  </span>
                </Label>
                <CustomSelect
                  option={hscBoard}
                  selectedOptions={eduValues.hscBoard}
                  setSelectedOptions={(e) =>
                    setEdu({ ...eduValues, hscBoard: e })
                  }
                  isSearchable={true}
                  isMulti={false}
                />
                {hboarderrorMessage && (
                  <Label
                    className="error"
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                  >
                    {" "}
                    {hboarderrorMessage}{" "}
                  </Label>
                )}
              </FormGroup>
            </Col>
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>
                  Year Of Passing
                  <span
                    style={{
                      paddingLeft: "5px",
                      color: "red",
                      fontSize: "15px",
                    }}
                  >
                    *
                  </span>
                </Label>
                <Input
                  type="text"
                  placeholder="Year Of Passing"
                  value={eduValues.hscYearOfPassing}
                  onChange={(e) =>
                    setEdu({ ...eduValues, hscYearOfPassing: e.target.value })
                  }
                />
                {hyoperrorMessage && (
                  <Label
                    className="error"
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                  >
                    {" "}
                    {hyoperrorMessage}{" "}
                  </Label>
                )}
              </FormGroup>
            </Col>
            
          </Row>
          <Row  style={{  display:"flex",padding:"5px"}} >
         
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>
                  Percentage
                  <span
                    style={{
                      paddingLeft: "5px",
                      color: "red",
                      fontSize: "15px",
                    }}
                  >
                    *
                  </span>
                </Label>
                <Input
                  type="number"
                  min={0}
                  // max={100}
                  // maxLength = {5}
                  placeholder="Percentage"
                  value={eduValues.hscPercentage}
                  onKeyDown={blockInvalidChar}
                  onChange={(e) =>
                    setEdu({ ...eduValues, hscPercentage: e.target.value })
                  }
                />
                {hpercenterrorMessage && (
                  <Label
                    className="error"
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                  >
                    {" "}
                    {hpercenterrorMessage}{" "}
                  </Label>
                )}
              </FormGroup>
            </Col>
            
          </Row>
          
          {/* *********************************************** Under Graduate *************************************************** */}
          <h4>Under Graduate</h4>
          <hr style={{ padding: "5px"}}></hr>
          <Row  style={{  display:"flex",padding:"5px"}} >
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>
                  College Name
                  <span
                    style={{
                      paddingLeft: "5px",
                      color: "red",
                      fontSize: "15px",
                    }}
                  >
                    *
                  </span>
                </Label>
                <Input
                  type="text"
                  placeholder="College Name"
                  value={eduValues.ugInstituteName}
                  onChange={(e) =>
                    setEdu({ ...eduValues, ugInstituteName: e.target.value })
                  }
                />
                {uginerrorMessage && (
                  <Label
                    className="error"
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                  >
                    {" "}
                    {uginerrorMessage}{" "}
                  </Label>
                )}
              </FormGroup>
            </Col>
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>
                  University
                  <span
                    style={{
                      paddingLeft: "5px",
                      color: "red",
                      fontSize: "15px",
                    }}
                  >
                    *
                  </span>
                </Label>
                <Input
                  type="text"
                  placeholder="Universty"
                  value={eduValues.ugUniversityName}
                  onChange={(e) =>
                    setEdu({ ...eduValues, ugUniversityName: e.target.value })
                  }
                />

                {ugunerrorMessage && (
                  <Label
                    className="error"
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                  >
                    {" "}
                    {ugunerrorMessage}{" "}
                  </Label>
                )}
              </FormGroup>
            </Col>
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>
                  Course
                  <span
                    style={{
                      paddingLeft: "5px",
                      color: "red",
                      fontSize: "15px",
                    }}
                  >
                    *
                  </span>
                </Label>
                <Input
                  type="text"
                  placeholder="Course"
                  value={eduValues.ugDepartmentCourse}
                  onChange={(e) =>
                    setEdu({ ...eduValues, ugDepartmentCourse: e.target.value })
                  }
                />
                {ugDepartmentCourseerrorMessage && (
                  <Label
                    className="error"
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                  >
                    {" "}
                    {ugDepartmentCourseerrorMessage}{" "}
                  </Label>
                )}
              </FormGroup>
            </Col>
            
          </Row>
          <Row  style={{ display:"flex",padding:"5px"}} >
          
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>
                  Year Of Passing
                  <span
                    style={{
                      paddingLeft: "5px",
                      color: "red",
                      fontSize: "15px",
                    }}
                  >
                    *
                  </span>
                </Label>
                <Input
                  type="number"
                  min={0}
                  onKeyDown={blockInvalidChar}
                  placeholder="Year Of Passing"
                  value={eduValues.ugYearOfPassing}
                  onChange={(e) =>
                    setEdu({ ...eduValues, ugYearOfPassing: e.target.value })
                  }
                />
                {ugyoperrorMessage && (
                  <Label
                    className="error"
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                  >
                    {" "}
                    {ugyoperrorMessage}{" "}
                  </Label>
                )}
              </FormGroup>
            </Col>

            <Col md={4} className="CreateEmpInpCon" >
              <FormGroup>
                <Label>
                  Percentage
                  <span
                    style={{
                      paddingLeft: "5px",
                      color: "red",
                      fontSize: "15px",
                    }}
                  >
                    *
                  </span>
                </Label>
                <Input
                  type="number"
                  min={0}
                  max={100}
                  placeholder="Percentage"
                  onKeyDown={blockInvalidChar}
                  value={eduValues.ugCgpa}
                  onChange={(e) =>
                    setEdu({ ...eduValues, ugCgpa: e.target.value })
                  }
                />
                {ugpererrorMessage && (
                  <Label
                    className="error"
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                  >
                    {" "}
                    {ugpererrorMessage}{" "}
                  </Label>
                )}
              </FormGroup>
            </Col>
          </Row>
          
          {/* //-------------------------------------------- PG --------------------------------------------// */}
          <Row>
            <Col md={4}>
              <FormGroup style={{ display: "flex", alignItems: "center" }}>
                <CFormSwitch
                  className={"mx-1"}
                  variant={"3d"}
                  color={"primary"}
                  onClick={toggleForm1}             
                />
                <Label style={{ marginTop: "6px" }}>
                  
                  {/* {showForm ? 'PostGraduate' : 'PostGraduate'} */}
                  PG
                </Label>
              </FormGroup>
            </Col>
          </Row>
          {showForm && (
            <div>
          <h4>PostGraduate</h4>
          <hr style={{ padding: "5px"}}></hr>
          <Row  style={{  display:"flex",padding:"5px"}} >
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>College Name</Label>
                <Input
                  type="text"
                  placeholder="College Name"
                  value={eduValues.pgInstituteName}
                  onChange={(e) =>
                    setEdu({ ...eduValues, pgInstituteName: e.target.value })
                  }
                />
              </FormGroup>
            </Col>
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>Universty</Label>
                <Input
                  type="text"
                  placeholder="Universty"
                  value={eduValues.pgUniversityName}
                  onChange={(e) =>
                    setEdu({ ...eduValues, pgUniversityName: e.target.value })
                  }
                />
              </FormGroup>
            </Col>
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>Course</Label>
                <Input
                  type="text"
                  placeholder="Course"
                  value={eduValues.pgDepartmentCourse}
                  onChange={(e) =>
                    setEdu({ ...eduValues, pgDepartmentCourse: e.target.value })
                  }
                />
              </FormGroup>
            </Col>
          </Row>
          <Row  style={{  display:"flex",padding:"5px"}} >
          
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>Year Of Passing</Label>
                <Input
                  type="number"
                  min={0}
                  onKeyDown={blockInvalidChar}
                  placeholder="Year Of Passing"
                  value={eduValues.pgYearOfPassing}
                  onChange={(e) =>
                    setEdu({ ...eduValues, pgYearOfPassing: e.target.value })
                  }
                />
                {pgyoperrormessage ? (
                    <FormText
                      style={{
                        paddingLeft: "14px",
                        color: "red",
                        fontSize: "14px",
                      }}
                      color="red"
                    >
                      {pgyoperrormessage}
                    </FormText>
                  ) : null}
              </FormGroup>
            </Col>

            <Col md={4} className="CreateEmpInpCon" >
              <FormGroup>
                <Label>Percentage</Label>
                <Input
                  type="number"
                  min={0}
                  max={100}
                  onKeyDown={blockInvalidChar}
                  placeholder="Percentage"
                  value={eduValues.pgCgpa}
                  onChange={(e) =>
                    setEdu({ ...eduValues, pgCgpa: e.target.value })
                  }
                />
                {pgpererrormessage ? (
                    <FormText
                      style={{
                        paddingLeft: "14px",
                        color: "red",
                        fontSize: "14px",
                      }}
                      color="red"
                    >
                      {pgpererrormessage}
                    </FormText>
                  ) : null}
              </FormGroup>
            </Col>
          </Row>
           {/* //-------------------------------------------- PHD--------------------------------------------// */}
          <Row>
            <Col md={4}>
              <FormGroup style={{ display: "flex", alignItems: "center" }}>
                <CFormSwitch
                  className={"mx-1"}
                  variant={"3d"}
                  color={"primary"}
                  onClick={toggleForm2}             
                />
                <Label style={{ marginTop: "6px" }}>
                  
                  {/* {showForm ? 'PostGraduate' : 'PostGraduate'} */}
                  PHD
                </Label>
              </FormGroup>
            </Col>
          </Row>
       
       {showphD && (
            <div>
          <h4>Doctor of Philosophy</h4>
          <hr style={{ padding: "5px"}}></hr>
          <Row  style={{  display:"flex",padding:"5px"}} >
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>College Name</Label>
                <Input
                  type="text"
                  placeholder="College Name"
                  value={eduValues.phdUniversityName}
                  onChange={(e) =>
                    setEdu({ ...eduValues, phdUniversityName: e})
                  }
                />
              </FormGroup>
            </Col>
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>Universty</Label>
                <Input
                  type="text"
                  placeholder="Universty"
                  value={eduValues.phdInstituteName}
                  onChange={(e) =>
                    setEdu({ ...eduValues,phdInstituteName: e.target.value })
                  }
                />
              </FormGroup>
            </Col>
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>Course</Label>
                <Input
                  type="text"
                  placeholder="Course"
                  value={eduValues.phdDepartmentCourse}
                  onChange={(e) =>
                    setEdu({ ...eduValues, phdDepartmentCourse: e.target.value })
                  }
                />
              </FormGroup>
            </Col>
          </Row>
          <Row  style={{  display:"flex",padding:"5px"}} >
          
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>Year Of Passing</Label>
                <Input
                  type="number"
                  min={0}
                  onKeyDown={blockInvalidChar}
                  placeholder="Year Of Passing"
                  value={eduValues.phdYearOfPassing}
                  onChange={(e) =>
                    setEdu({ ...eduValues, phdYearOfPassing: e.target.value })
                  }
                />
                 {phdyoperrormessage ? (
                    <FormText
                      style={{
                        paddingLeft: "14px",
                        color: "red",
                        fontSize: "14px",
                      }}
                      color="red"
                    >
                      {phdyoperrormessage}
                    </FormText>
                  ) : null}
              </FormGroup>
            </Col>

            <Col md={4} className="CreateEmpInpCon" >
              <FormGroup>
                <Label>Percentage</Label>
                <Input
                  type="number"
                  min={0}
                  max={100}
                  onKeyDown={blockInvalidChar}
                  placeholder="Percentage"
                  value={eduValues.phdCgpa}
                  onChange={(e) =>
                    setEdu({ ...eduValues, phdCgpa: e.target.value })
                  }
                />
                 {phdpererrormessage ? (
                    <FormText
                      style={{
                        paddingLeft: "14px",
                        color: "red",
                        fontSize: "14px",
                      }}
                      color="red"
                    >
                      {phdpererrormessage}
                    </FormText>
                  ) : null}
              </FormGroup>
            </Col>
          </Row>
          </div>
          )}
          </div>
          )}
          
          <FormGroup style={{ float: "right" }}>
            {/* <Input id="exampleCheck" name="check" type="checkbox" /> */}
            <Button variant="outlined" color="primary" onClick={() => setActiveStep(activeStep - 1)}>Back</Button>

            <Button
              variant="contained"
              color="primary"
              style={{ marginLeft: "5px" }}
              // onClick={()=>setActiveStep(activeStep + 1)}
              onClick={handelSubmit}
            >
              Next
            </Button>
          </FormGroup>
        </Form>
      </Container>
    </CCard>
  );
}
