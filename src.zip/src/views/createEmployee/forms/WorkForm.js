import { CButton, CCard, CFormSwitch } from "@coreui/react";
import { RadioGroup } from "@material-ui/core";
import { Button } from "@mui/material";
import React, { useEffect, useState } from "react";
import { IconContext } from "react-icons";
import { FaMinus, FaPlus } from "react-icons/fa";
import moment from "moment";
import {
  Col,
  Container,
  Form,
  FormGroup,
  Input,
  Label,
  Row,
  FormText,
} from "reactstrap";
import CustomDatePicker from "src/custom/Datepicker";
import CustomSelect from "src/custom/Select";
import { getallDep, getallDes, getallRole, getAllUsers } from "src/utility/apiService";
import "./styles.css";
export default function WorkForm(props) {
  const { activeStep, setActiveStep, workValues, setWork, errorState, menuId } = props;
  const [department, setDepartment] = useState("");
  const [designation, setDesignation] = useState("");
  const [role, setRole] = useState({});
  const [reportTo, setReportTo] = useState([]);
  const blockInvalidChar = e => ['e', 'E', '+', '-'].includes(e.key) && e.preventDefault();
  const [deptError, setDeptError] = useState("");
  const [desigError, setDesigError] = useState("");
  const [roleError, setRoleError] = useState("");
  const [reportError, setReportError] = useState("");
  const [joinDateError, setJoinDateError] = useState("");
  const [salaryError, setSalaryError] = useState("");

  const [cNameError, setcNameError] = useState("");
  const [cDesigError, setcDesigError] = useState("");
  const [cDescriptionError, setcDescriptionError] = useState("");
  const [cSalaryError, setcSalaryError] = useState("");
  const [cJoinDateError, setcJoinDateError] = useState("");
  const [cEndDateError, setcEndDateError] = useState("");
  const [cExpError, setcExpError] = useState("");

  const handleCompany = (e, index) => {
    const { name, value } = e.target;
    const list = [...workValues.previousCompany];
    list[index][name] = value;
    setWork((prev) => ({
      ...prev,
      previousCompany: list,
      
    }));
  };

  const handleDeptDesignRole = async () => {
    const Dep = await getallDep();
    const DepData = Dep.data?.data?.filter((item) => {
      return item.isBlock === false;
    });

    setDepartment(
      DepData.map((item) => {
        return {
          value: item.deptName || "",
          label: item.deptName || "",
          depId: item._id || "",
        };
      })
    );

    let desig = await getallDes();
    const desigData = desig.data?.data.filter((item) => {
      return (
        item.departmentId === workValues.department?.depId &&
        item.isBlock === false
      );
    });
    if (workValues.department) {
      // setDesignation("xyz")
      setDesignation(
        desigData?.map((item) => {
          return {
            value: item.designationName || "",
            label: item.designationName || "",
            desigId: item._id || "",
          };
        })
      );
    }

    const Role = await getallRole();
    const RoleData = Role.data?.data?.filter((item) => {
      return item.isBlock === false;
    });
    setRole(
      RoleData.map((item) => {
        return {
          value: item.roleName || "",
          label: item.roleName || "",
          roleId: item._id || "",
        };
      })
    );
  };
  

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (errorState) {
      if (!workValues.department?.value) {
        setDeptError("Department is required");
      } else {
        setDeptError("");
      }
      if (!workValues.designation) {
        setDesigError("Designation is required");
      } else {
        setDesigError("");
      }
      if (!workValues.role) {
        setRoleError("Role is required");
      } else {
        setRoleError("");
      }
      if (!workValues.reportedTo) {
        setReportError("Reported To is required");
      } else {
        setReportError("");
      }
      if (!workValues.joiningDate) {
        setJoinDateError("Joining Date is required");
      } else {
        setJoinDateError("");
      }
      if (!workValues.salary) {
        setSalaryError("Salary is required");
      } else {
        setSalaryError("");
      }
      if (workValues.isFresher === false) {
        workValues.previousCompany.map((item, index) => {
          if (!item.companyName) {
            setcNameError("Company Name is required");
          } else {
            setcNameError("");
          }
          if (!item.designation) {
            setcDesigError("Designation is required");
          } else {
            setcDesigError("");
          }
          if (!item.description) {
            setcDescriptionError("Description is required");
          } else {
            setcDescriptionError("");
          }
          if (!item.salary) {
            setcSalaryError("Salary is required");
          } else {
            setcSalaryError("");
          }
          if (!item.startDate) {
            setcJoinDateError("Joining Date is required");
          } else {
            setcJoinDateError("");
          }
          if (!item.endDate) {
            setcEndDateError("End Date is required");
          } else {
            setcEndDateError("");
          }
          if (!item.experience) {
            setcExpError("Experience is required");
          } else {
            setcExpError("");
          }
        });
      }

      if (errorState) {
        if (
          !workValues.department?.value ||
          !workValues.designation?.value ||
          !workValues.role?.value ||
          !workValues.reportedTo?.value ||
          !workValues.joiningDate ||
          // !workValues.salary||
          (workValues.isFresher === false &&
            workValues.previousCompany.some(
              (item) =>
                item.companyName === "" ||
                item.designation === "" ||
                item.description === "" ||
                item.salary === "" ||
                item.joiningDate === "" ||
                item.endDate === "" ||
                item.experience === ""
            ))
        ) {
          console.log("error");
        } else {
          setActiveStep((prev) => prev + 1);
        }
      } else {
        setActiveStep((prev) => prev + 1);
      }
    } else {
      setActiveStep((prev) => prev + 1);
    }
  };
  let fetch=async()=>{
    try {
      const Users = await getAllUsers();
      setReportTo(
        Users.map((item) => {
          return {
            value: item.firstName+ " " + item.lastName|| "",
            label: item.firstName+ " " + item.lastName || ""
          };
        })
      );
      
    } catch (error) {
      console.log(error.message);
    } 
  }
  
  useEffect(() => {
    handleDeptDesignRole();
  }, [workValues.department]);

  return (
    <CCard>
      <Container style={{ padding: "20px" }}>
        <Form>
          <h4>Work Info</h4>
          <hr style={{ padding: "5px" }}></hr>
          <Row style={{ display: "flex", padding: "5px" }}>
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>Department</Label>
                <span
                  style={{
                    paddingLeft: "5px",
                    color: "red",
                    fontSize: "15px",
                  }}
                >
                  *
                </span>
                <CustomSelect
                  option={department}
                  selectedOptions={workValues.department}
                  setSelectedOptions={(e) =>
                    setWork({ ...workValues, department: e })
                  }
                  isSearchable={true}
                  isMulti={false}
                />
                {deptError ? (
                  <FormText
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                    color="red"
                  >
                    {deptError}
                  </FormText>
                ) : null}
              </FormGroup>
            </Col>
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>Designation</Label>
                <span
                  style={{
                    paddingLeft: "5px",
                    color: "red",
                    fontSize: "15px",
                  }}
                >
                  *
                </span>
                <CustomSelect
                  option={designation}
                  selectedOptions={workValues.designation}
                  setSelectedOptions={(e) =>
                    setWork({ ...workValues, designation: e })
                  }
                  isSearchable={true}
                  isMulti={false}
                />
                {desigError ? (
                  <FormText
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                    color="red"
                  >
                    {desigError}
                  </FormText>
                ) : null}
              </FormGroup>
            </Col>
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>Role</Label>
                <span
                  style={{
                    paddingLeft: "5px",
                    color: "red",
                    fontSize: "15px",
                  }}
                >
                  *
                </span>
                <CustomSelect
                  option={role}
                  selectedOptions={workValues.role}
                  setSelectedOptions={(e) =>
                    setWork({ ...workValues, role: e })
                  }
                  isSearchable={true}
                  isMulti={false}
                />
                {roleError ? (
                  <FormText
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                    color="red"
                  >
                    {roleError}
                  </FormText>
                ) : null}
              </FormGroup>
            </Col>
          </Row>
          <Row style={{ display: "flex", padding: "5px" }}>
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>Reported To</Label>
                <span
                  style={{
                    paddingLeft: "5px",
                    color: "red",
                    fontSize: "15px",
                  }}
                >
                  *
                </span>
                <CustomSelect
                  option={reportTo}
                  selectedOptions={workValues.reportedTo}
                  setSelectedOptions={(e) =>
                    setWork({ ...workValues, reportedTo: e })
                  }
                  isSearchable={true}
                  isMulti={false}
                />
                {reportError ? (
                  <FormText
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                    color="red"
                  >
                    {reportError}
                  </FormText>
                ) : null}
              </FormGroup>
            </Col>
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>Joining Date</Label>
                <span
                  style={{
                    paddingLeft: "5px",
                    color: "red",
                    fontSize: "15px",
                  }}
                >
                  *
                </span>
                {/* <Input
                  type="date"
                  value={workValues.joiningDate}
                  onChange={(e) =>
                    setWork({ ...workValues, joiningDate: e.target.value })
                  }
                /> */}
                <CustomDatePicker
                  wrapperClassName="datepicker"
                  className="form-control"
                  dateFormat="dd/MM/yyyy"
                  // selected={inputValues.dob}
                  selected={
                    workValues.joiningDate
                      ? new Date(workValues.joiningDate)
                      : ""
                  }
                  onChange={(date) =>
                    setWork({ ...workValues, joiningDate: date })
                  }
                />
                {joinDateError ? (
                  <FormText
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                    color="red"
                  >
                    {joinDateError}
                  </FormText>
                ) : null}
              </FormGroup>
            </Col>
            <Col md={4} className="CreateEmpInpCon">
              <FormGroup>
                <Label>Salary</Label>
                <Input
                  type="number"
                  placeholder="₹"
                  value={workValues.salary}
                  onChange={(e) =>
                    setWork({ ...workValues, salary: e.target.value })
                  }
                />
                {salaryError ? (
                  <FormText
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                    color="red"
                  >
                    {salaryError}
                  </FormText>
                ) : null}
              </FormGroup>
            </Col>
          </Row>
          <Row>
            <Col md={4}>
              <FormGroup style={{ display: "flex", alignItems: "center" }}>
                <CFormSwitch
                  className={"mx-1"}
                  variant={"3d"}
                  color={"primary"}
                  checked={workValues.isFresher}
                  onChange={(e) =>
                    setWork({ ...workValues, isFresher: e.target.checked })
                  }
                />
                <Label style={{ marginTop: "6px" }}>
                  Are you a fresher
                  <span
                    style={{
                      paddingLeft: "5px",
                      color: "red",
                      fontSize: "15px",
                    }}
                  >
                    *
                  </span>
                </Label>
              </FormGroup>
            </Col>
          </Row>
          {!workValues.isFresher && (
            <>
              <Row>
                <Col md={12}>
                  <FormGroup>
                    <IconContext.Provider
                      value={{ color: "black", size: "20px" }}
                    >
                      <FaPlus
                        style={{ float: "right", cursor: "pointer" }}
                        onClick={() => {
                          setWork({
                            ...workValues,
                            previousCompany: [
                              ...workValues.previousCompany?.length > 0
                                ? workValues.previousCompany
                                : [],
                                {
                                  companyName: "",
                                  designation: "",
                                  description: "",
                                  salary: null,
                                  startDate: "",
                                  endDate: "",
                                  experience: "",
                                },
                            ]
                          });
                        }}
                      />
                    </IconContext.Provider>
                  </FormGroup>
                </Col>
              </Row>
              {workValues?.previousCompany?.map((item, index) => {
                return (
                  <div key={index}>
                    <h4>Experience Details</h4>
                    <hr style={{ padding: "5px" }}></hr>
                    <Row>
                      {index < 1 ? (
                        <Col md={4}>
                          <FormGroup>
                            <h5>Company {index + 1}</h5>
                          </FormGroup>
                        </Col>
                      ) : (
                        <div>
                          <Col md={4}>
                            <FormGroup>
                              <h5>Company {index + 1}</h5>
                            </FormGroup>
                          </Col>
                          <Col md={12}>
                            <IconContext.Provider
                              value={{ color: "black", size: "20px" }}
                            >
                              <FaMinus
                                style={{ float: "right", cursor: "pointer" }}
                                onClick={() => {
                                  setWork({
                                    ...workValues,
                                    previousCompany:
                                      workValues.previousCompany.filter(
                                        (item, i) => i !== index
                                      ),
                                  });
                                }}
                              />
                            </IconContext.Provider>
                          </Col>
                        </div>
                      )}
                    </Row>
                    <Row style={{ display: "flex", padding: "5px" }}>
                      <Col md={4}>
                        <FormGroup>
                          <Label>Company Name</Label>
                          <Input
                            type="text"
                            placeholder="company Name"
                            name="companyName"
                            value={item.companyName}
                            onChange={(e) => handleCompany(e, index)}
                          />
                          {cNameError ? (
                            <FormText
                              style={{
                                paddingLeft: "14px",
                                color: "red",
                                fontSize: "14px",
                              }}
                              color="red"
                            >
                              {cNameError}
                            </FormText>
                          ) : null}
                        </FormGroup>
                      </Col>
                      <Col md={4} className="CreateEmpInpCon">
                        <FormGroup>
                          <Label>Designation</Label>
                          <Input
                            type="text"
                            placeholder="Designation"
                            name="designation"
                            value={item.designation}
                            onChange={(e) => handleCompany(e, index)}
                          />
                          {cDesigError ? (
                            <FormText
                              style={{
                                paddingLeft: "14px",
                                color: "red",
                                fontSize: "14px",
                              }}
                              color="red"
                            >
                              {cDesigError}
                            </FormText>
                          ) : null}
                        </FormGroup>
                      </Col>
                      <Col md={4} className="CreateEmpInpCon">
                        <FormGroup>
                          <Label>Description</Label>
                          <Input
                            type="text"
                            placeholder="Description"
                            name="description"
                            value={item.description}
                            onChange={(e) => handleCompany(e, index)}
                          />
                          {cDescriptionError ? (
                            <FormText
                              style={{
                                paddingLeft: "14px",
                                color: "red",
                                fontSize: "14px",
                              }}
                              color="red"
                            >
                              {cDescriptionError}
                            </FormText>
                          ) : null}
                        </FormGroup>
                      </Col>
                    </Row>
                    <Row style={{ display: "flex", padding: "5px" }}>
                      <Col md={4} className="CreateEmpInpCon">
                        <FormGroup>
                          <Label>Salary</Label>
                          <Input
                            type="number"
                            onKeyDown={blockInvalidChar}
                            placeholder="₹"
                            name="salary"
                            value={item.salary}
                            onChange={(e) => handleCompany(e, index)}
                          />
                          {cSalaryError ? (
                            <FormText
                              style={{
                                paddingLeft: "14px",
                                color: "red",
                                fontSize: "14px",
                              }}
                              color="red"
                            >
                              {cSalaryError}
                            </FormText>
                          ) : null}
                        </FormGroup>
                      </Col>
                      <Col md={4} className="CreateEmpInpCon">
                        <FormGroup>
                          <Label>Start Date</Label>
                          <CustomDatePicker
                            wrapperClassName="datepicker"
                            className="form-control"
                            dateFormat="dd/MM/yyyy"
                            selected={
                              item.startDate ? new Date(item.startDate) : ""
                            }
                            onChange={(date) => {
                              handleCompany(
                                {
                                  target: {
                                    name: "startDate",
                                    value: date,
                                  },
                                },
                                index
                              );
                            }}
                          />
                          {cJoinDateError ? (
                            <FormText
                              style={{
                                paddingLeft: "14px",
                                color: "red",
                                fontSize: "14px",
                              }}
                              color="red"
                            >
                              {cJoinDateError}
                            </FormText>
                          ) : null}
                        </FormGroup>
                      </Col>
                      <Col md={4} className="CreateEmpInpCon">
                        <FormGroup>
                          <Label>End Date</Label>
                          <CustomDatePicker
                            wrapperClassName="datepicker"
                            className="form-control"
                            dateFormat="dd/MM/yyyy"
                            selected={
                              item.endDate ? new Date(item.endDate) : ""
                            }
                            onChange={(date) => {
                              handleCompany(
                                {
                                  target: {
                                    name: "endDate",
                                    value: date,
                                  },
                                },
                                index
                              );
                              let a = moment(item.startDate);
                              let b = moment(item.endDate);
                              let years = a.diff(b, 'year');
                              b.add(years, 'years');
                              let months = a.diff(b, 'months');
                              b.add(months, 'months');
                              let days = a.diff(b, 'days');
                              if(item.startDate && item.endDate){
                              let diffDate=years + ' years ' + months + ' month(s) ' + days + ' day(s)'
                              let diffDateWith=diffDate.replaceAll("-","");
                              item.experience = diffDateWith;
                              }
                            }}
                          />
                          {cEndDateError ? (
                            <FormText
                              style={{
                                paddingLeft: "14px",
                                color: "red",
                                fontSize: "14px",
                              }}
                              color="red"
                            >
                              {cEndDateError}
                            </FormText>
                          ) : null}
                        </FormGroup>
                      </Col>
                    </Row>
                    <Row style={{ display: "flex", padding: "5px" }}>
                      <Col md={4} className="CreateEmpInpCon">
                        <FormGroup>
                          <Label>Experience</Label>
                          <Input
                            type="text"
                            placeholder="Experience"
                            name="experience"
                            value={item.experience}
                            onChange={(e) => handleCompany(e, index)}
                            disabled
                          />
                          {cExpError ? (
                            <FormText
                              style={{
                                paddingLeft: "14px",
                                color: "red",
                                fontSize: "14px",
                              }}
                              color="red"
                            >
                              {cExpError}
                            </FormText>
                          ) : null}
                        </FormGroup>
                      </Col>
                    </Row>
                  </div>
                );
              })}
            </>
          )}

          <FormGroup style={{ float: "right" }}>
            <Button
              variant="outlined"
              color="primary"
              onClick={() => setActiveStep(activeStep - 1)}
            >
              Back
            </Button>
            <Button
              variant="contained"
              color="primary"
              style={{ marginLeft: "5px" }}
              onClick={handleSubmit}
            >
              Next
            </Button>
          </FormGroup>
        </Form>
      </Container>
    </CCard>
  );
}
