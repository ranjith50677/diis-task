import { CCard } from "@coreui/react";
import React, { useEffect, useState } from "react";
import {
  Col,
  Container,
  Form,
  FormGroup,
  FormText,
  Input,
  Label,
  Row,
} from "reactstrap";
import { Country, State, City } from "country-state-city";
import Select from "react-select";
import CustomSelect from "src/custom/Select";
import { IconContext } from "react-icons";
import { FaMinus, FaPlus } from "react-icons/fa";
import CustomDatePicker from "src/custom/Datepicker";
import Pincode from "../../../utility/pincode.json";
import _ from "lodash";
import "./styles.css"

import "bootstrap/dist/css/bootstrap.min.css";
import { toast, Toaster } from "react-hot-toast";
import { Button } from "@mui/material";
export default function UserForm(props) {
  const {
    activeStep,
    setActiveStep,
    inputValues,
    setValue,
    errorState,
    menuId,
    useage,
    userId,
  } = props;
  const [UserIdForVerify, setUserIdForVerify] = useState(userId);
  const [firstnameError, setFirstnameError] = useState("");
  const [secondnameError, setSecondnameError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [dobError, setDobError] = useState("");
  const [mobileError, setMobileError] = useState("");
  const [bloodgroupError, setBloodgroupError] = useState("");
  const [genderError, setGenderError] = useState("");
  const [maritalStatusError, setMaritalStatusError] = useState("");
  const [doornoError, setDornoError] = useState("");
  const [stretError, setStretError] = useState("");
  const [countryError, setCountryError] = useState("");
  const [stateError, setStateError] = useState("");
  const [cityError, setCityError] = useState("");
  const [zipError, setZipError] = useState("");
  const [familyMemberError, setFamilyMemberError] = useState({
    name: "",
    relationship: "",
    occupation: "",
    dob: "",
    adhaarNo: "",
    emergencyContact: "",
  });
  const [datepick, setDatePick] = useState(new Date());
  const [bloodGroups, setBloodGroups] = useState([
    { value: "A+", label: "A+" },
    { value: "A-", label: "A-" },
    { value: "B+", label: "B+" },
    { value: "B-", label: "B-" },
    { value: "AB+", label: "AB+" },
    { value: "AB-", label: "AB-" },
    { value: "O+", label: "O+" },
    { value: "O-", label: "O-" },
  ]);
  const [marriageStatus, setMarriageStatus] = useState([
    { value: "Married", label: "Married" },
    { value: "Unmarried", label: "Unmarried" },
  ]);
  const [gender, setGender] = useState([
    { value: "Male", label: "Male" },
    { value: "Female", label: "Female" },
    { value: "Others", label: "Others" },
  ]);

  const [addressDetails, setAddressDetails] = useState({
    countryName: "",
    stateName: "",
    districtName: "",
    pincode: "",
  });
  const [countryList, setCountryList] = useState([]);
  const [stateList, setStateList] = useState([]);
  const [districtNameList, setDistrictNameList] = useState([]);
  const [pincodeList, setPincodeList] = useState([]);

  const [con, setCon] = useState(null);
  const blockInvalidChar = e => ['e', 'E', '+', '-'].includes(e.key) && e.preventDefault();

  const handlepin = async () => {
    if (Pincode) {
      let country = _.uniqBy(Pincode, (e) => {
        return e.countryName;
      });
      setCountryList(country);
      setStateList([]);
      setDistrictNameList([]);
      setPincodeList([]);
    }
  };

  useEffect(() => {
    handlepin();
  }, []);

  const resetFuc = async (list) => {
    let fields = {};
    list.map((x) => (fields = { ...fields, [x]: "" }));
    return fields;
  };

  const onChangeAddress = async (element, label) => {
    if (label === "countryName") {
      let data = await resetFuc(["stateName", "districtName", "pincode"]);
      setAddressDetails({ ...addressDetails, [label]: element, ...data });
      let state = _.uniqBy(
        _.filter(Pincode, (d) => d.countryName == element.countryName),
        (e) => {
          return e.stateName;
        }
      );
      setStateList(state);
      setDistrictNameList([]);
      setPincodeList([]);
      setValue({ ...inputValues, country: element.countryName });
    }

    if (label === "stateName") {
      let data = await resetFuc(["districtName", "pincode"]);
      setAddressDetails({ ...addressDetails, [label]: element, ...data });
      let district = _.uniqBy(
        _.filter(Pincode, (d) => d.stateName == element.stateName),
        (e) => {
          return e.districtName;
        }
      );

      setDistrictNameList(district);
      setPincodeList([]);
      setValue({ ...inputValues, state: element.stateName });
    }

    if (label === "districtName") {
      let data = await resetFuc(["pincode"]);
      setAddressDetails({ ...addressDetails, [label]: element, ...data });
      let pincode = _.uniqBy(
        _.filter(Pincode, (d) => d.districtName == element.districtName),
        (e) => {
          return e.pincode;
        }
      );

      setPincodeList(pincode);
      setValue({ ...inputValues, city: element.districtName });
    }

    if (label === "pincode") {
      setAddressDetails({ ...addressDetails, [label]: element });
      setValue({ ...inputValues, postalCode: element.pincode });
    }

  };
  const handleFamilyMemberChange = (e, index) => {
    const { name, value } = e.target;
    const list = [...inputValues.familyMembers];
    list[index][name] = value;
    setValue((prev) => ({
      ...prev,
      familyMembers: list,
    }));
  };

  const handelSubmit = async (e) => {
    e.preventDefault();
    if (!inputValues.firstName) {
      setFirstnameError("First name is required");
    } else {
      setFirstnameError("");
    }
    if (!inputValues.lastName) {
      setSecondnameError("Last name is required");
    } else {
      setSecondnameError("");
    }
    if (!inputValues.email) {
      setEmailError("Email is required");
    } else if (!/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{3}$/.test(inputValues.email)) {
      setEmailError("Invalid email");
    } else {
      setEmailError("");
    }
    if (!inputValues.dob) {
      setDobError("DOB is required");
    } else {
      setDobError("");
    }
    if (!inputValues.mobileNo) {
      setMobileError("Mobile number is required");
    } else if (!/^\d{10}$/.test(inputValues.mobileNo)) {
      setMobileError("Must be 10 digit");
    } else {
      setMobileError("");
    }
    if (!inputValues.bloodGroup) {
      setBloodgroupError("Blood group is required");
    } else {
      setBloodgroupError("");
    }
    if (!inputValues.gender) {
      setGenderError("Gender is required");
    } else {
      setGenderError("");
    }
    if (!inputValues.marriageStatus) {
      setMaritalStatusError("Marital status is required");
    } else {
      setMaritalStatusError("");
    }
    if (!inputValues.Doorno) {
      setDornoError("HouseName/Doorno required");
    } else {
      setDornoError("");
    }
    if (!inputValues.streetName) {
      setStretError("AreaName/StreetName required");
    } else {
      setStretError("");
    }
    if (!inputValues.postalCode) {
      setZipError("Zip code  is required");
    } else {
      setZipError("");
    }
    if (!inputValues.city) {
      setCityError("City is required");
    } else {
      setCityError("");
    }
    if (!inputValues.state) {
      setStateError("State is required");
    } else {
      setStateError("");
    }
    if (!inputValues.country) {
      setCountryError("Country is required");
    } else {
      setCountryError("");
    }
    inputValues.familyMembers?.map((item, index) => {
      if (!item.name) {
        setFamilyMemberError((pre) => ({ ...pre, name: "Name is required" }));
      } else {
        setFamilyMemberError((pre) => ({ ...pre, name: "" }));
      }
      if (!item.relationship) {
        setFamilyMemberError((pre) => ({
          ...pre,
          relationship: "Relationship is required",
        }));
      } else {
        setFamilyMemberError((pre) => ({ ...pre, relationship: "" }));
      }
      if (!item.occupation) {
        setFamilyMemberError((pre) => ({
          ...pre,
          occupation: "Occupation is required",
        }));
      } else {
        setFamilyMemberError((pre) => ({ ...pre, occupation: "" }));
      }
      if (!item.dob) {
        setFamilyMemberError((pre) => ({ ...pre, dob: "DOB is required" }));
      } else {
        setFamilyMemberError((pre) => ({ ...pre, dob: "" }));
      }
      if (!item.adhaarNo) {
        setFamilyMemberError((pre) => ({
          ...pre,
          adhaarNo: "Aadhaar number is required",
        }));
      } else if (!/^\d{12}$/.test(item.adhaarNo)) {
        setFamilyMemberError((pre) => ({
          ...pre,
          adhaarNo: "Must be 12 digit",
        }));
      } else {
        setFamilyMemberError((pre) => ({ ...pre, adhaarNo: "" }));
      }
      if (!item.emergencyContact) {
        setFamilyMemberError((pre) => ({
          ...pre,
          emergencyContact: "Emergency contact is required",
        }));
      } else if (!/^\d{10}$/.test(item.emergencyContact)) {
        setFamilyMemberError((pre) => ({
          ...pre,
          emergencyContact: "Must be 10 digit",
        }));
      } else {
        setFamilyMemberError((pre) => ({ ...pre, emergencyContact: "" }));
      }
    });

    const familyMemberr = inputValues.familyMembers?.map((item, index) => {
      if (
        !item.name ||
        !item.relationship ||
        !item.occupation ||
        !item.dob ||
        !item.adhaarNo ||
        !item.emergencyContact
      ) {
        return false;
      } else {
        return true;
      }
    });

    if (errorState) {
      if (
        !inputValues.firstName ||
        !inputValues.lastName ||
        !inputValues.email ||
        !inputValues.dob ||
        !inputValues.mobileNo ||
        !inputValues.bloodGroup ||
        !inputValues.gender ||
        !inputValues.marriageStatus ||
        !inputValues.Doorno ||
        !inputValues.streetName ||
        !inputValues.postalCode ||
        !inputValues.city ||
        !inputValues.state ||
        !inputValues.country ||
        familyMemberr.includes(false)
      ) {
        console.log("Errors happend");
        console.log(errorState);
      } else {
       
        setActiveStep(activeStep + 1);
      }
    } else {
      setActiveStep(activeStep + 1);
    
    }
  };
  useEffect(() => {
    const EditFuc = async () => {
      if (Pincode && inputValues) {
        let addData = {};

        if (inputValues.country != "") {

          addData = {
            ...addData,
            countryName: { countryName: inputValues.country }
          };

          let state = _.uniqBy(
            _.filter(Pincode, (d) => d.countryName == inputValues.country),
            (e) => {
              return e.stateName;
            }
          );

          setStateList(state);
        }

        if (inputValues.state != "") {
          let data = await resetFuc(["districtName", "pincode"]);

          addData = {
            ...addData,
            stateName: { stateName: inputValues.state }
          };

          let district = _.uniqBy(
            _.filter(Pincode, (d) => d.stateName == inputValues.state),
            (e) => {
              return e.districtName;
            }
          );

          setDistrictNameList(district);
        }

        if (inputValues.city != "") {
          let data = await resetFuc(["pincode"]);

          addData = {
            ...addData,
            districtName: { districtName: inputValues.city }
          };

          let pincode = _.uniqBy(
            _.filter(Pincode, (d) => d.districtName == inputValues.city),
            (e) => {
              return e.pincode;
            }
          );

          setPincodeList(pincode);
        }

        if (inputValues.postalCode != "") {

          addData = {
            ...addData,
            pincode: { pincode: inputValues.postalCode },
          };
        }

        setAddressDetails(addData);
      }
    };

     EditFuc();
  }, [inputValues.country]);

  return (
    <CCard>
      <Container style={{ padding: "20px" }}>
        <Form>
          <Row  style={{  justifyContent:"space-between",padding:"5px"}} >
          <h4>Personal Info</h4>
          <hr style={{ padding: "5px"}}></hr>
            <Col md={4} className="CreateEmpInpCon"  >
              <FormGroup>
                <Label>
                  First Name{" "}
                  <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                </Label>
                <Input
                  type="text"
                  name="firstName"
                  id="firstName"
                  placeholder="First Name"
                  value={inputValues.firstName}
                  onChange={(e) =>
                    setValue({ ...inputValues, firstName: e.target.value })
                  }
                />
                {firstnameError ? (
                  <FormText
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                    color="red"
                  >
                    {firstnameError}
                  </FormText>
                ) : null}
              </FormGroup>
            </Col>
            <Col md={4} className="CreateEmpInpCon"   >
              <FormGroup>
                <Label>
                  Last Name{" "}
                     <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                </Label>
                <Input
                  type="text"
                  name="lastName"
                  id="lastName"
                  placeholder="Last Name"
                  value={inputValues.lastName}
                  onChange={(e) =>
                    setValue({ ...inputValues, lastName: e.target.value })
                  }
                />
                {secondnameError ? (
                  <FormText
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                    color="red"
                  >
                    {secondnameError}
                  </FormText>
                ) : null}
              </FormGroup>
            </Col>
            <Col md={4} className="CreateEmpInpCon"  >
              <FormGroup>  
                <Label>
                  Email{" "}
                     <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                </Label>
                <Input
                  type="email"
                  name="email"
                  id="email"
                  placeholder="Email"
                  style={{ textTransform: "lowercase" }}
                  value={inputValues.email}
                  onChange={(e) =>
                    setValue({ ...inputValues, email: e.target.value })
                  }
                />
                {emailError ? (
                  <FormText
                    style={{
                      paddingLeft: "14px",
                      color: "red",
                      fontSize: "14px",
                    }}
                    color="red"
                  >
                    {emailError}
                  </FormText>
                ) : null}
              </FormGroup>
            </Col>
           
          </Row>
          <>
          <Row  style={{justifyContent:"space-between",padding:"5px"}} >           
              <Col md={4} className="CreateEmpInpCon" >
                <FormGroup>
                  <Label>
                    Date Of Birth
                      <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                  </Label>
                  <CustomDatePicker
                    wrapperClassName="datepicker"
                    className="form-control"
                    dateFormat="dd/MM/yyyy"
                    // selected={inputValues.dob}
                    selected={inputValues.dob ? new Date(inputValues.dob) : ""}
                    onChange={(date) => setValue({ ...inputValues, dob: date })}
                  />
                  {dobError ? (
                    <FormText
                      style={{
                        paddingLeft: "14px",
                        color: "red",
                        fontSize: "14px",
                      }}
                      color="red"
                    >
                      {dobError}
                    </FormText>
                  ) : null}
                </FormGroup>
              </Col>
              <Col md={4} className="CreateEmpInpCon">
                <FormGroup>
                  <Label>
                    Mobile No
                      <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                  </Label>
                  <Input
                    type="number"
                    name="mobile"
                    id="mobile"
                    min={0}
                    // maxLength='3'
                    size="4"
                    placeholder="Mobile No."
                    onKeyDown={blockInvalidChar}
                    value={inputValues.mobileNo}
                    onChange={(e) =>
                      setValue({ ...inputValues, mobileNo: e.target.value })
                    }
                  />
                  {mobileError ? (
                    <FormText
                      style={{
                        paddingLeft: "14px",
                        color: "red",
                        fontSize: "14px",
                      }}
                      color="red"
                    >
                      {mobileError}
                    </FormText>
                  ) : null}
                </FormGroup>
              </Col>
              <Col md={4} className="CreateEmpInpCon" >
                <FormGroup>
                  <Label>
                    Blood Group{" "}
                      <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                  </Label>
                  <CustomSelect
                    option={bloodGroups}
                    selectedOptions={inputValues.bloodGroup}
                    setSelectedOptions={(e) =>
                      setValue({ ...inputValues, bloodGroup: e })
                    }
                    isSearchable={true}
                    isMulti={false}
                  />
                  {bloodgroupError ? (
                    <FormText
                      style={{
                        paddingLeft: "14px",
                        color: "red",
                        fontSize: "14px",
                      }}
                      color="red"
                    >
                      {bloodgroupError}
                    </FormText>
                  ) : null}
                </FormGroup>
              </Col>             
              </Row>
              <Row  style={{ padding:"5px",display:"flex"}} >             
              <Col md={4} className="CreateEmpInpCon"  >
                <FormGroup>
                  <Label>
                    Gender
                      <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                  </Label>
                  <CustomSelect
                    option={gender}
                    selectedOptions={inputValues.gender}
                    setSelectedOptions={(e) =>
                      setValue({ ...inputValues, gender: e })
                    }
                    value={inputValues.gender}
                    isMulti={false}
                    isSearchable={true}
                  />
                  {genderError ? (
                    <FormText
                      style={{
                        paddingLeft: "14px",
                        color: "red",
                        fontSize: "14px",
                      }}
                      color="red"
                    >
                      {genderError}
                    </FormText>
                  ) : null}
                </FormGroup>
              </Col>
              <Col md={4} className="CreateEmpInpCon"   >
                <FormGroup>
                  <Label>
                    Marital Status{" "}
                      <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                  </Label>
                  <CustomSelect
                    option={marriageStatus}
                    selectedOptions={inputValues.marriageStatus}
                    setSelectedOptions={(e) =>
                      setValue({ ...inputValues, marriageStatus: e })
                    }
                    isMulti={false}
                    isSearchable={true}
                  />
                  {maritalStatusError ? (
                    <FormText
                      style={{
                        paddingLeft: "14px",
                        color: "red",
                        fontSize: "14px",
                      }}
                      color="red"
                    >
                      {maritalStatusError}
                    </FormText>
                  ) : null}
                </FormGroup>
              </Col>             
              </Row>
            <h4>Address Details</h4>
            <hr style={{ padding: " 5px"}}></hr>
            <Row  style={{  justifyContent:"space-between",padding:"5px"}} >           
              <Col md={4}>
                <FormGroup>
                  <Label>
                    House Name / Door No
                    <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                  </Label>
                  <Input
                    type="text"
                    name="Doorno"
                    id="Doorno"
                    placeholder="House Name / Door No"
                    value={inputValues.Doorno}
                    onChange={(e) =>
                      setValue({ ...inputValues, Doorno: e.target.value })
                    }
                  />
                  {doornoError ? (
                    <FormText
                      style={{
                        paddingLeft: "14px",
                        color: "red",
                        fontSize: "14px",
                      }}
                      color="red"
                    >
                      {doornoError}
                    </FormText>
                  ) : null}
                </FormGroup>
              </Col>
              <Col md={4}>
                <FormGroup>
                  <Label>
                    Area Name / Street Name
                    <span
                           style={{
                             paddingLeft: "5px",
                             color: "red",
                             fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                  </Label>
                  <Input
                    type="text"
                    name="street"
                    id="street"
                    placeholder=" Area Name / Street Name"
                    value={inputValues.streetName}
                    onChange={(e) =>
                      setValue({ ...inputValues, streetName: e.target.value })
                    }
                  />
                  {stretError ? (
                    <FormText
                      style={{
                        paddingLeft: "14px",
                        color: "red",
                        fontSize: "14px",
                      }}
                      color="red"
                    >
                      {stretError}
                    </FormText>
                  ) : null}
                </FormGroup>
              </Col>
              <Col md={4}>
                <FormGroup>
                  <Label>Land Mark</Label>
                  <Input
                    type="text"
                    name="LandMark"
                    id="LandMark"
                    placeholder="Land Mark"
                    value={inputValues.landmark}
                    onChange={(e) =>
                      setValue({ ...inputValues, landmark: e.target.value })
                    }
                  />
                </FormGroup>
              </Col>
              </Row>
              <Row  style={{justifyContent:"space-between",padding:"5px"}} >  
            <Col md={4}  className="CreateEmpInpCon"  >
                <FormGroup>
                  <Label>
                    Country{" "}
                    <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                  </Label>
                  <Select
                    options={countryList}
                    getOptionLabel={(options) => {
                      return options["countryName"];
                    }}
                    getOptionValue={(options) => {
                      return options["countryName"];
                    }}
                    value={addressDetails["countryName"]}
                    onChange={(item) => {
                      onChangeAddress(item, "countryName");
                    }}
                  />
                  {countryError ? (
                    <FormText
                      style={{
                        paddingLeft: "14px",
                        color: "red",
                        fontSize: "14px",
                      }}
                      color="red"
                    >
                      {countryError}
                    </FormText>
                  ) : null}
                </FormGroup>
              </Col>
              <Col md={4}  className="CreateEmpInpCon"  >
                <FormGroup>
                  <Label>State</Label>
                  <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                  <Select
                    options={stateList}
                    getOptionLabel={(options) => {
                      return options["stateName"];
                    }}
                    getOptionValue={(options) => {
                      return options["stateName"];
                    }}
                    value={addressDetails["stateName"]}
                    onChange={(item) => {
                      onChangeAddress(item, "stateName");
                    }}
                  />
                  {stateError ? (
                    <FormText
                      style={{
                        paddingLeft: "14px",
                        color: "red",
                        fontSize: "14px",
                      }}
                      color="red"
                    >
                      {stateError}
                    </FormText>
                  ) : null}
                </FormGroup>
              </Col>
              <Col md={4}  className="CreateEmpInpCon"  >
                <FormGroup>
                  <Label>City</Label>
                  <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                  <Select
                    options={districtNameList}
                    getOptionLabel={(options) => {
                      return options["districtName"];
                    }}
                    getOptionValue={(options) => {
                      return options["districtName"];
                    }}
                    value={addressDetails["districtName"]}
                    onChange={(item) => {
                      onChangeAddress(item, "districtName");
                    }}
                  />
                  {cityError ? (
                    <FormText
                      style={{
                        paddingLeft: "14px",
                        color: "red",
                        fontSize: "14px",
                      }}
                      color="red"
                    >
                      {cityError}
                    </FormText>
                  ) : null}
                </FormGroup>
              </Col>
              </Row>
              <Row>
              <Col md={4}  className="CreateEmpInpCon"  >
                <FormGroup>
                  <Label>Postal Code </Label>
                  <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                  <Select
                    options={pincodeList}
                    getOptionLabel={(options) => {
                      return options["pincode"];
                    }}
                    getOptionValue={(options) => {
                      return options["pincode"];
                    }}
                    value={addressDetails["pincode"]}
                    onChange={(item) => {
                      onChangeAddress(item, "pincode");
                    }}
                  />
                  {zipError ? (
                    <FormText
                      style={{
                        paddingLeft: "14px",
                        color: "red",
                        fontSize: "14px",
                      }}
                      color="red"
                    >
                      {zipError}
                    </FormText>
                  ) : null}
                </FormGroup>
              </Col>
              </Row>
             <h4>Family Members</h4>
            <hr style={{ width: "100%" }} />
            <Row style={{ marginTop: "20px",padding:"5px" }}>
              <Col md={12}>
                <FormGroup>
                  <IconContext.Provider
                    value={{ color: "black", size: "20px" }}
                  >
                    <FaPlus
                      style={{ float: "right", cursor: "pointer" }}
                      onClick={() => {
                        setValue({
                          ...inputValues,
                          familyMembers: [
                            ...inputValues.familyMembers,
                            {
                              name: "",
                              relationship: "",
                              occupation: "",
                              dob: "",
                              adhaarNo: null,
                              emergencyContact: null,
                            },
                          ],
                        });
                      }}
                    />
                  </IconContext.Provider>
                </FormGroup>
              </Col>
            </Row>
          </>
          {inputValues.familyMembers?.map((familyMember, index) => (
            <div key={index}>
              {index < 1 ? (
                <Row>
                  <Col md={4}>
                    <FormGroup>
                      <h5>Family Members {index + 1}</h5>
                    </FormGroup>
                  </Col>
                </Row>
              ) : (
                <Row>
                  <Col md={6}>
                    <FormGroup>               
                      <h5>Family Members {index + 1}</h5>                     
                    </FormGroup>
                  </Col>
                  <Col md={12}>
                    <IconContext.Provider
                      value={{ color: "black", size: "20px" }}
                    >
                      <FaMinus
                        style={{ float: "right", cursor: "pointer" }}
                        onClick={() => {
                          // setFamilyMembers(
                          //   familyMembers.filter((_, i) => i !== index)
                          // );
                          setValue({
                            ...inputValues,
                            familyMembers: inputValues.familyMembers?.filter(
                              (_, i) => i !== index
                            ),
                          });
                        }}
                      />
                    </IconContext.Provider>
                  </Col>
                </Row>
              )}
              <Row  style={{justifyContent:"space-between",padding:"5px"}} > 
                <Col md={4} className="CreateEmpInpCon" >
                  <FormGroup>
                    <Label>
                      Name
                        <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                    </Label>
                    <Input
                      id="name"
                      name="name"
                      type="text"
                      value={familyMember.name}
                      onChange={(e) => handleFamilyMemberChange(e, index)}
                      placeholder="Name"
                    />
                    {familyMemberError.name ? (
                      <FormText
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                        color="red"
                      >
                        {familyMemberError.name}
                      </FormText>
                    ) : null}
                  </FormGroup>
                </Col>
                <Col md={4} className="CreateEmpInpCon" >
                  <FormGroup>
                    <Label>
                      Relationship
                        <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                    </Label>
                    <Input
                      id="relationship"
                      name="relationship"
                      placeholder="Relationship"
                      type="text"
                      value={familyMember.relationship}
                      onChange={(e) => handleFamilyMemberChange(e, index)}
                    />
                    {familyMemberError.relationship ? (
                      <FormText
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                        color="red"
                      >
                        {familyMemberError.relationship}
                      </FormText>
                    ) : null}
                  </FormGroup>
                </Col>
                <Col md={4} className="CreateEmpInpCon" >
                  <FormGroup>
                    <Label>
                      Occupation
                        <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                    </Label>
                    <Input
                      id="occupation"
                      name="occupation"
                      placeholder="Occupation"
                      type="text"
                      value={familyMember.occupation}
                      onChange={(e) => handleFamilyMemberChange(e, index)}
                    />
                    {familyMemberError.occupation ? (
                      <FormText
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                        color="red"
                      >
                        {familyMemberError.occupation}
                      </FormText>
                    ) : null}
                  </FormGroup>
                </Col>
         
                </Row>
                <Row  style={{justifyContent:"space-between",padding:"5px"}} >           
                <Col md={4} className="CreateEmpInpCon" >
                  <FormGroup>
                    <Label>
                      DOB
                        <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                    </Label>
                    <CustomDatePicker
                      wrapperClassName="datepicker"
                      className="form-control"
                      dateFormat="dd/MM/yyyy"
                      // selected={inputValues.dob}
                      selected={
                        familyMember.dob ? new Date(familyMember.dob) : ""
                      }
                      onChange={(date) => {
                        handleFamilyMemberChange(
                          {
                            target: {
                              name: "dob",
                              value: date,
                            },
                          },
                          index
                        );
                      }}
                    />
                    {familyMemberError.dob ? (
                      <FormText
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                        color="red"
                      >
                        {familyMemberError.dob}
                      </FormText>
                    ) : null}
                  </FormGroup>
                </Col>
                <Col md={4} className="CreateEmpInpCon" >
                  <FormGroup>
                    <Label>
                      Aadhaar No
                        <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                    </Label>
                    <Input
                      id="aadhaar"
                      name="adhaarNo"
                      placeholder="Aadhaar No"
                      type="number"
                      min={0}
                      
                      value={familyMember.adhaarNo}
                      onChange={(e) => handleFamilyMemberChange(e, index)}
                    />
                    {familyMemberError.adhaarNo ? (
                      <FormText
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                        color="red"
                      >
                        {familyMemberError.adhaarNo}
                      </FormText>
                    ) : null}
                  </FormGroup>
                </Col>
                <Col md={4} className="CreateEmpInpCon" >
                  <FormGroup>
                    <Label>
                      Emergency Contact
                        <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                    </Label>
                    <Input
                      id="emergency"
                      name="emergencyContact"
                      placeholder="Emergency Contact"
                      type="number"
                      min={0}
                      onKeyDown={blockInvalidChar}
                      value={familyMember.emergencyContact}
                      onChange={(e) => handleFamilyMemberChange(e, index)}
                    />
                    {familyMemberError.emergencyContact ? (
                      <FormText
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                        color="red"
                      >
                        {familyMemberError.emergencyContact}
                      </FormText>
                    ) : null}
                  </FormGroup>
                </Col>
                </Row>
                
            </div>
          ))}
          <FormGroup style={{ float: "right" }}>
            {/* <Button
              //  disabled={!btnDisbaled}
              // onClick={()=>setActiveStep(activeStep+1)}
              >Next</Button> */}
            {/* <Button onClick={()=>  setActiveStep(activeStep + 1)} color="primary"> */}
            <Button variant="contained" onClick={handelSubmit} color="primary">
              Next
            </Button>
          </FormGroup>
        </Form>
      </Container>
      <Toaster />
    </CCard>
  );
}
