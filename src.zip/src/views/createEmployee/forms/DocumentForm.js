import { CButton, CCard, CCardBody, CCardTitle } from "@coreui/react";
import { Button } from "@mui/material";
import React, { useState } from "react";
import { toast, Toaster } from "react-hot-toast";
import { Col, Container, Form, FormGroup, Input, Label, Row } from "reactstrap";
import CustomDatePicker from "src/custom/Datepicker";
import {
  addAddress,
  addDocument,
  addEducation,
  addFamily,
  createUser,
  updateAddress,
  updateDocument,
  updateEducation,
  updateUser,
  updateWorkById,
  workInfo,
  getUserById,
  updateFamily,
  getFamilyById,
  addExperience,
  updateExperience,
  deleteUserById,
} from "src/utility/apiService";
import "./styles.css";
export default function DocumentForm(props) {
  const {
    activeStep,
    setActiveStep,
    user,
    fam,
    work,
    exp,
    edu,
    useage,
    documentValues,
    setDocuValues,
    open,
    setOpen,
    id,
    errorState,
    menuId,
  } = props;
  let userdata = {
    firstName: user?.firstName,
    lastName: user?.lastName,
    email: user?.email,
    dob: user?.dob,
    mobileNo: user?.mobileNo,
    gender: user?.gender.value,
    marriageStatus: user?.marriageStatus.value,
    bloodGroup: user.bloodGroup.value,
  };
  let userFamily = [
    {
      // userId:"",
      name: fam?.name,
      relationship: fam?.relationship,
      occupation: fam?.occupation,
      dob: fam?.dob,
      adhaarNo: fam?.adhaarNo,
      emergencyContact: fam?.emergencyContact,
      menuId: menuId,
    },
  ];
  let useraddress = {
    Doorno: user?.Doorno,
    streetName: user?.streetName,
    landmark: user?.landmark,
    country: user?.country,
    city: user?.city,
    state: user?.state,
    postalCode: user?.postalCode,
    menuId: menuId,
  };
  let userWorkinfo = {
    department: work.department.value,
    designation: work.designation.value,
    roleId: work.role.roleId,
    salary: work.salary,
    joiningDate: work.joiningDate,
    reportedTo: work.reportedTo.value,
    isFresher: work.isFresher,
    menuId: menuId,
  };

  let previousCompany = {
    companyName: exp?.companyName,
    designation: exp?.designation,
    startDate: exp?.startDate,
    endDate: exp?.endDate,
    salary: exp?.salary,
    description: exp?.description,
    experience: exp?.experience,
    menuId: menuId,
  };
  let userdocument = {
    accountNo: documentValues.accountNo,
    ifsc: documentValues.ifsc,
    branch: documentValues.branch,
    bankName: documentValues.bankName,
    accountHolderName: documentValues.accountHolderName,
    aadhaarNo: documentValues.aadhaarNo,
    panNo: documentValues.panNo,
    passportNo: documentValues.passportNo,
    uanNo: documentValues.uanNo,
    pfNo: documentValues.pfNo,
    esiNo: documentValues.esiNo,
    vaccination1Date: documentValues.vaccination1Date,
    vaccination2Date: documentValues.vaccination2Date,
    menuId: menuId,
  };
  let userEducation = {
    sslcSchoolName: edu.sslcSchoolName,
    sslcBoard: edu.sslcBoard.value,
    sslcYearOfPassing: edu.sslcYearOfPassing,
    sslcPercentage: edu.sslcPercentage,
    hscSchoolName: edu.hscSchoolName,
    hscBoard: edu.hscBoard.value,
    hscYearOfPassing: edu.hscYearOfPassing,
    hscPercentage: edu.hscPercentage,
    ugUniversityName: edu.ugUniversityName,
    ugInstituteName: edu.ugInstituteName,
    ugDepartmentCourse: edu.ugDepartmentCourse,
    ugYearOfPassing: edu.ugYearOfPassing,
    ugCgpa: edu.ugCgpa,
    pgUniversityName: edu.pgUniversityName,
    pgInstituteName: edu.pgInstituteName,
    pgDepartmentCourse: edu.pgDepartmentCourse,
    pgYearOfPassing: edu.pgYearOfPassing,
    pgCgpa: edu.pgCgpa,
    phdUniversityName: edu.phdUniversityName,
    phdInstituteName: edu.phdInstituteName,
    phdDepartmentCourse: edu.phdDepartmentCourse,
    phdYearOfPassing: edu.phdYearOfPassing,
    phdCgpa: edu.phdCgpa,
    menuId: menuId,
  };
  console.log(menuId);

  const [anoerrorMessage, setAnoerrorMessage] = useState("");
  const [ifscerrorMessage, setIfscerrorMessage] = useState("");
  const [brancherrorMessage, setBrancherrorMessage] = useState("");
  const [banknameerrorMessage, setBanknameerrorMessage] = useState("");
  const [nameerrorMessage, setNameerrorMessage] = useState("");
  const [adhaarerrorMessage, setAdhaarerrorMessage] = useState("");
  const [panerrorMessage, setPanerrorMessage] = useState("");
  const [passporterrorMessage, setPassporterrorMessage] = useState("");
  const [uanerrorMessage, setUanerrorMessage] = useState("");
  const [pferrorMessage, setPferrorMessage] = useState("");
  const [esierrorMessage, setEsierrorMessage] = useState("");
  const [v1errorMessage, setV1errorMessage] = useState("");
  const [v2errorMessage, setV2errorMessage] = useState("");
  const [famerr, setFamErr] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    let adhaar =
      /(^[0-9]{4}[0-9]{4}[0-9]{4}$)|(^[0-9]{4}\s[0-9]{4}\s[0-9]{4}$)|(^[0-9]{4}-[0-9]{4}-[0-9]{4}$)/;
    let ifsccode = /^[A-Za-z]{4}0[A-Z0-9a-z]{6}$/;
    if (errorState) {
      if (documentValues.accountNo === "") {
        setAnoerrorMessage("Account Number is required");
      } else if (!/^\d{12}$/.test(documentValues.accountNo)) {
        setAnoerrorMessage("Must be 12 digit");
      } else {
        setAnoerrorMessage("");
      }
      if (documentValues.ifsc === "") {
        setIfscerrorMessage("IFSC is required");
      } else if (!ifsccode.test(documentValues.ifsc)) {
        setIfscerrorMessage("Enter Valid Format IFSC Code");
      } else {
        setIfscerrorMessage("");
      }
      if (documentValues.branch === "") {
        setBrancherrorMessage("Branch is required");
      } else {
        setBrancherrorMessage("");
      }
      if (documentValues.bankName === "") {
        setBanknameerrorMessage("Bank Name is required");
      } else {
        setBanknameerrorMessage("");
      }
      if (documentValues.accountHolderName === "") {
        setNameerrorMessage("Account Holder Name is required");
      } else {
        setNameerrorMessage("");
      }
      if (documentValues.aadhaarNo === "") {
        setAdhaarerrorMessage("Aadhaar Number is required");
      } else if (!adhaar.test(documentValues.aadhaarNo)) {
        setAdhaarerrorMessage("Enter Valid Format Aadhaar Number");
      } else {
        setAdhaarerrorMessage("");
      }
      if (documentValues.panNo === "") {
        setPanerrorMessage("Pan Number is required");
      } else if (!/[A-Z]{5}[0-9]{4}[A-Z]{1}/.test(documentValues.panNo)) {
        setPanerrorMessage("Enter Valid Format PanNumber");
      } else {
        setPanerrorMessage("");
      }
      if (documentValues.vaccination1Date === "") {
        setV1errorMessage("Vaccination 1 Date is required");
      } else {
        setV1errorMessage("");
      }
      if (
        !documentValues.accountNo ||
        !documentValues.ifsc ||
        !documentValues.branch ||
        !documentValues.bankName ||
        !documentValues.accountHolderName ||
        !documentValues.aadhaarNo ||
        !documentValues.panNo ||
        !documentValues.vaccination1Date
      ) {
        console.log("error");
      } else {
        try {
          userdata = { ...userdata, password: "hrms@123", menuId };
          let response = await createUser(userdata);
          if (!response.ok) {
            return toast.error(response.data.message);
          }
          try {
            let family = fam.map((item, index) => {
              addFamily(response.data?.userId, { ...item, menuId }).then(
                (res) => {
                  if (!res.ok) {
                    setFamErr(true);
                    deleteUserById(response.data?.userId);
                    return toast.error(res.data.message);
                  }
                }
              );
            });
            try {
              if (famerr == false) {
                let address = await addAddress(
                  response.data.userId,
                  useraddress
                );
                console.log(useraddress);
                if (!address.ok) {
                  deleteUserById(response.data?.userId);
                  return toast.error(address.data.message);
                }
                try {
                  let education = await addEducation(
                    response.data.userId,
                    userEducation
                  );
                  if (!education.ok) {
                    deleteUserById(response.data?.userId);
                    return toast.error(education.data.message);
                  }
                  try {
                    let workinfo = await workInfo(
                      response.data.userId,
                      userWorkinfo
                    );
                    if (!workinfo.ok) {
                      deleteUserById(response.data?.userId);
                      return toast.error(workinfo.data.message);
                    }
                    try {
                      let preComp = exp?.map((item, index) => {
                        addExperience(response.data.userId, {
                          ...item,
                          menuId,
                        });
                      });

                      try {
                        let userUpdate = await updateUser(
                          response.data.userId,
                          {
                            roleId: work.role.roleId,
                          }
                        );
                        let doc = await addDocument(
                          response.data.userId,
                          userdocument
                        );
                        if (!doc.ok) {
                          deleteUserById(response.data?.userId);
                          return toast.error(doc.data.message);
                        }
                        if (!userUpdate.ok) {
                          deleteUserById(response.data?.userId);
                          return toast.error(userUpdate.data.message);
                        }
                        setTimeout(() => setOpen(!open), 500);
                        return toast.success("User Created Successfully");
                      } catch (error) {
                        deleteUserById(response.data?.userId);
                        console.log(error.message);
                      }
                    } catch (error) {
                      deleteUserById(response.data?.userId);
                      console.log(error.message);
                    }
                  } catch (error) {
                    deleteUserById(response.data?.userId);
                    console.log(error.message);
                  }
                } catch (error) {
                  deleteUserById(response.data?.userId);
                  console.log(error.message);
                }
              }
            } catch (error) {
              deleteUserById(response.data?.userId);
              console.log(error.message);
            }
          } catch (error) {
            deleteUserById(response.data?.userId);
            console.log(error);
          }
        } catch (error) {
          deleteUserById(response.data?.userId);
          console.log(error.message);
        }
      }
    } else {
      toast.error("Please fill all the required fields");
    }
  };
  const blockInvalidChar = (e) =>
    ["e", "E", "+", "-"].includes(e.key) && e.preventDefault();

  const handleUpdate = async () => {
    try {
      let response = await updateUser(id, userdata);
      let address = await updateAddress(id, useraddress);
      fam.map((item, index) => {
        if (item._id) {
          updateFamily(item._id, { ...item, menuId });
        } else {
          addFamily(id, { ...item, menuId });
        }
      });
      let education = await updateEducation(id, userEducation);
      let workinfo = await updateWorkById(id, userWorkinfo);
      exp?.map((item, index) => {
        if (item._id) {
          updateExperience(item._id, { ...item, menuId });
        } else {
          addExperience(id, { ...item, menuId });
        }
      });
      let doc = await updateDocument(id, userdocument);
      try {
        toast.success("User Updated Successfully");
        setTimeout(() => setOpen(!open), 700);
      } catch (error) {
        console.log(error.message);
      }
    } catch (error) {
      toast.error(error.message);
    }
  };
  return (
    <>
      <CCard>
        <Container style={{ padding: "20px" }}>
          <Form>
            <Form>
              <h4>Bank Details</h4>
              <hr style={{ padding: "5px" }}></hr>
              <Row style={{ display: "flex", padding: "5px" }}>
                <Col md={4} className="CreateEmpInpCon">
                  <FormGroup>
                    <Label>Account Number</Label>
                    <span
                      style={{
                        paddingLeft: "5px",
                        color: "red",
                        fontSize: "15px",
                      }}
                    >
                      *
                    </span>
                    <Input
                      type="number"
                      onKeyDown={blockInvalidChar}
                      placeholder="Account Number"
                      value={documentValues.accountNo}
                      onChange={(e) =>
                        setDocuValues({
                          ...documentValues,
                          accountNo: e.target.value,
                        })
                      }
                    />
                    {anoerrorMessage && (
                      <Label
                        className="error"
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                      >
                        {" "}
                        {anoerrorMessage}{" "}
                      </Label>
                    )}
                  </FormGroup>
                </Col>
                <Col md={4} className="CreateEmpInpCon">
                  <FormGroup>
                    <Label>IFSC</Label>
                    <span
                      style={{
                        paddingLeft: "5px",
                        color: "red",
                        fontSize: "15px",
                      }}
                    >
                      *
                    </span>
                    <Input
                      type="text"
                      placeholder="IFSC"
                      value={documentValues.ifsc}
                      onChange={(e) =>
                        setDocuValues({
                          ...documentValues,
                          ifsc: e.target.value,
                        })
                      }
                    />
                    {ifscerrorMessage && (
                      <Label
                        className="error"
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                      >
                        {" "}
                        {ifscerrorMessage}{" "}
                      </Label>
                    )}
                  </FormGroup>
                </Col>
                <Col md={4} className="CreateEmpInpCon">
                  <FormGroup>
                    <Label>Branch</Label>
                    <span
                      style={{
                        paddingLeft: "5px",
                        color: "red",
                        fontSize: "15px",
                      }}
                    >
                      *
                    </span>
                    <Input
                      placeholder="Branch"
                      type="text"
                      value={documentValues.branch}
                      onChange={(e) =>
                        setDocuValues({
                          ...documentValues,
                          branch: e.target.value,
                        })
                      }
                    />
                    {brancherrorMessage && (
                      <Label
                        className="error"
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                      >
                        {" "}
                        {brancherrorMessage}{" "}
                      </Label>
                    )}
                  </FormGroup>
                </Col>
              </Row>
              <Row>
                <Col md={4} className="CreateEmpInpCon">
                  <FormGroup>
                    <Label>Bank Name</Label>
                    <span
                      style={{
                        paddingLeft: "5px",
                        color: "red",
                        fontSize: "15px",
                      }}
                    >
                      *
                    </span>
                    <Input
                      placeholder="Bank Name"
                      type="text"
                      value={documentValues.bankName}
                      onChange={(e) =>
                        setDocuValues({
                          ...documentValues,
                          bankName: e.target.value,
                        })
                      }
                    />
                    {banknameerrorMessage && (
                      <Label
                        className="error"
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                      >
                        {" "}
                        {banknameerrorMessage}{" "}
                      </Label>
                    )}
                  </FormGroup>
                </Col>
                <Col md={4} className="CreateEmpInpCon">
                  <FormGroup>
                    <Label>Account Holder Name</Label>
                    <span
                      style={{
                        paddingLeft: "5px",
                        color: "red",
                        fontSize: "15px",
                      }}
                    >
                      *
                    </span>
                    <Input
                      placeholder="Account Holder Name"
                      type="text"
                      value={documentValues.accountHolderName}
                      onChange={(e) =>
                        setDocuValues({
                          ...documentValues,
                          accountHolderName: e.target.value,
                        })
                      }
                    />
                    {nameerrorMessage && (
                      <Label
                        className="error"
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                      >
                        {" "}
                        {nameerrorMessage}{" "}
                      </Label>
                    )}
                  </FormGroup>
                </Col>
              </Row>

              {/* *********************************************** Indentification Details *************************************************** */}
              <h4>Indentification Details</h4>
              <hr style={{ padding: "5px" }}></hr>
              <Row style={{ display: "flex", padding: "5px" }}>
                <Col md={4} className="CreateEmpInpCon">
                  <FormGroup>
                    <Label>Aadhaar Number</Label>
                    <span
                      style={{
                        paddingLeft: "5px",
                        color: "red",
                        fontSize: "15px",
                      }}
                    >
                      *
                    </span>
                    <Input
                      placeholder="Aadhaar Number"
                      type="number"
                      onKeyDown={blockInvalidChar}
                      value={documentValues.aadhaarNo}
                      onChange={(e) =>
                        setDocuValues({
                          ...documentValues,
                          aadhaarNo: e.target.value,
                        })
                      }
                    />
                    {adhaarerrorMessage && (
                      <Label
                        className="error"
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                      >
                        {" "}
                        {adhaarerrorMessage}{" "}
                      </Label>
                    )}
                  </FormGroup>
                </Col>
                <Col md={4} className="CreateEmpInpCon">
                  <FormGroup>
                    <Label>Pan Number</Label>
                    <span
                      style={{
                        paddingLeft: "5px",
                        color: "red",
                        fontSize: "15px",
                      }}
                    >
                      *
                    </span>
                    <Input
                      placeholder="Pan Number"
                      type="text"
                      value={documentValues.panNo}
                      onChange={(e) =>
                        setDocuValues({
                          ...documentValues,
                          panNo: e.target.value,
                        })
                      }
                    />
                    {panerrorMessage && (
                      <Label
                        className="error"
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                      >
                        {" "}
                        {panerrorMessage}{" "}
                      </Label>
                    )}
                  </FormGroup>
                </Col>
                <Col md={4} className="CreateEmpInpCon">
                  <FormGroup>
                    <Label>Passport Number</Label>

                    <Input
                      placeholder="Passport Number"
                      type="text"
                      value={documentValues.passportNo}
                      onChange={(e) =>
                        setDocuValues({
                          ...documentValues,
                          passportNo: e.target.value,
                        })
                      }
                    />
                    {passporterrorMessage && (
                      <Label
                        className="error"
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                      >
                        {" "}
                        {passporterrorMessage}{" "}
                      </Label>
                    )}
                  </FormGroup>
                </Col>
              </Row>
              <Row style={{ display: "flex", padding: "5px" }}>
                <Col md={4} className="CreateEmpInpCon">
                  <FormGroup>
                    <Label>UAN Number</Label>

                    <Input
                      placeholder="UAN Number"
                      type="text"
                      value={documentValues.uanNo}
                      onChange={(e) =>
                        setDocuValues({
                          ...documentValues,
                          uanNo: e.target.value,
                        })
                      }
                    />
                    {uanerrorMessage && (
                      <Label
                        className="error"
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                      >
                        {" "}
                        {uanerrorMessage}{" "}
                      </Label>
                    )}
                  </FormGroup>
                </Col>
                <Col md={4} className="CreateEmpInpCon">
                  <FormGroup>
                    <Label>PF Number</Label>

                    <Input
                      placeholder="PF Number"
                      type="text"
                      value={documentValues.pfNo}
                      onChange={(e) =>
                        setDocuValues({
                          ...documentValues,
                          pfNo: e.target.value,
                        })
                      }
                    />
                    {pferrorMessage && (
                      <Label
                        className="error"
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                      >
                        {" "}
                        {pferrorMessage}{" "}
                      </Label>
                    )}
                  </FormGroup>
                </Col>
                <Col md={4} className="CreateEmpInpCon">
                  <FormGroup>
                    <Label>ESI Number</Label>

                    <Input
                      placeholder="ESI Number"
                      type="text"
                      value={documentValues.esiNo}
                      onChange={(e) =>
                        setDocuValues({
                          ...documentValues,
                          esiNo: e.target.value,
                        })
                      }
                    />
                    {esierrorMessage && (
                      <Label
                        className="error"
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                      >
                        {" "}
                        {esierrorMessage}{" "}
                      </Label>
                    )}
                  </FormGroup>
                </Col>
              </Row>
              {/* *********************************************** Medical Details *************************************************** */}
              <h4>Medical Details</h4>
              <hr style={{ padding: "5px" }}></hr>
              <Row style={{ display: "flex", padding: "5px" }}>
                <Col md={6} className="CreateEmpInpCon">
                  <FormGroup>
                    <Label>1st Vaccination Date</Label>
                    <span
                      style={{
                        paddingLeft: "5px",
                        color: "red",
                        fontSize: "15px",
                      }}
                    >
                      *
                    </span>
                    {/* <Input
                    type="date"
                     value={documentValues.vaccination1Date}
                     onChange={(e)=>setDocuValues({...documentValues,vaccination1Date:e.target.value})}
                  /> */}
                    <CustomDatePicker
                      wrapperClassName="datepicker"
                      className="form-control"
                      dateFormat="dd/MM/yyyy"
                      // selected={inputValues.dob}
                      selected={
                        documentValues.vaccination1Date
                          ? new Date(documentValues.vaccination1Date)
                          : ""
                      }
                      onChange={(date) =>
                        setDocuValues({
                          ...documentValues,
                          vaccination1Date: date,
                        })
                      }
                    />
                    {v1errorMessage && (
                      <Label
                        className="error"
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                      >
                        {" "}
                        {v1errorMessage}{" "}
                      </Label>
                    )}
                  </FormGroup>
                </Col>
                <Col md={6} className="CreateEmpInpCon">
                  <FormGroup>
                    <Label>2nd Vaccination Date</Label>

                    {
                      /* <Input
                    type="date"
                    value={documentValues.vaccination2Date}
                    onChange={(e)=>setDocuValues({...documentValues,vaccination2Date:e.target.value})}
                  /> */
                      <CustomDatePicker
                        wrapperClassName="datepicker"
                        className="form-control"
                        dateFormat="dd/MM/yyyy"
                        // selected={inputValues.dob}
                        selected={
                          documentValues.vaccination2Date
                            ? new Date(documentValues.vaccination2Date)
                            : ""
                        }
                        onChange={(date) =>
                          setDocuValues({
                            ...documentValues,
                            vaccination2Date: date,
                          })
                        }
                      />
                    }
                    {v2errorMessage && (
                      <Label
                        className="error"
                        style={{
                          paddingLeft: "14px",
                          color: "red",
                          fontSize: "14px",
                        }}
                      >
                        {" "}
                        {v2errorMessage}{" "}
                      </Label>
                    )}
                  </FormGroup>
                </Col>
              </Row>
              <FormGroup style={{ float: "right" }}>
                <Button
                  variant="outlined"
                  color="primary"
                  onClick={() => setActiveStep(activeStep - 1)}
                >
                  Back
                </Button>
                {!useage ? (
                  <Button
                    variant="outlined"
                    color="primary"
                    style={{ marginLeft: "5px" }}
                    onClick={handleSubmit}
                  >
                    Submit
                  </Button>
                ) : (
                  <Button
                    variant="contained"
                    color="primary"
                    style={{ marginLeft: "5px" }}
                    onClick={handleUpdate}
                  >
                    Update
                  </Button>
                )}
              </FormGroup>
            </Form>
          </Form>
        </Container>
      </CCard>
      <Toaster />
    </>
  );
}
