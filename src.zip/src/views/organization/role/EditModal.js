import React, { useState } from "react";
import {
  MDBBtn,
  MDBModal,
  MDBModalDialog,
  MDBModalContent,
  MDBModalHeader,
  MDBModalTitle,
  MDBModalBody,
  MDBModalFooter,
} from "mdb-react-ui-kit";
import { updateRole } from "src/utility/apiService";
import { toast, Toaster } from "react-hot-toast";
import { CContainer, CFormInput } from "@coreui/react";
import CIcon from "@coreui/icons-react";
import { Col, Row, Label } from "reactstrap";
import { cilArrowCircleLeft } from "@coreui/icons";
import { Typography } from "@mui/material";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box/Box";

export const EditModal = (props) => {
  const { open, setOpen, data,menuId  } = props;
  const [active, setActive] = useState(data.isActive);
  const [block, setBlock] = useState(data.isBlock);
  const [role, setRole] = useState(data.roleName);
  const toggle = () => setOpen(!open);
  const update = async () => {
    let updates = { isActive: !active,menuId  };
    try {
      let response = await updateRole(data._id, updates);
      if (!response.ok) {
        return toast.error(response.data.message);
      }
      toast.success(response.data.message);
      setOpen(!open);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      <MDBModal show={open} setShow={setOpen} tabIndex="-1">
        <MDBModalDialog centered>
          <MDBModalContent>
            <MDBModalHeader>
              <MDBModalTitle>Update</MDBModalTitle>
              <MDBBtn
                className="btn-close"
                color="none"
                onClick={toggle}
              ></MDBBtn>
            </MDBModalHeader>
            <MDBModalBody>
              <Typography>
                Are you sure you wanna {active == true ? "Block" : "Activate"}
              </Typography>
            </MDBModalBody>

            <MDBModalFooter>
              <Button variant="contained"  onClick={update} color={"primary"} >
                {active == true ? "Block" : "Activate"}
              </Button>
            </MDBModalFooter>
          </MDBModalContent>
        </MDBModalDialog>
      </MDBModal>
      <Toaster />
    </>
  );
};

// export default EditModal

export const RoleDelete = (props) => {
  const { open1, setOpen1, data,menuId  } = props;
  const toggle = () => setOpen1(!open1);
  const update = async () => {
    let updates = { isBlock: true,menuId  };
    try {
      let response = await updateRole(data._id, updates);
      if (!response.ok) {
        return toast.error(response.data.message);
      }
      toast.success(response.data.message);
      setOpen1(!open1);
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <>
      <MDBModal show={open1} setShow={setOpen1} tabIndex="-1">
        <MDBModalDialog centered>
          <MDBModalContent>
            <MDBModalHeader>
              <MDBModalTitle>Delete</MDBModalTitle>
              <MDBBtn
                className="btn-close"
                color="none"
                onClick={toggle}
              ></MDBBtn>
            </MDBModalHeader>
            <MDBModalBody>
              <p>Are you sure you want to delete this role?</p>
            </MDBModalBody>

            <MDBModalFooter>
              {/* <CustomButton text="cancel" onClick={toggle} color={"danger"}/> */}
              <Button autoCapitalize="false" variant="contained" onClick={update} color={"primary"} >
                Delete
              </Button>
            </MDBModalFooter>
          </MDBModalContent>
        </MDBModalDialog>
      </MDBModal>
      <Toaster />
    </>
  );
};

export const RoleRecover = (props) => {
  const { open, setOpen, data, getAccess,menuId  } = props;
  const toggle = () => setOpen(!open);
  const recover = async () => {
    let updates = { isBlock: false,menuId  };
    try {
      let response = await updateRole(data._id, updates);
      if (!response.ok) {
        return toast.error(response.data.message);
      }
      toast.success(response.data.message);
      setOpen(!open);
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <>
      <MDBModal show={open} setShow={setOpen} tabIndex="-1">
        <MDBModalDialog centered>
          <MDBModalContent>
            <MDBModalHeader>
              <MDBModalTitle>Recover</MDBModalTitle>
              <MDBBtn
                className="btn-close"
                color="none"
                onClick={toggle}
              ></MDBBtn>
            </MDBModalHeader>
            <MDBModalBody>
              <p>Are you sure you want to Recover this role?</p>
            </MDBModalBody>

            <MDBModalFooter>
              <Button
                variant="contained"
                onClick={recover}
                color={"primary"}
              >
                Recover
              </Button>
            </MDBModalFooter>
          </MDBModalContent>
        </MDBModalDialog>
      </MDBModal>
      <Toaster />
    </>
  );
};

export const NameUpdate = (props) => {
  const { open, setOpen, data,menuId  } = props;
  const [role, setRole] = useState(data.roleName);
  const [err, setErr] = useState("");
  const toggle = () => setOpen(!open);
  const reset = () => {
    setErr("");
    setRole("");
  };
  const update = async () => {
    let updates = { roleName: role,menuId  };
    if (role == "") {
      return setErr("Please enter a role name");
    } else {
      setErr("");
    }
    try {
      let response = await updateRole(data._id, updates);
      if (!response.ok) {
        return toast.error(response.data.message);
      }
      toast.success(response.data.message);
      setOpen(!open);
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <>
      <div>
        <div
          style={{
            flexDirection: "row",
            position: "relative",
            display: "flex",
            borderRadius: "20px",
            marginLeft: "0.5rem",
            alignItems: "center",
          }}
        >
          <CContainer style={{ display: "contents" }}>
            <CIcon
              icon={cilArrowCircleLeft}
              size="xl"
              style={{
                marginTop: "1rem",
                marginLeft: "1rem",
                cursor: "pointer",
              }}
              onClick={toggle}
            />
            <h1
              style={{
                fontSize: "1.5rem",
                fontWeight: "500",
                marginLeft: "3.8rem",
                position: "absolute",
                top: "13px",
              }}
            >
              Update Role
            </h1>
          </CContainer>
        </div>
        <div
          className="cusInpFullCon"
          style={{
            position: "relative",
            marginTop: "3rem",
            marginRight: "5rem",
          }}
        >
          <CContainer
            className="cusInpFullWrap"
            style={{ marginLeft: "3.2rem", marginTop: "1rem" }}
          >
            <Row>
              <Col
                md={6}
                className="cusInpCon"
                style={{ minWidth: "300px", maxWidth: "300px" }}
              >
                <Label>
                  Role Name
                  <span
                    style={{
                      paddingLeft: "5px",
                      color: "red",
                      fontSize: "15px",
                    }}
                  >
                    *
                  </span>
                </Label>
                <CFormInput
                  id="exampleFormControlInput1"
                  placeholder="Enter Role Name"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                />
                {err ? <p style={{ color: "red" }}>{err}</p> : null}
              </Col>
            </Row>
          </CContainer>
        </div>
        <Box
          mt={"30px"}
          sx={{
            display: "flex",
            flexDirection: "row",
            flexWrap: "wrap",
            justifyContent: "end",
          }}
        >
          <Button
            type="reset"
            variant="outlined"
            aria-label="fingerprint"
            sx={{
              display: "flex",
              margin: "12px",
              alignSelf: "left",
            }}
            color="primary"
            onClick={reset}
          >
            Reset
          </Button>
          <Button
            variant="contained"
            aria-label="fingerprint"
            sx={{
              display: "flex",
              margin: "12px",
              alignSelf: "left",
            }}
            color={"primary"}
            onClick={update}
          >
            Update
          </Button>
        </Box>
      </div>
    </>
  );
};
