import React, { useContext, useEffect, useState } from "react";
import { toast, Toaster } from "react-hot-toast";
import CIcon from "@coreui/icons-react";
import { cilArrowCircleLeft } from "@coreui/icons";
import { CContainer, CFormInput, CFormText } from "@coreui/react";
import { createRole, getAccessForMenu, getallRole, getRoleMenu } from "src/utility/apiService";
import CustomTable from "src/custom/Table";
import { Switch } from "@mui/material";
import { EditModal, NameUpdate, RoleDelete, RoleRecover } from "./EditModal";
import { Col, Row, Label } from "reactstrap";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box/Box";
import "./styles.css";
import { RoleMenuAccessContext } from "src/context/roleMenuContext";
import {HiPencilSquare} from 'react-icons/hi2'
import {MdDeleteSweep} from 'react-icons/md'
import {GiReturnArrow} from 'react-icons/gi'

const Role = ({ menuId }) => {
  const [open, setOpen] = useState(false);
  const [getAccess, setGetAccess] = useState();
  const [id, setId] = useState({});
  const [active, setActive] = useState(false);
  const [open2, setOpen2] = useState(false);
  const [modal, setModal] = useState(false);
  const [update, setUpdate] = useState(false);
  const [modal2, setModal2] = useState(false);
  const [recover, setRecover] = useState(false);
  const [role, setRole] = useState("");
  const [err, setErr] = useState("");
  const [data, setData] = useState([]);
  const [data2, setData2] = useState([]);
  const [columns, setColumns] = useState([
    {
      Header: "SI No",
      id: "index",
      accessor: (row, index) => (
        <div style={{ textAlign: "center" }}>{index + 1}</div>
      ),
    },
    {
      Header: "Role Name",
      accessor: "roleName",
    },
    {
      Header: "Role Code",
      accessor: "roleCode",
    },
    {
      Header: "Status",
      accessor: "status",
      disableSortBy: true,
    },
    {
      Header: "Edit",
      accessor: "edit",
      disableSortBy: true,
    },
    {
      Header: "Delete",
      accessor: "delete",
      disableSortBy: true,
    },
  ]);
  // columns2
  let columns2 = [
    {
      Header: "SI No",
      id: "index",
      accessor: (row, index) => (
        <div style={{ textAlign: "center" }}>{index + 1}</div>
      ),
    },
    {
      Header: "Role Name",
      accessor: "roleName",
    },
    {
      Header: "Role Code",
      accessor: "roleCode",
    },
    {
      Header: "Recover",
      accessor: "edit",
      disableSortBy: true,
    },
  ];

  const toggle = () => setOpen(!open);
  const reset = () => {
    setErr("");
    setRole("");
  };

  let roleMenuAccess = useContext(RoleMenuAccessContext);

  useEffect(() => {
    let fetchData = async () => {
      try {
        let res = await getAccessForMenu(roleMenuAccess?.roleId, menuId);
        setGetAccess(res.data.data);
        if ( !res.data.data?.isOwner && res.data.data?.update == false ) {
          setColumns((pState) =>
            pState.filter((item) => item.Header != "Edit")
          );
          setColumns((pState) =>
            pState.filter((item) => item.Header != "Delete")
          );
        }
      } catch (error) {
        console.log(error.message);
      }
    };
    fetchData();
  }, [menuId]);


  // ***********************  api's  ***********************
  useEffect(()=>{
 let res=getRoleMenu()
  },[])
  useEffect(() => {
    const roleData = async () => {
      try {
        let response = await getallRole();
        let arr = [];
        let arr2 = [];
        response.data.data?.map((item, index) => {
          if (item.isBlock == false) {
            arr.push({
              ...item,
              status: (
                <center>
                  {" "}
                  <Switch
                    onChange={(e) => {}}
                    checked={item?.isActive}
                    disabled={!getAccess?.isOwner && getAccess?.update == false  }
                    onClick={() => {
                      setModal(!modal), setId(item);
                    }}
                    color="success"
                  />
                </center>
              ),
              edit: (
                <center>
                     <HiPencilSquare
                      style={{ cursor: "pointer" }}
                      size={25}
                      onClick={() => {
                        setUpdate(!update), setId(item);
                      }}
                    ></HiPencilSquare>
                </center>
              ),
              delete: (
                <center>
                    <MdDeleteSweep
                      style={{ cursor: "pointer" }}
                      size={25}
                      onClick={() => {
                        setModal2(!modal2), setId(item);
                      }}
                    ></MdDeleteSweep>
                </center>
              ),
            });
          }
          // Deleted data
          if (item.isBlock == true) {
            arr2.push({
              ...item,
              edit: (
                <center>
                  <GiReturnArrow
                      style={{ cursor: "pointer" }}
                      size={25}
                      onClick={() => {
                        setOpen2(!open2), setId(item)
                      }}
                    ></GiReturnArrow>
                </center>
              ),
            });
          } else {
            return null;
          }
        });
        setData2(arr2);
        setData(arr);
      } catch (error) {
        console.log(error);
      }
    };
    roleData();
  }, [open, modal, modal2, open2, update,getAccess ]);

  const initiateRole = async () => {
    if (!role) {
      return setErr("Role is required");
    }
    setErr("");
    try {
      let response = await createRole({ roleName: role,menuId  });
      if (!response.ok) {
        return toast.error(response.data.message);
      }
      toast.success(response.data.message);
      setOpen(!open);
    } catch (error) {
      console.log(error);
    }
  };
  const handleUpdate = async () => {
    let response = await updateRole(id._id, { roleName: role,menuId });
    console.log(response);
  };
  // console.log("data", id._id);
  return (
    <div
      style={{
        width: "100%",
        minHeight: "calc(100vh - 190px)",
        backgroundColor: "white",
        borderRadius: "20px",
      }}
    >
      {!update ? (
        <>
          {!recover ? (
            <>
              {!open ? (
                <>
                  <div
                    style={{
                      display: "flex",
                      flexWrap: "wrap",
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    <h1
                      style={{
                        fontSize: "1.5rem",
                        fontWeight: "500",
                        padding: "20px",
                        paddingRight: "5px",
                        wordWrap: "break-word",
                      }}
                    >
                      Role
                    </h1>
                   {getAccess?.isOwner || getAccess?.create ? <Button
                      style={{
                        marginRight: "1rem",
                      }}
                      onClick={toggle}
                      variant="contained"
                      color={"primary"}
                    >Create</Button>:null}
                  </div>
                  {modal2 && (
                    <RoleDelete open1={modal2} setOpen1={setModal2} data={id}  menuId={menuId}  />
                  )}
                  {modal ? (
                    <EditModal open={modal} setOpen={setModal} data={id} menuId={menuId}  />
                  ) : null}
                  <CContainer fluid>
                    <CustomTable
                      columns={columns}
                      data={data}
                      onClick={getAccess?.isOwner || getAccess?.update ? () => setRecover(!recover) : null}
                    />
                  </CContainer>
                </>
              ) : (
                <>
                  <div>
                    <div
                      style={{
                        flexDirection: "row",
                        position: "relative",
                        display: "flex",
                        borderRadius: "20px",
                        marginLeft: "0.5rem",
                        alignItems: "center",
                      }}
                    >
                      <CContainer style={{ display: "contents" }}>
                        <CIcon
                          icon={cilArrowCircleLeft}
                          size="xl"
                          style={{
                            marginTop: "1rem",
                            marginLeft: "1rem",
                            cursor: "pointer",
                          }}
                          onClick={toggle}
                        />
                        <h1
                          style={{
                            fontSize: "1.5rem",
                            fontWeight: "500",
                            marginLeft: "3.8rem",
                            position: "absolute",
                            top: "13px",
                          }}
                        >
                          Create Role
                        </h1>
                      </CContainer>
                    </div>
                    <div
                      className="cusInpFullCon"
                      style={{
                        position: "relative",
                        marginTop: "3rem",
                        marginRight: "5rem",
                      }}
                    >
                      <CContainer
                        className="cusInpFullWrap"
                        style={{ marginLeft: "3.2rem", marginTop: "1rem" }}
                      >
                        <Row>
                          <Col
                            md={6}
                            className="cusInpCon"
                            style={{ minWidth: "300px", maxWidth: "300px" }}
                          >
                            <Label>
                              Role Name
                              <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                            </Label>
                            <CFormInput
                              id="exampleFormControlInput1"
                              placeholder="Enter Role Name"
                              // text="give a valid Role name."
                              value={role}
                              onChange={(e) => setRole(e.target.value)}
                              // width="400px"
                            />
                            {err ? <p style={{ color: "red" }}>{err}</p> : null}
                          </Col>
                        </Row>
                      </CContainer>
                    </div>
                    <Box
                      mt={"30px"}
                      sx={{
                        display: "flex",
                        flexDirection: "row",
                        flexWrap: "wrap",
                        justifyContent: "end",
                      }}
                    >
                      <Button
                        type="reset"
                        variant="outlined"
                        aria-label="fingerprint"
                        sx={{
                          display: "flex",
                          margin: "12px",
                          alignSelf: "left",
                        }}
                        color={"primary"}
                        onClick={reset}
                      >
                        Reset
                      </Button>
                      <Button
                      autoCapitalize="none"
                        variant="contained"
                        aria-label="fingerprint"
                        sx={{
                          display: "flex",
                          margin: "12px",
                          alignSelf: "left",
                        }}
                        color={"primary"}
                        onClick={initiateRole}
                      >
                        Submit
                      </Button>
                    </Box>
                  </div>
                </>
              )}
            </>
          ) : (
            <>
              <div
                style={{
                  flexDirection: "row",
                  position: "relative",
                  display: "flex",
                  borderRadius: "20px",
                  marginLeft: "0.5rem",
                  alignItems: "center",
                }}
              >
                <CContainer style={{ display: "contents" }}>
                  <CIcon
                    icon={cilArrowCircleLeft}
                    size="xl"
                    style={{
                      marginTop: "1rem",
                      marginLeft: "1rem",
                      cursor: "pointer",
                    }}
                    onClick={() => setRecover(!recover)}
                  />
                  <h1
                    style={{
                      fontSize: "1.5rem",
                      fontWeight: "600",
                      marginLeft: "3.8rem",
                      position: "absolute",
                      top: "13px",
                    }}
                  >
                    Deleted Role
                  </h1>
                </CContainer>
              </div>
              {open2 && (
                <RoleRecover open={open2} setOpen={setOpen2} data={id} getAccess={getAccess} menuId={menuId}  />
              )}
              <CContainer fluid>
                <CustomTable columns={columns2} data={data2} />
              </CContainer>
            </>
          )}
        </>
      ) : (
        <>
          <NameUpdate open={update} setOpen={setUpdate} data={id}  menuId={menuId} />
        </>
      )}

      <Toaster />
    </div>
  );
};

export default Role;
