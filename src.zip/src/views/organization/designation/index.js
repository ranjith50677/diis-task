import React, { useContext, useEffect, useState } from "react";
import { toast, Toaster } from "react-hot-toast";
import CIcon from "@coreui/icons-react";
import { cilArrowCircleLeft, cilPlus } from "@coreui/icons";
import { CContainer, CFormInput, CFormText } from "@coreui/react";
import {
  createDesignation,
  getAccessForMenu,
  getallDep,
  getallDes,
} from "src/utility/apiService";
import CustomTable from "src/custom/Table";
import {
  DesRecover,
  EditDesignation,
  DesDelete,
  NameUpdate,
} from "./EditModal";
import CustomSelect from "src/custom/Select";
import { Row, Col } from "reactstrap";
import { Switch, Typography } from "@mui/material";
import FormGroup from "@mui/material/FormGroup";
import { Label } from "reactstrap";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box/Box";
import { RoleMenuAccessContext } from "src/context/roleMenuContext";
import {HiPencilSquare} from 'react-icons/hi2'
import {MdDeleteSweep} from 'react-icons/md'
import {GiReturnArrow} from 'react-icons/gi'

const Designation = ({menuId}) => {
  const [open, setOpen] = useState(false);
  const [open2, setOpen2] = useState(false);
  const [recover, setRecover] = useState(false);
  const [update, setUpdate] = useState(false);
  const [id, setId] = useState({});
  const [getAccess, setGetAccess] = useState({});
  const [depId, setDepId] = useState("");
  const [modal, setModal] = useState(false);
  const [modal2, setModal2] = useState(false);
  const [des, setDes] = useState("");
  const [err, setErr] = useState("");
  const [depErr, setDepErr] = useState("");
  const [data, setData] = useState([]);
  const [data2, setData2] = useState([]);
  const [selected, setSelected] = useState("");
  const [columns,setColumns] = useState([
    {
      Header: "SI No",
      id: "index",
      accessor: (row, index) => (
        <div style={{ textAlign: "center" }}>{index + 1}</div>
      ),
    },
    {
      Header: "Designation Name",
      accessor: "designationName",
    },
    {
      Header: "Designation Code",
      accessor: "designationCode",
    },
    {
      Header: "Status",
      accessor: "status",
      disableSortBy: true,
    },
    {
      Header: "Edit",
      accessor: "edit",
      disableSortBy: true,
    },
    {
      Header: "Delete",
      accessor: "delete",
      disableSortBy: true,
    },
  ]);
  // columns2
  let columns2 = [
    {
      Header: "SI No",
      id: "index",
      accessor: (row, index) => (
        <div style={{ textAlign: "center" }}>{index + 1}</div>
      ),
    },
    {
      Header: "Designation Name",
      accessor: "designationName",
    },
    {
      Header: "Designation Code",
      accessor: "designationCode",
    },
    {
      Header: "Recover",
      accessor: "edit",
      disableSortBy: true,
    },
  ];
  
  const reset = () => {
    setErr("");
    setDes("");
    setDepErr("");
    setSelected("");
  };
  const toggle = () => setOpen(!open);

  let roleMenuAccess = useContext(RoleMenuAccessContext);

  // ***********************  api's  ***********************
  useEffect(() => {
    let fetchData = async () => {
      try {
        let res = await getAccessForMenu(roleMenuAccess?.roleId, menuId);
        setGetAccess(res.data.data);
        if ( !res.data.data?.isOwner && res.data.data?.update == false ) {
          setColumns((pState) =>
            pState.filter((item) => item.Header != "Edit")
          );
          setColumns((pState) =>
            pState.filter((item) => item.Header != "Delete")
          );
        }
      } catch (error) {
        console.log(error.message);
      }
    };
    fetchData();
  }, [menuId]);


  useEffect(() => {
    const depData = async () => {
      try {
        let response = await getallDep();
        let arr = [];
        response.data.data?.map((item, index) => {
          if (item.isBlock == false) {
            arr.push({
              id: item._id,
              value: item.deptName,
              label: item.deptName,
            });
          }
          setDepId(arr);
        });
      } catch (error) {
        console.log(error);
      }
    };
    const desData = async () => {
      try {
        let response = await getallDes();
        let arr = [];
        let arr2 = [];
        response.data.data?.map((item, index) => {
          if (item.isBlock == false) {
            arr.push({
              ...item,
              status: (
                <center>
                  <Switch
                    disabled={!getAccess?.isOwner && getAccess?.update == false  }
                    onChange={(e) => {}}
                    checked={item?.isActive}
                    onClick={() => {
                      setModal(!modal), setId(item);
                    }}
                    color="success"
                  />
                </center>
              ),
              edit: (
                <center>
                  <HiPencilSquare
                    style={{ cursor: "pointer" }}
                    size={25}
                    onClick={() => {
                      setUpdate(!update), setId(item);
                    }}
                  ></HiPencilSquare>
                </center>
              ),
              delete: (
                <center>
                  <MdDeleteSweep
                    style={{ cursor: "pointer" }}
                    size={25}
                    onClick={() => {
                      setModal2(!modal2), setId(item);
                    }}
                  ></MdDeleteSweep>
                </center>
              ),
            });
          }
          // Deleted data
          if (item.isBlock == true) {
            arr2.push({
              ...item,
              edit: (
                <center>
                  <GiReturnArrow
                    style={{ cursor: "pointer" }}
                    size={25}
                    onClick={() => {
                      setOpen2(!open2), setId(item)
                    }}
                  ></GiReturnArrow>
                </center>
              ),
            });
          } else {
            return null;
          }
        });
        setData2(arr2);
        setData(arr);
      } catch (error) {
        console.log(error);
      }
    };
    depData();
    desData();
  }, [open, modal, modal2, open2, update, getAccess]);
  const initiateDes = async () => {
    if (!selected) {
      setDepErr("Deparment is required!");
    } else {
      setDepErr("");
    }
    if (!des) {
      setErr("Designation is required!");
    } else {
      setErr("");
    }
    if (des && selected) {
      try {
        let response = await createDesignation( selected.id,{designationName: des,menuId});
        if (!response.ok) {
          return toast.error(response.data.message);
        }
        toast.success(response.data.message);
        setOpen(!open);
      } catch (error) {
        console.log(error);
      }
    }
  };
  return (
    <div
      style={{
        width: "100%",
        minHeight: "calc(100vh - 190px)",
        backgroundColor: "white",
        borderRadius: "20px",
      }}
    >
      {!update ? (
        <>
          {!recover ? (
            <>
              {!open ? (
                <>
                  <div
                    style={{
                      display: "flex",
                      flexWrap: "wrap",
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    <h1
                      style={{
                        fontSize: "1.5rem",
                        fontWeight: "500",
                        padding: "20px",
                        paddingRight: "5px",
                        wordWrap: "break-word",
                      }}
                    >
                      Designation
                    </h1>
                    {getAccess?.isOwner || getAccess?.create ?<Button
                      // color="primary"
                      style={{ marginRight: "1rem", marginLeft: "10px" }}
                      onClick={toggle}
                      color={"primary"}
                      variant="contained"
                    >
                      Create
                    </Button>:null}
                  </div>
                  {modal2 && (
                    <DesDelete open1={modal2} setOpen1={setModal2} data={id} menuId={menuId} />
                  )}
                  {modal && (
                    <EditDesignation
                      open={modal}
                      setOpen={setModal}
                      data={id} 
                      menuId={menuId}
                    />
                  )}
                  <CContainer fluid>
                    <CustomTable
                      columns={columns}
                      data={data}
                      onClick={() => setRecover(!recover)}
                    />
                  </CContainer>
                </>
              ) : (
                <>
                  <div>
                    <div
                      style={{
                        flexDirection: "row",
                        position: "relative",
                        display: "flex",
                        borderRadius: "20px",
                        marginLeft: "0.5rem",
                        alignItems: "center",
                      }}
                    >
                      <CContainer style={{ display: "contents" }}>
                        <CIcon
                          icon={cilArrowCircleLeft}
                          size="xl"
                          style={{
                            marginTop: "1rem",
                            marginLeft: "1rem",
                            cursor: "pointer",
                          }}
                          onClick={toggle}
                        />
                        <h1
                          style={{
                            fontSize: "1.5rem",
                            fontWeight: "500",
                            marginLeft: "3.8rem",
                            position: "absolute",
                            top: "13px",
                            paddingRight: "0px",
                          }}
                        >
                          Create Designation
                        </h1>
                      </CContainer>
                    </div>
                    <div
                      className="cusInpFullCon"
                      style={{
                        position: "relative",
                        marginTop: "3rem",
                        // width: "50%",
                        marginRight: "5rem",
                      }}
                    >
                      <CContainer
                        className="cusInpFullWrap"
                        style={{ marginLeft: "3.2rem" }}
                      >
                        <Row>
                          <Col
                            md={6}
                            className="cusInpCon"
                            style={{ minWidth: "300px", maxWidth: "300px" }}
                          >
                            {" "}
                            <FormGroup>
                              <Label>
                                Select the Department
                                <span
                                  style={{
                                    paddingLeft: "5px",
                                    color: "red",
                                    fontSize: "15px",
                                  }}
                                >
                                  *
                                </span>
                              </Label>

                              <CustomSelect
                                // styles={{ width: "18rem" }}
                                option={depId}
                                selectedOptions={selected}
                                setSelectedOptions={setSelected}
                                isSearchable={true}
                                isMulti={false}
                                placeholder={"Select Department"}
                                name={"Select"}
                                style={{ marginButtom: "0.5rem" }}
                              />
                            </FormGroup>
                            {depErr ? (
                              <Typography style={{ color: "red" }}>
                                {depErr}
                              </Typography>
                            ) : null}
                          </Col>
                          <Col
                            md={6}
                            className="cusInpCon"
                            style={{ minWidth: "300px", maxWidth: "300px" }}
                          >
                            <Label>
                              Designation Name
                              <span
                                style={{
                                  paddingLeft: "5px",
                                  color: "red",
                                  fontSize: "15px",
                                }}
                              >
                                *
                              </span>
                            </Label>
                            <CFormInput
                              id="exampleFormControlInput1"
                              placeholder="Enter Designation Name"
                              value={des}
                              onChange={(e) => setDes(e.target.value)}
                            />
                            {err ? (
                              <Typography style={{ color: "red" }}>
                                {err}
                              </Typography>
                            ) : null}
                          </Col>
                        </Row>
                      </CContainer>
                    </div>
                    <Box
                      mt={"30px"}
                      sx={{
                        display: "flex",
                        flexDirection: "row",
                        flexWrap: "wrap",
                        justifyContent: "end",
                      }}
                    >
                      <Button
                        type="reset"
                        variant="outlined"
                        aria-label="fingerprint"
                        sx={{
                          display: "flex",
                          margin: "12px",
                          alignSelf: "left",
                        }}
                        color="primary"
                        onClick={reset}
                      >
                        Reset
                      </Button>
                      <Button
                        variant="contained"
                        aria-label="fingerprint"
                        sx={{
                          display: "flex",
                          margin: "12px",
                          alignSelf: "left",
                        }}
                        color={"primary"}
                        onClick={initiateDes}
                      >
                        Submit
                      </Button>
                    </Box>
                  </div>
                </>
              )}
            </>
          ) : (
            <>
              <div
                style={{
                  flexDirection: "row",
                  position: "relative",
                  display: "flex",
                  borderRadius: "20px",
                  marginLeft: "0.5rem",
                  alignItems: "center",
                }}
              >
                <CContainer fluid style={{ display: "contents" }}>
                  <CIcon
                    icon={cilArrowCircleLeft}
                    size="xl"
                    style={{
                      marginTop: "1rem",
                      marginLeft: "1rem",
                      cursor: "pointer",
                    }}
                    onClick={() => setRecover(!recover)}
                  />
                  <h1
                    style={{
                      fontSize: "1.5rem",
                      fontWeight: "600",
                      marginLeft: "3.8rem",
                      position: "absolute",
                      top: "13px",
                    }}
                  >
                    Deleted Designation
                  </h1>
                </CContainer>
              </div>
              {open2 && (
                <DesRecover open={open2} setOpen={setOpen2} data={id} menuId={menuId} />
              )}
              <CContainer fluid>
                <CustomTable columns={columns2} data={data2} />
              </CContainer>
            </>
          )}
        </>
      ) : (
        <>
          <NameUpdate open={update} setOpen={setUpdate} data={id} menuId={menuId} />
        </>
      )}

      <Toaster />
    </div>
  );
};

export default Designation;
