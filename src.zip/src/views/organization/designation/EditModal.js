import React, { useState } from "react";
import {
  MDBBtn,
  MDBModal,
  MDBModalDialog,
  MDBModalContent,
  MDBModalHeader,
  MDBModalTitle,
  MDBModalBody,
  MDBModalFooter,
} from "mdb-react-ui-kit";
import { updateDes } from "src/utility/apiService";
import { toast, Toaster } from "react-hot-toast";
import { CContainer, CFormInput } from "@coreui/react";
import { cilArrowCircleLeft } from "@coreui/icons";
import CIcon from "@coreui/icons-react";
import { Col, Label, Row } from "reactstrap";
import { Typography } from "@mui/material";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box/Box";

export const EditDesignation = (props) => {
  const { open, setOpen, data ,menuId} = props;
  const [active, setActive] = useState(data.isActive);
  const toggle = () => setOpen(!open);
  // api call to update the data
  const update = async () => {
    let updates = { isActive: !active,menuId };
    try {
      let response = await updateDes(data._id, updates);
      if (!response.ok) {
        return toast.error(response.data.message);
      }
      toast.success(response.data.message);
      setOpen(!open);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      <MDBModal show={open} setShow={setOpen} tabIndex="-1">
        <MDBModalDialog centered>
          <MDBModalContent>
            <MDBModalHeader>
              <MDBModalTitle>Update</MDBModalTitle>
              <MDBBtn
                className="btn-close"
                color="none"
                onClick={toggle}
              ></MDBBtn>
            </MDBModalHeader>
            <MDBModalBody>
              <Typography>
                Are you sure you wanna {active == true ? "Block" : "Activate"}{" "}
                this designation
              </Typography>
            </MDBModalBody>

            <MDBModalFooter>
              {/* <CustomButton text="cancel" onClick={toggle} color={"danger"} /> */}
              <Button variant="contained"  onClick={update} color={"primary"} >
                {active == true ? "Block" : "Activate"}
              </Button>
            </MDBModalFooter>
          </MDBModalContent>
        </MDBModalDialog>
      </MDBModal>
      <Toaster />
    </>
  );
};

export const DesDelete = (props) => {
  const { open1, setOpen1, data ,menuId} = props;
  const toggle = () => setOpen1(!open1);
  const update = async () => {
    let updates = { isBlock: true,menuId };
    try {
      let response = await updateDes(data._id, updates);
      if (!response.ok) {
        return toast.error(response.data.message);
      }
      toast.success(response.data.message);
      setOpen1(!open1);
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <>
      <MDBModal show={open1} setShow={setOpen1} tabIndex="-1">
        <MDBModalDialog centered>
          <MDBModalContent>
            <MDBModalHeader>
              <MDBModalTitle>Delete</MDBModalTitle>
              <MDBBtn
                className="btn-close"
                color="none"
                onClick={toggle}
              ></MDBBtn>
            </MDBModalHeader>
            <MDBModalBody>
              <p>Are you sure you want to delete this designation?</p>
            </MDBModalBody>

            <MDBModalFooter>
              {/* <CustomButton text="cancel" onClick={toggle} color={"danger"}/> */}
              <Button variant="contained" text="Delete" onClick={update} color={"primary"} >
                Delete
              </Button>
            </MDBModalFooter>
          </MDBModalContent>
        </MDBModalDialog>
      </MDBModal>
      <Toaster />
    </>
  );
};

export const DesRecover = (props) => {
  const { open, setOpen, data ,menuId} = props;
  const toggle = () => setOpen(!open);
  const recover = async () => {
    let updates = { isBlock: false,menuId };
    try {
      let response = await updateDes(data._id, updates);
      if (!response.ok) {
        return toast.error(response.data.message);
      }
      toast.success(response.data.message);
      setOpen(!open);
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <>
      <MDBModal show={open} setShow={setOpen} tabIndex="-1">
        <MDBModalDialog centered>
          <MDBModalContent>
            <MDBModalHeader>
              <MDBModalTitle>Recover</MDBModalTitle>
              <MDBBtn
                className="btn-close"
                color="none"
                onClick={toggle}
              ></MDBBtn>
            </MDBModalHeader>
            <MDBModalBody>
              <p>Are you sure you want to Recover this designation?</p>
            </MDBModalBody>

            <MDBModalFooter>
              {/* <CustomButton text="cancel" onClick={toggle} color={"danger"}/> */}
              <Button
                onClick={recover}
                color={"primary"}
                variant="contained"
              >
                Recover
              </Button>
            </MDBModalFooter>
          </MDBModalContent>
        </MDBModalDialog>
      </MDBModal>
      <Toaster />
    </>
  );
};

export const NameUpdate = (props) => {
  const { open, setOpen, data ,menuId} = props;
  const [des, setDes] = useState(data.designationName);
  const [err, setErr] = useState("");
  const toggle = () => setOpen(!open);
  const reset = () => {
    setErr("");
    setDes("");
  };
  const update = async () => {
    let updates = { designationName: des,menuId };
    if (des == "") {
      return setErr("Please enter a designation name");
    } else {
      setErr("");
    }
    try {
      let response = await updateDes(data._id, updates);
      if (!response.ok) {
        return toast.error(response.data.message);
      }
      toast.success(response.data.message);
      setOpen(!open);
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <>
      <div>
        <div
          style={{
            flexDirection: "row",
            position: "relative",
            display: "flex",
            borderRadius: "20px",
            marginLeft: "0.5rem",
            alignItems: "center",
          }}
        >
          <CContainer style={{ display: "contents" }}>
            <CIcon
              icon={cilArrowCircleLeft}
              size="xl"
              style={{
                marginTop: "1rem",
                marginLeft: "1rem",
                cursor: "pointer",
              }}
              onClick={toggle}
            />
            <h1
              style={{
                fontSize: "1.5rem",
                fontWeight: "500",
                marginLeft: "3.8rem",
                position: "absolute",
                top: "13px",
              }}
            >
              Update Designation
            </h1>
          </CContainer>
        </div>
        <div
          className="cusInpFullCon"
          style={{
            position: "relative",
            marginTop: "3rem",
            marginRight: "5rem",
          }}
        >
          <CContainer
            className="cusInpFullWrap"
            style={{ marginLeft: "3.2rem", marginTop: "1rem" }}
          >
            <Row>
              <Col
                md={6}
                className="cusInpCon"
                style={{ minWidth: "300px", maxWidth: "300px" }}
              >
                <Label>
                  Designation Name
                  <span
                    style={{
                      paddingLeft: "5px",
                      color: "red",
                      fontSize: "15px",
                    }}
                  >
                    *
                  </span>
                </Label>
                <CFormInput
                  id="exampleFormControlInput1"
                  placeholder="Enter designation name"
                  // text="give a valid Des name."
                  value={des}
                  onChange={(e) => setDes(e.target.value)}
                  // width="400px"
                />
                {err ? <p style={{ color: "red" }}>{err}</p> : null}
              </Col>
            </Row>
          </CContainer>
        </div>
        <Box
          mt={"30px"}
          sx={{
            display: "flex",
            flexDirection: "row",
            flexWrap: "wrap",
            justifyContent: "end",
          }}
        >
          <Button
            type="reset"
            variant="outlined"
            aria-label="fingerprint"
            sx={{
              display: "flex",
              margin: "12px",
              alignSelf: "left",
            }}
            color="primary"
            onClick={reset}
          >
            Reset
          </Button>
          <Button
            variant="contained"
            aria-label="fingerprint"
            sx={{
              display: "flex",
              margin: "12px",
              alignSelf: "left",
            }}
            color={"primary"}
            onClick={update}
          >
            Update
          </Button>
        </Box>
      </div>
    </>
  );
};
