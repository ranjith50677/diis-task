import UploadVideo from "./header/upload";
import RecipeReviewCard from "./pages/Home/video";
import {HiHome} from 'react-icons/hi'
import {FaCloudUploadAlt} from 'react-icons/fa'
import {BiSolidUserAccount} from 'react-icons/bi'
import MyAccount from "./pages/profile/myAccount";

const routes=[
        { path: "/video", name: "Home", element:<RecipeReviewCard/> ,icon:<HiHome/>},
        { path: "/upload", name: "Upload", element:<UploadVideo/> ,icon:<FaCloudUploadAlt/> },
        { path: "/MyAccount", name: "My Account", element:<MyAccount/> ,icon:<BiSolidUserAccount/> }
]

export default routes;