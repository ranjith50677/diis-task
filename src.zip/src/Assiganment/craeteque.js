import React from 'react';
import { Divider } from 'antd';
import { cilChevronLeft } from "@coreui/icons";
import CIcon from "@coreui/icons-react";
import { MDBContainer, MDBRow, MDBCol, MDBInput, MDBIcon } from 'mdb-react-ui-kit';
import { Button, FormLabel } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const Create=()=>{
    let navigate = useNavigate();
    const back=()=>navigate('/dashboard')
    return(
        <>
         <CIcon
              icon={cilChevronLeft}
              size="xl"
              style={{
                marginTop: "1rem",
                marginLeft: "1rem",
                cursor: "pointer",
              }}
              onClick={back}
              />
         <h1 style={{marginLeft:"3rem", marginTop: "-3rem"}}>craete Question</h1>
        <Divider style={{backgroundColor:'black'}}/>
        <MDBContainer className="shadow-inner" style={{backgroundColor:'white',height:'300px'}} >
        <MDBRow >
        <MDBCol size='12'>
        <MDBInput placeholder='Question No' id='form1' type='text' />
        </MDBCol>
      </MDBRow>
      <br/>
        <MDBRow >
        <MDBCol size='5'>
        <MDBInput placeholder='Option A' id='form1' type='text' />
        </MDBCol>
        <MDBCol size='5'>
        <MDBInput placeholder='Option B' id='form1' type='text' />
        </MDBCol>
        </MDBRow >
        <br/>
        <MDBRow >
        <MDBCol size='5'>
        <MDBInput placeholder='Option C' id='form1' type='text' />
        </MDBCol>
        <MDBCol size='5'>
        <MDBInput placeholder='Option D' id='form1' type='text' />
        </MDBCol>
       </MDBRow>
    </MDBContainer>
     <br/>
    <Button variant="contained" style={{marginTop:"10%",marginLeft:"90%"}}>Submit
    </Button> 
    </>
    )
}

export default Create;