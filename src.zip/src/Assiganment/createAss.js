// import { Diversity1 } from '@mui/icons-material';
import React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import { Divider } from 'antd';
import { Button } from '@mui/material';
import { useState } from 'react';
import { useNavigate } from "react-router-dom";


const Assiganment=()=>{
  let navigate = useNavigate();
const create=()=>navigate('/dashboard')
    const Item = styled(Paper)(({ theme }) => ({
        backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
        ...theme.typography.body2,
        padding: theme.spacing(1),
        textAlign: 'center',
        color: theme.palette.text.secondary,
      }));
      
    return (
        <>
     <h1>Assiganment</h1>
        <Button variant="contained" style={{marginLeft:"93%",marginTop:"-100px"}} onClick={create}>create</Button>
      <Divider style={{backgroundColor:'black',marginTop:"-16px"}}/>
        <>
      <Box sx={{ width: '100%' }}>
            <Stack spacing={2}>
              <Item>
                <div>ran</div>
              </Item>
              <Item>Item 2</Item>
              <Item>Item 3</Item>
            </Stack>
          </Box>
        </>
        </>
      )
}
export default Assiganment;
