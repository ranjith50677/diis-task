import React, { useContext } from "react";
import { CNavGroup, CNavItem } from "@coreui/react";
import { MdDashboard } from "react-icons/md";

import _ from "lodash";
const _nav = () => {

  let commonRoute = [
    {
      component: CNavItem,
      name: "Dashboard",
      to: "/dashboard",
      order: 0,
      icon: <MdDashboard style={{ width: "30px", paddingLeft: "2px " }} />,
      badge: {
        color: "info",
      },
    },
    {
      component: CNavItem,
      name: "Assiganment",
      to: "/Assiganment",
      order: 0,
      icon: <MdDashboard style={{ width: "30px", paddingLeft: "2px " }} />,
      badge: {
        color: "info",
      },
    },
  ];


  return commonRoute;
 
};

export default _nav;