
let baseUrl = "http://192.168.1.43:7373/api/";

export const userLogin = async (body) => {
  const requestOptions = {
    method: "POST",
    mode: "cors",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  };
  const response = await fetch(`${baseUrl}user/login`, requestOptions);
  if (!response.ok) {
    let data = await response.json();
    return { data: data, ok: false };
  }
  let data = await response?.json();
  return { data: data, ok: true };
};

export const userReg = async (body) => {
  const requestOptions = {
    method: "POST",
    mode: "cors",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  };
  const response = await fetch(`${baseUrl}user/reg`, requestOptions);
  if (!response.ok) {
    let data = await response.json();
    return { data: data, ok: false };
  }
  let data = await response?.json();
  return { data: data, ok: true };
};
export const profile = async() => {
  let token = localStorage.getItem("token");
  let gettoken=JSON.parse(token)
  const requestOptions = {
    method: "GET",
    mode: "cors",
    headers: {
      "Content-Type": "application/json",
      token:gettoken
    },
 
  };
  const response = await fetch(`${baseUrl}user/profile`, requestOptions);
  if (!response.ok) {
    let data = await response.json();
    return { data: data, ok: false };
  }
  let data = await response?.json();
  return { data: data, ok: true };
};

export const Editprofile = async(body) => {
  let token = localStorage.getItem("token");
  let gettoken=JSON.parse(token)
  const requestOptions = {
    method: "PUT",
    mode: "cors",
    headers: {
      "Content-Type": "application/json",
      token:gettoken
    },
    body: JSON.stringify(body)
  };
  
  const response = await fetch(`${baseUrl}user/updateprofile`,requestOptions);
  if (!response.ok) {
    let data = await response.json();
    return { data: data, ok: false };
  }
  let data = await response?.json();
  return { data: data, ok: true };
};

export const videos = async() => {
  const requestOptions = {
    method: "GET",
    mode: "cors",
    headers: {
      "Content-Type": "application/json",
    },
 
  };
  const response = await fetch(`${baseUrl}video/all`, requestOptions);
  if (!response.ok) {
    let data = await response.json();
    return { data: data, ok: false };
  }
  let data = await response?.json();
  return { data: data, ok: true };
};

export const likes = async(id) => {
  console.log(id)
  let token = localStorage.getItem("token");
  let gettoken=JSON.parse(token)
  const requestOptions = {
    method: "PUT",
    mode: "cors",
    headers: {
      "Content-Type": "application/json",
      token:gettoken
    },
 
  };
  const response = await fetch(`${baseUrl}video/like/${id}`, requestOptions);
  if (!response.ok) {
    let data = await response.json();
    return { data: data, ok: false };
  }
  let data = await response?.json();
  return { data: data, ok: true };
}
export const unlikes = async(id) => {
  let token = localStorage.getItem("token");
  let gettoken=JSON.parse(token)
  const requestOptions = {
    method: "PUT",
    mode: "cors",
    headers: {
      "Content-Type": "application/json",
      token:gettoken
    },
 
  };
  const response = await fetch(`${baseUrl}video/unlikevideo/${id}`, requestOptions);
  if (!response.ok) {
    let data = await response.json();
    return { data: data, ok: false };
  }
  let data = await response?.json();
  return { data: data, ok: true };
}
export const Comment = async(id,body) => {
  let token = localStorage.getItem("token");
  let gettoken=JSON.parse(token)
  const requestOptions = {
    method: "PUT",
    mode: "cors",
    headers: {
      "Content-Type": "application/json",
      token:gettoken
    },
    body: JSON.stringify(body),
  };
  const response = await fetch(`${baseUrl}video/comment/${id}`, requestOptions);
  if (!response.ok) {
    let data = await response.json();
    return { data: data, ok: false };
  }
  let data = await response?.json();
  return { data: data, ok: true };
}

export const deleteComment = async(id,body) => {
  let token = localStorage.getItem("token");
  let gettoken=JSON.parse(token)
  const requestOptions = {
    method: "PUT",
    mode: "cors",
    headers: {
      "Content-Type": "application/json",
      token:gettoken
    },
    body: JSON.stringify(body),
  };
  const response = await fetch(`${baseUrl}video/commentdelete/${id}`, requestOptions);
  if (!response.ok) {
    let data = await response.json();
    return { data: data, ok: false };
  }
  let data = await response?.json();
  return { data: data, ok: true };
}
export const editComment = async(id,commentId,body) => {
  let token = localStorage.getItem("token");
  let gettoken=JSON.parse(token)
  const requestOptions = {
    method: "PUT",
    mode: "cors",
    headers: {
      "Content-Type": "application/json",
      token:gettoken
    },
    body: JSON.stringify(body),
  };
  const response = await fetch(`${baseUrl}video//updatecomment/${id}/${commentId}`, requestOptions);
  if (!response.ok) {
    let data = await response.json();
    return { data: data, ok: false };
  }
  let data = await response?.json();
  return { data: data, ok: true };
}

export const UserVideos = async() => {
  let token = localStorage.getItem("token");
  let gettoken=JSON.parse(token)
  const requestOptions = {
    method: "GET",
    mode: "cors",
    headers: {
      "Content-Type": "application/json",
      token:gettoken
    },
 
  };
  const response = await fetch(`${baseUrl}video/getvideo/user`, requestOptions);
  if (!response.ok) {
    let data = await response.json();
    return { data: data, ok: false };
  }
  let data = await response?.json();
  return { data: data, ok: true };
};
export const UserByIdVideos = async(id) => {
  const requestOptions = {
    method: "GET",
    mode: "cors",
    headers: {
      "Content-Type": "application/json",
    },
  };
  const response = await fetch(`${baseUrl}video/user/byid/${id}`, requestOptions);
  if (!response.ok) {
    let data = await response.json();
    return { data: data, ok: false };
  }
  let data = await response?.json();
  return { data: data, ok: true };
};
export const DeleteVideo = async(id) => {
  const requestOptions = {
    method: "DELETE",
    mode: "cors",
    headers: {
      "Content-Type": "application/json",
    },
  };
  const response = await fetch(`${baseUrl}video/delete/${id}`, requestOptions);
  if (!response.ok) {
    let data = await response.json();
    return { data: data, ok: false };
  }
  let data = await response?.json();
  return { data: data, ok: true };
};
