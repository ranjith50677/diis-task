import { createContext } from "react";
const Store = createContext(null);
export default Store;