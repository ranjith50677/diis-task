// import { Diversity1 } from '@mui/icons-material';
import React from "react";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Stack from "@mui/material/Stack";
import { Divider } from "antd";
import { Button, Grid } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { getAllassigment } from "src/utility/apiService.js";
import { useState } from "react";
import { MDBCol, MDBContainer, MDBRow } from "mdb-react-ui-kit";
import fatculty from "src/context/fatculty";
import { useContext } from "react";

const Assiganment = () => {
  let navigate = useNavigate();
  const [data,setData] = useState([]);
  const Access=useContext(fatculty)
  const move = () => navigate("/dashboard");
  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
    ...theme.typography.body2,
    padding: theme.spacing(1),
    color: theme.palette.text.secondary,
  }));
console.log(Access);
  const getAll = async () => {
    let res = await getAllassigment();
    console.log(res?.data?.data);
    setData(res?.data?.data);
  };
  useEffect(() => {
    getAll();
  }, []);
  return (
    <>
      <h1>Assiganment</h1>
     {Access.isfaculty ? <Button
        variant="contained"
        style={{ marginLeft: "93%", marginTop: "-100px" }}
        onClick={move}
      >
        create
      </Button>:null}
      <Divider style={{ backgroundColor: "black", marginTop: "-16px" }} />
      <>
        <Box sx={{ width: "100%" }}>
          <Stack spacing={2}>
        {data.map((i,index)=>
           i ? <Item key={index}>
                <MDBContainer>
              <MDBRow>
                <MDBCol size="6">
                <div style={{marginTop:"10px" ,fontSize:"17px"}}><b>Assiganment :{i.assignmentTitle} </b></div>
                <div style={{marginTop:"10px" ,fontSize:"17px"}} ><b>Class :{i.class}</b></div>
                <div style={{marginTop:"10px" ,fontSize:"17px"}}><b>No.of.Question :{i.totalQuestion}</b> </div>
                </MDBCol>
                <MDBCol size="6">
                <div style={{marginTop:"10px" ,fontSize:"17px"}} ><b>Date :{i.createdAt}</b> </div>
                <div style={{marginTop:"10px" ,fontSize:"17px"}} ><b>totalMarks:{i.totalMarks}</b> </div>
                </MDBCol>
              </MDBRow>
            </MDBContainer>
              {/* <div><b>Assiganment :{i.assignmentTitle}</b></div>
              <div><b>Class :{i.class}</b></div>
              <div><b>subject:{i.subject}</b></div>
              <div style={{marginTop:"-14px",marginLeft:"85%"}}>Date :{i.createdAt} </div>
              <div><b>No.of.Question :{i.totalQuestion}</b> </div>
              <div style={{marginTop:"-24px",marginLeft:"85%"}}>totalMarks:{i.totalMarks} </div> */}
            </Item>:null)}
          </Stack>
        </Box>
        <br/>
      </>
    </>
  );
};
export default Assiganment;

// margin-left: 85%;
//     margin-top: -24px;