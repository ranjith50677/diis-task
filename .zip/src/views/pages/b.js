<Flex
            zIndex='2'
            direction='column'
            w='445px'
            background='transparent'
            borderRadius='15px'
            p='40px'
            mx={{ base: "100px" }}
            m={{ base: "20px", md: "auto" }}
            bg={bgForm}
            boxShadow={useColorModeValue(
              "0px 5px 14px rgba(0, 0, 0, 0.05)",
              "unset"
            )}>
            <center>
            <img src="https://hrms.codiis.oneappplus.in/static/media/HRMS01.69d926896928ecf30e13.png" className="img-fluid" alt="Responsive image" style={{display: "flex",height: "auto",width:"25%"}}/>
            </center>     
            <HStack spacing='15px' justify='center' mb='22px'>
            </HStack>
            <FormControl>
              <FormLabel ms='4px' fontSize='sm' fontWeight='normal'>
               Email
              </FormLabel>
              <CFormInput 
                  id="exampleFormControlInput1"
                  placeholder="Enter Your Email"
                  value={email}
                  onChange={(e)=>setEmail(e.target.value)}
                  />
                <HStack spacing='15px' justify='center' mb='18px'>
            </HStack>
              <FormLabel ms='4px' fontSize='sm' fontWeight='normal'>
                Password
              </FormLabel>
              <CFormInput 
                  id="exampleFormControlInput1"
                  placeholder="Enter Your Password"
                  value={password}
                  onChange={(e)=>setPassword(e.target.value)}
                  />
              <FormControl display='flex' alignItems='center' mb='34px' mt="24px">
              <input type="checkbox"/>
                {/* <CFormSwitch id='remember-login'  me='10px' color="info" /> */}
                <FormLabel htmlFor='remember-login' mb='0' fontWeight='normal' ml="0.8rem">
                  Remember me
                </FormLabel>
              </FormControl>
             {/* <NavLink to="/admin/dashboard">  */}
             <div className="d-grid">
                    <CButton color="info" onClick={handleSubmit} style={{width:"100%"}}>Login</CButton>
                  </div>
              {/* </NavLink> */}
            </FormControl>
            <Flex
              flexDirection='column'
              justifyContent='center'
              alignItems='center'
              maxW='100%'
              mt='0px'>
            </Flex>
          </Flex>