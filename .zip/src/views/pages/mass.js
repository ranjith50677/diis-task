
// // Chakra imports
// import {
//     Box,
//     Flex,
//     Button,
//     FormControl,
//     FormLabel,
//     HStack,
//     Input,
//     Icon,
//     Link,
//     Switch,
//     Text,
//     useColorModeValue,
//   } from "@chakra-ui/react";
//   import React, { useContext, useState } from 'react'
//   import { useNavigate } from 'react-router-dom'
  
  
//   // import { useHistory } from "react-router-dom";
  
//   // import Context from "../../context/MenuAcess";
  
//   import { getProfile, getRoleMenuAccessById, userLogin } from 'src/utility/apiService'
//   import { RoleMenuAccessContext } from 'src/context/roleMenuContext'
//   import CustomButton from "src/custom/Button";
//   import { CButton, CFormInput, CFormSwitch } from "@coreui/react";
  
//   // import { useContext } from "react";
//   // import { userLogin } from "utility/apiSerivice";
//   // import { useLocation } from 'react-router-dom';
//   // import  Context  from "../../context/MenuAcess";
//   // import router from "routes";
//   // import App from '../../App'
  
//   // import  Context  from "../../context/MenuAcess";
  
//   function Login() {
//     let navigate=useNavigate()
  
//   let {dispatch}=useContext(RoleMenuAccessContext)
//   let roleMenuContext=useContext(RoleMenuAccessContext)
//     // Chakra color mode
//     const textColor = useColorModeValue("gray.700", "white");
//     const bgForm = useColorModeValue("white", "navy.800");
//     // const titleColor = useColorModeValue("gray.700", "blue.500");
//     const colorIcons = useColorModeValue("gray.700", "white");
//     const bgIcons = useColorModeValue("trasnparent", "navy.700");
//     const bgIconsHover = useColorModeValue("gray.50", "whiteAlpha.100");
//     //const history = useHistory();
//     const [email,setEmail]=useState("")
//     const[password,setPassword]=useState("")
//     // const[token,setToken]=useState("")
//     // const route = useContext(Context);
//     const handleSubmit = async(e) => {
//       e.preventDefault()
//       if(email==="" || password===""){
//       return alert("Please fill all the fields")
//       }
//       try {
//       let response=await userLogin({email,password})
//       if(!response?.ok){
//       return alert(response.data.message)
//       }
//       localStorage.setItem("hrmsv2-token",JSON.stringify(response.data.token));
//       try {
//       let profile=await getProfile(response.data.token)
//       if(!profile?.ok){
//       return alert(response.data.message)
//       }
//       dispatch({type:"ADD_ISOWNER",payload:profile.data.data.isOwner})
//       if(profile.data.data.isOwner==true){
//       return navigate("/dashboard")
//       }
//       try {
//       if(!profile.data.data?.roleId?._id) return alert("role not mapping for you")
//       let roleMenu=await getRoleMenuAccessById(profile.data.data?.roleId?._id)
//       if(!roleMenu?.ok){
//       return alert(profile.data.message)
//       }
//       dispatch({type:"ADD_ROLEMENUACCESS",payload:roleMenu.data.data})
//       console.log(roleMenu.data.data);
//       navigate("/dashboard")
//       } catch (error) {
//       console.log(error.message);
//       }
//       } catch (error) {
//       console.log(error.message);
//       }
//       } catch (error) {
//       console.log(error.message);
//       }
//       }
       
  
//     return (
//       <Flex position='relative' mb='40px' mt="200px">
//         <Flex
//           minH={{ md: "1000px" }}
//           h={{ sm: "initial", md: "75vh", lg: "85vh" }}
//           w='100%'
//           maxW='1044px'
//           mx='auto'
//           justifyContent='space-between'
//           mb='30px'
//           pt={{ md: "0px" }}>
//           <Flex
//             w='100%'
//             h='100%'
//             alignItems='center'
//             justifyContent='center'
//             mb='60px'
//             mt={{ base: "50px", md: "20px" }}
//             >
//             <Flex
//               zIndex='2'
//               direction='column'
//               w='445px'
//               background='transparent'
//               borderRadius='15px'
//               p='40px'
//               mx={{ base: "100px" }}
//               m={{ base: "20px", md: "auto" }}
//               bg={bgForm}
//               boxShadow={useColorModeValue(
//                 "0px 5px 14px rgba(0, 0, 0, 0.05)",
//                 "unset"
//               )}>
//               <center>
//               <img src="https://hrms.codiis.oneappplus.in/static/media/HRMS01.69d926896928ecf30e13.png" className="img-fluid" alt="Responsive image" style={{display: "flex",height: "auto",width:"25%"}}/>
//               </center>     
//               <HStack spacing='15px' justify='center' mb='22px'>
//               </HStack>
//               <FormControl>
//                 <FormLabel ms='4px' fontSize='sm' fontWeight='normal'>
//                  Email
//                 </FormLabel>
//                 <CFormInput 
//                     id="exampleFormControlInput1"
//                     placeholder="Enter Your Email"
//                     value={email}
//                     onChange={(e)=>setEmail(e.target.value)}
//                     />
//                   <HStack spacing='15px' justify='center' mb='18px'>
//               </HStack>
//                 <FormLabel ms='4px' fontSize='sm' fontWeight='normal'>
//                   Password
//                 </FormLabel>
//                 <CFormInput 
//                     id="exampleFormControlInput1"
//                     placeholder="Enter Your Password"
//                     value={password}
//                     onChange={(e)=>setPassword(e.target.value)}
//                     />
//                 <FormControl display='flex' alignItems='center' mb='34px' mt="24px">
//                 <input type="checkbox"/>
//                   {/* <CFormSwitch id='remember-login'  me='10px' color="info" /> */}
//                   <FormLabel htmlFor='remember-login' mb='0' fontWeight='normal' ml="0.8rem">
//                     Remember me
//                   </FormLabel>
//                 </FormControl>
//                {/* <NavLink to="/admin/dashboard">  */}
//                <div className="d-grid">
//                       <CButton color="info" onClick={handleSubmit} style={{width:"100%"}}>Login</CButton>
//                     </div>
//                 {/* </NavLink> */}
//               </FormControl>
//               <Flex
//                 flexDirection='column'
//                 justifyContent='center'
//                 alignItems='center'
//                 maxW='100%'
//                 mt='0px'>
//               </Flex>
//             </Flex>
//           </Flex>
//           <Box
//             overflowX='hidden'
//             h='100%'
//             w='100%'
//             left='0px'
//             position='absolute'
//             // bgImage={signInImage}
//             >
//             <Box
//               w='100%'
//               h='100%'
//               bgSize='cover'
//               bg='blue'
//               opacity='0.4'></Box>
//           </Box>
//         </Flex>
//       </Flex>
//     );
//   }
  
//   export default Login;
  