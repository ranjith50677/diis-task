import React,{useEffect} from "react";
import View from './viewquestion'

export default function Attend(){

return(
    <View/>
)

} 