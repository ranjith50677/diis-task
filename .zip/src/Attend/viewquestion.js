import { Box, Stack } from "@mui/material";
import { MDBCol, MDBContainer, MDBRow } from "mdb-react-ui-kit";
import React,{useEffect} from "react";
import { studentAss } from "src/utility/apiService";
import { styled } from "@mui/material/styles";
import Paper from "@mui/material/Paper";
import { useState } from "react";
import { Button } from "@mui/material";
import Questionatt from './attendques';
export default function Attend(){
  const[data,setData]=useState([])
  const[open,setOpen]=useState(false)
  const Item = styled(Paper)(({ theme }) => ({
   backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
   ...theme.typography.body2,
   padding: theme.spacing(1),
   color: theme.palette.text.secondary,
   }));

    const handel=async()=>{
    let res= await studentAss();
    console.log(res?.data?.data);
    setData(res?.data?.data)
    }
    const Attend=()=>{
        setOpen(true)
    }
     useEffect(()=>{
     handel()
    },[])

return(
    <>
   {open ? <Questionatt data={data}/>:
     <Box sx={{ width: "100%" }}>
    <Stack spacing={2}>
  {data.map((i,index)=>
     i ? 
     <Item key={index} >
          <MDBContainer>
        <MDBRow>
          <MDBCol size="6">
          <div style={{marginTop:"10px" ,fontSize:"17px"}}><b>Assiganment :{i.assignment.assignmentTitle} </b></div>
          <div style={{marginTop:"10px" ,fontSize:"17px"}} ><b>Class :{i.assignment.class}</b></div>
          <div style={{marginTop:"10px" ,fontSize:"17px"}}><b>No.of.Question :{i.assignment.totalQuestion}</b> </div>
          
          </MDBCol>
          <MDBCol size="6">
          <div style={{marginTop:"10px" ,fontSize:"17px"}} ><b>Date :{i.assignment.createdAt}</b> </div>
          <div style={{marginTop:"10px" ,fontSize:"17px"}} ><b>totalMarks:{i.assignment.totalMarks}</b> </div>
          </MDBCol>
        </MDBRow>
        <Button variant="contained" style={{marginTop:"10px"}} onClick={Attend}>Attend</Button>
      </MDBContainer>
      </Item>:null)} 
    </Stack>
  </Box>}
</>

)

} 