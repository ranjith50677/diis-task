import { cilChevronLeft } from "@coreui/icons";
import CIcon from "@coreui/icons-react";
import { Box, Button, Radio } from "@mui/material";
// import Radio from '@mui/joy/Radio';
import { Divider } from "antd";
import { MDBCol, MDBContainer, MDBInput, MDBRadio, MDBRow } from "mdb-react-ui-kit";
import React from "react";
import { useState,useEffect } from "react";

export default function questionAttend({data}){
    const[question,setQuestion]=useState([])
 useEffect(()=>{
    data.map((i)=>{
       setQuestion(i?.assignment?.question);
    })
},[])
return(
    <>
    <CIcon
        icon={cilChevronLeft}
        size="xl"
        style={{
          marginTop: "1rem",
          marginLeft: "1rem",
          cursor: "pointer",
        }}
      />
      <h1 style={{ marginLeft: "3rem", marginTop: "-3rem" }}>
         write Answer
      </h1>
      <Divider style={{ backgroundColor: "black" }} />
        {/* { arr?.map((item,index)=>{
          let si= index + 1
          return( */}
         {question.map((i,index)=>
         i ? <MDBContainer
           key={index}
            className="shadow-inner"
            style={{ backgroundColor: "white", height: "320px" }}
          >
            <MDBRow>
             <div style={{marginTop:"10px",fontSize:"31px"}}>{index+1}</div> 
              <MDBCol size="12" style={{ margin:"4%" }}>
                <MDBInput
                  placeholder="Question No"
                  id="form1"
                  type="text"
                  disabled
                  value={i.question}
                  style={{width:"95%",marginTop: "-75px",}}
                />
              </MDBCol>
            </MDBRow>
            <MDBRow>
              <Box style={{backgroundColor:"white"}}>     
              <MDBCol size="5" style={{ margin:"4%" }}>
              <MDBRadio name='flexRadioDefault' id='flexRadioDefault1' label='Default radio' />
              </MDBCol>
              </Box>
              <MDBCol size="5" style={{ marginLeft: "2%" }}>
              <MDBRadio name='flexRadioDefault' id='flexRadioDefault2' label='Default checked radio'  />
              </MDBCol>
            </MDBRow>
            {/* <MDBRow>
              <MDBCol size="5" style={{ margin:"2%" }}>
                <MDBInput placeholder="Option C" id="form1" name="option3" type="text" style={{ width: "110%"}} onChange={(e) => handleChange({
                    target: {
                      name: "option3",
                      value: e.target.value,
                    },
                  },
                  index)} />
              </MDBCol>
              <MDBCol size="5" style={{ marginLeft: "2%" }}>
                <MDBInput placeholder="Option D" id="form1" name="option4" type="text"  style={{marginTop: "15px", width: "119%"}} onChange={(e) => handleChange({
                    target: {
                      name: "option4",
                      value: e.target.value,
                    },
                  },
                  index)} />
              </MDBCol>
              <MDBCol size="5" style={{ margin:"2%" }}>
                <MDBInput placeholder="Answer" id="form1" name="answer" type="text" style={{width: "110%"}} onChange={(e) => handleChange({
                    target: {
                      name: "answer",
                      value: e.target.value,
                    },
                  },
                  index)} />
              </MDBCol>
              <MDBCol size="5" style={{ marginLeft: "2%" }}>
                <MDBInput placeholder="Mark For This Question" id="form1" name="markForThisQuestion" style={{marginTop: "15px", width: "119%"}}    type="number" onChange={(e) => handleChange({
                    target: {
                      name: "markForThisQuestion",
                      value: e.target.value,
                    },
                  },
                  index)}                 />
              </MDBCol>
            </MDBRow> */}
          </MDBContainer>
         :null )}
      <Button
        variant="contained"
        // onClick={handleSubmit}
        style={{ marginTop: "10%", marginLeft: "90%" }}
      >
        Submit
      </Button>
      </>
)

} 