import { createContext } from "react";
const fatculty = createContext(null);
export default fatculty;