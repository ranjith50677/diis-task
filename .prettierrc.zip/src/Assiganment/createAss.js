// import { Diversity1 } from '@mui/icons-material';
import React from "react";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Stack from "@mui/material/Stack";
import { Divider } from "antd";
import { Button } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { getAllassigment } from "src/utility/apiService.js";
import { useState } from "react";

const Assiganment = () => {
  let navigate = useNavigate();

  const [data, setData] = useState("");
  const move = () => navigate("/dashboard");
  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: "center",
    color: theme.palette.text.secondary,
  }));

  const getAll = async () => {
    let res = await getAllassigment();
    console.log(res);
    setData(res);
  };
  useEffect(() => {
    getAll();
  }, []);

  return (
    <>
      <h1>Assiganment</h1>
      <Button
        variant="contained"
        style={{ marginLeft: "93%", marginTop: "-100px" }}
        onClick={move}
      >
        create
      </Button>
      <Divider style={{ backgroundColor: "black", marginTop: "-16px" }} />
      <>
        <Box sx={{ width: "100%" }}>
          <Stack spacing={2}>
            <Item>
              <div>ran</div>
            </Item>
          </Stack>
        </Box>
      </>
    </>
  );
};
export default Assiganment;
