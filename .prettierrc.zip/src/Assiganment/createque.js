import React,{useEffect} from "react";
import { Divider } from "antd";
import { cilChevronLeft } from "@coreui/icons";
import CIcon from "@coreui/icons-react";
import { MDBContainer, MDBRow, MDBCol, MDBInput } from "mdb-react-ui-kit";
import { Button } from "@mui/material";
import { useNavigate,useLocation } from "react-router-dom";
import { useState } from "react";

const Craeteque = () => {
  const {state} = useLocation()
  console.log(state )
  const [question, setQuestion] = useState([]);
  var B = state?.no;
  var N = B + 1;
  let a = Array.apply(null, { length: N }).map(Number.call, Number);
  let navigate = useNavigate();
  const back = () => navigate("/dashboard");
  let [arr,setArr]=useState([]);
  let [data,setData]=useState([])
  
  for(let i=1;i<=B;i++){
    let si=i+1
    if(arr?.length < B){
      arr.push(i)
      data.push({questionNo:si,question:"",option1:"",option2:"",option3:"",option4:"",correctAnswer:""})
    }
  }

  const handleChange = (e, index) => {
    const { name, value } = e.target;
    let list = [...data] ;
    list[index][name] = value;
    // setData((prev) => ({
    //   ...prev,
    //   list,
    // }));
    // console.log(list);
    setData(list);
  };

  const handleSubmit = () => {
    let options=[]
    data.map((item,index)=>{
      if(item.option1){
        options.push({optionNo:1 , optionAns : item.option1})
      }
      if(item.option2){
        options.push({optionNo:1 , optionAns : item.option2})
      }
      if(item.option3){
        options.push({optionNo:1 , optionAns : item.option3})
      }
      if(item.option4){
        options.push({optionNo:1 , optionAns : item.option4})
      }
    })
  }
  
  return (
    <div>
      <CIcon
        icon={cilChevronLeft}
        size="xl"
        style={{
          marginTop: "1rem",
          marginLeft: "1rem",
          cursor: "pointer",
        }}
        onClick={back}
      />
      <h1 style={{ marginLeft: "3rem", marginTop: "-3rem" }}>
        create Question
      </h1>
      <Divider style={{ backgroundColor: "black" }} />
        { arr?.map((item,index)=>{
          let si= index + 1
          return(<MDBContainer
            className="shadow-inner"
            style={{ backgroundColor: "white", height: "320px" }}
          >
            <MDBRow>
             <div style={{marginTop:"10px",fontSize:"31px"}}>{si}</div> 
              <MDBCol size="12" style={{ margin:"2%" }}>
                <MDBInput
                  placeholder="Question No"
                  id="form1"
                  type="text"
                  name="question"
                  onChange={(e) => handleChange({
                    target: {
                      name: "question",
                      value: e.target.value,
                    },
                  },
                  index)}
                  style={{width:"95%",marginTop: "-55px",}}
                />
              </MDBCol>
            </MDBRow>
            <MDBRow>
              <MDBCol size="5" style={{ margin:"2%" }}>
                <MDBInput placeholder="Option A" id="form1" name="option1"  type="text" style={{ width: "110%"}} onChange={(e) => handleChange({
                    target: {
                      name: "option1",
                      value: e.target.value,
                    },
                  },
                  index)} />
              </MDBCol>
              <MDBCol size="5" style={{ marginLeft: "2%" }}>
                <MDBInput placeholder="Option B" id="form1" name="option2" type="text"  style={{marginTop: "15px", width: "119%"}} onChange={(e) => handleChange({
                    target: {
                      name: "option2",
                      value: e.target.value,
                    },
                  },
                  index)} />
              </MDBCol>
            </MDBRow>
            <MDBRow>
              <MDBCol size="5" style={{ margin:"2%" }}>
                <MDBInput placeholder="Option C" id="form1" name="option3" type="text" style={{ width: "110%"}} onChange={(e) => handleChange({
                    target: {
                      name: "option3",
                      value: e.target.value,
                    },
                  },
                  index)} />
              </MDBCol>
              <MDBCol size="5" style={{ marginLeft: "10%" }}>
                <MDBInput placeholder="Option D" id="form1" name="option4" type="text" onChange={(e) => handleChange({
                    target: {
                      name: "option4",
                      value: e.target.value,
                    },
                  },
                  index)}                 />
              </MDBCol>
              <MDBCol size="5" style={{ margin:"2%" }}>
                <MDBInput placeholder="Answer" id="form1" name="correctAnswer" type="text" style={{width: "110%"}} onChange={(e) => handleChange({
                    target: {
                      name: "correctAnswer",
                      value: e.target.value,
                    },
                  },
                  index)} />
              </MDBCol>
            </MDBRow>
          </MDBContainer>)})}
        {/* ) : null
      )} */}
      <Button
        variant="contained"
        onClick={handleSubmit}
        style={{ marginTop: "10%", marginLeft: "90%" }}
      >
        Submit
      </Button>
    </div>
  );
};

export default Craeteque;
