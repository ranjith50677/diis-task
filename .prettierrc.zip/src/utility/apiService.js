//  ******************** Base URL ***********************
let baseUrl = "http://localhost:2023/api/";

let token = localStorage.getItem("token");
console.log(token);
// if (token) {
//   token = JSON.parse(token);
// }
////////======================================/////////////////////
export const userLogin = async (body) => {
  const requestOptions = {
    method: "POST",
    mode: "cors",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  };
  const response = await fetch(`${baseUrl}user/login`, requestOptions);
  if (!response.ok) {
    let data = await response.json();
    return { data: data, ok: false };
  }
  let data = await response?.json();
  return { data: data, ok: true };
};


export const getAllassigment = async () => {   
  const requestOptions = {
    method: "GET",
    mode: "cors",
    headers: {
      "Content-Type": "application/json",
      "token": token,
    },
  };
  const response = await fetch(`${baseUrl}assign/getallassign`, requestOptions);
  if (!response.ok) {
    let data = await response.json();
    return { data: data, ok: false };
  }
  let data = await response?.json();
  return { data: data, ok: true };
};
//  ******************** Auth Api's ***********************
// export const createUser = async (body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(`${baseUrl}user/reg`, requestOptions);
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const getAllUsers = async (menuId) => {
//   const requestOptions = {
//     method: "GET",
//     headers: { "Content-Type": "application/json" },
//   };
//   const response = await fetch(`${baseUrl}user/getalluser?menuId=${menuId}`, requestOptions);
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// // export const userLogin = async (body) => {
// //   const requestOptions = {
// //     method: "POST",
// //     mode: "cors",
// //     headers: {
// //       "Content-Type": "application/json",
// //     },
// //     body: JSON.stringify(body),
// //   };
// //   const response = await fetch(`${baseUrl}user/login`, requestOptions);
// //   if (!response.ok) {
// //     let data = await response.json();
// //     return { data: data, ok: false };
// //   }
// //   let data = await response?.json();
// //   return { data: data, ok: true };
// // };

// export const getProfile = async () => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   if (token) {
//     const response = await fetch(`${baseUrl}user/profile`, requestOptions);
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// export const getUserById = async (id) => {
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//     },
//   };
//   if (token) {
//     const response = await fetch(
//       `${baseUrl}user/getuserbyid/${id}`,
//       requestOptions
//     );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// export const getAccessForMenu = async (roleId, menuId) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(   `${baseUrl}rolemenuaccess/getaccessforuser?roleId=${roleId}&menuId=${menuId}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const myProfile = async () => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   if (token) {
//     const response = await fetch(`${baseUrl}user/myprofile`, requestOptions);
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// export const updateUser = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}user/updateuser/${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data.data, ok: true };
// };

// export const deleteUserById = async (id) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "DELETE",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(
//     `${baseUrl}user/deleteuser/${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data.data, ok: true };
// };

// //  ******************** Education Api's ***********************
// export const addEducation = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   }; 
//     const response = await fetch( `${baseUrl}user/addeducation?userId=${id}`, requestOptions );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true }; 
// };

// export const getEducationById = async (id, menuId) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   if (token) {
//     const response = await fetch(
//       `${baseUrl}user/geteducationbyid?userId=${id}&menuId=${menuId}`,
//       requestOptions
//     );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// export const updateEducation = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   if (token) {
//     const response = await fetch(
//       `${baseUrl}user/updateeducation?userId=${id}`,
//       requestOptions
//     );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// //  ******************** Document Api's ***********************

// export const addDocument = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   if (token) {
//     const response = await fetch(
//       `${baseUrl}user/adddoc?userId=${id}`,
//       requestOptions
//     );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// export const getDocumentById = async (id, menuId) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   if (token) {
//     const response = await fetch(
//       `${baseUrl}user/getdocbyid?userId=${id}&menuId=${menuId}`,
//       requestOptions
//     );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// export const updateDocument = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };

//   if (token) {
//     const response = await fetch(
//       `${baseUrl}user/updatedoc?userId=${id}`,
//       requestOptions
//     );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// //  ******************** Address Api's ***********************

// export const addAddress = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   if (token) {
//     const response = await fetch(
//       `${baseUrl}user/addaddress?userId=${id}`,
//       requestOptions
//     );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// export const addAddressVerify = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   if (token) {
//     const response = await fetch(
//       `${baseUrl}user/addaddressverify?userId=${id}`,
//       requestOptions
//     );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// export const getAddressById = async (id, menuId) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   if (token) {
//     const response = await fetch(
//       `${baseUrl}user/getaddressbyid?userId=${id}&menuId=${menuId}`,
//       requestOptions
//     );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// export const updateAddress = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   if (token) {
//     const response = await fetch(
//       `${baseUrl}user/updateaddress?userId=${id}`,
//       requestOptions
//     );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// //  ******************** Family Api's ***********************

// export const addFamily = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   if (token) {
//     const response = await fetch(
//       `${baseUrl}user/addfamily?userId=${id}`,
//       requestOptions
//     );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// export const addFamilyVerify = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   if (token) {
//     const response = await fetch(
//       `${baseUrl}user/addfamilyverify?userId=${id}`,
//       requestOptions
//     );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// export const getFamilyById = async (id, menuId) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   if (token) {
//     const response = await fetch(
//       `${baseUrl}user/getfamilybyid?userId=${id}&menuId=${menuId}`,
//       requestOptions
//     );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// export const updateFamily = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   if (token) {
//     const response = await fetch(
//       `${baseUrl}user/updatefamily?id=${id}`,
//       requestOptions
//     );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// //  ******************** Experience Api's ***********************

// export const addExperience = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   if (token) {
//     const response = await fetch(
//       `${baseUrl}user/addexperience?userId=${id}`,
//       requestOptions
//     );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// export const getExperienceById = async (id, menuId) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   if (token) {
//     const response = await fetch(
//       `${baseUrl}user/getexperiencebyid?userId=${id}&menuId=${menuId}`,
//       requestOptions
//     );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// export const updateExperience = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: { 
//       "Content-Type": "application/json",
//       "hrms-auth-token": token },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}user/updateexperience?id=${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// //  ******************** Menu Api's ***********************
// export const createMenu = async (body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}organization/menu/createmenu`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const getallMenu = async () => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(
//     `${baseUrl}organization/menu/getallmenu`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const updateMenu = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: { "Content-Type": "application/json", "hrms-auth-token": token },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}organization/menu/upmenu?id=${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// //  ******************** Role Api's ***********************
// export const createRole = async (body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}organization/role/newrole`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const getallRole = async () => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(
//     `${baseUrl}organization/role/getallrole`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const updateRole = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}organization/role/updaterole?id=${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const getRoleById = async (id) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   let res = await fetch(
//     `${baseUrl}organization/role/getrolebyid/${id}`,
//     requestOptions
//   );
//   if (!res.ok) {
//     let data = await res.json();
//     return { data: data, ok: false };
//   }
//   let data = await res?.json();
//   return { data: data, ok: true };
// };

// //  ******************** Department Api's ***********************
// export const createDepartment = async (body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}organization/dept/createdept`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const getallDep = async () => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(
//     `${baseUrl}organization/dept/getalldept`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const updateDep = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   } 
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}organization/dept/updatedept?deptid=${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// //  ******************** Designation Api's ***********************
// export const createDesignation = async (id,body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   } 
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}organization/des/createdes?departmentId=${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const getallDes = async () => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(
//     `${baseUrl}organization/des/getalldes`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const updateDes = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}organization/des/updatedes?id=${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// //  ******************** Mapping Api's ***********************
// export const createRoleMenu = async (body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}rolemenuaccess/createnew`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { message: data.message, ok: false };
//   }
//   const data = await response.json();
//   return { message: data.message, ok: true };
// };

// export const getRoleMenu = async () => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   let response = await fetch(`${baseUrl}rolemenuaccess/getall`, requestOptions);
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const getRoleMenuById = async (id,menuId) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   let response = await fetch(
//     `${baseUrl}rolemenuaccess/getbyid/${id}?menuId=${menuId}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const getRoleMenuAccessById = async (id) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(
//     `${baseUrl}rolemenuaccess/getidaccess/${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const updateRoleMenuById = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "PUT",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   let res = await fetch(
//     `${baseUrl}rolemenuaccess/update/${id}`,
//     requestOptions
//   );
//   let data = res?.json();
//   return data;
// };

// //  ********************  work Api's ***********************

// export const workInfo = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}user/addwork?userId=${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const getWorkByid = async (id, menuid) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   let res = await fetch(
//     `${baseUrl}user/getworkbyid?userId=${id}&menuId=${menuid}`,
//     requestOptions
//   );
//   if (!res.ok) {
//     let data = await res.json();
//     return { data: data, ok: false };
//   }
//   let data = await res?.json();
//   return { data: data, ok: true };
// };

// export const updateWorkById = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   if (token) {
//     const response = await fetch(
//       `${baseUrl}user/updatework?userId=${id}`,
//       requestOptions
//     );
//     if (!response.ok) {
//       let data = await response.json();
//       return { data: data, ok: false };
//     }
//     let data = await response?.json();
//     return { data: data, ok: true };
//   }
// };

// //  ******************** Asset Api's ***********************
// export const createAssets = async (body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(`${baseUrl}assets/createasset`, requestOptions);
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const getAssetsById = async (id,menuId) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   let res = await fetch(
//     `${baseUrl}assets/getassetsById/${id}?menuId=${menuId}`,
//     requestOptions
//   );
//   if (!res.ok) {
//     let data = await res.json();
//     return { data: data, ok: false };
//   }
//   let data = await res?.json();
//   return { data: data, ok: true };
// };

// export const getAssetsUsingStoreId = async (id,menuId) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   let res = await fetch(
//     `${baseUrl}assets/getassetbyusingstoreid/${id}?menuId=${menuId}`,
//     requestOptions
//   );
//   if (!res.ok) {
//     let data = await res.json();
//     return { data: data, ok: false };
//   }
//   let data = await res?.json();
//   return { data: data, ok: true };
// };


// export const getAllAssets = async (obj) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   let {isAvailable,type} = obj;
//   const response = await fetch(`${baseUrl}assets/getallassets?isAvailable=${isAvailable}&type=${type}`, requestOptions);
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// //  ********************User Asset Mapping Api's ***********************

// export const assetMapping = async (obj) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(obj),
//   };
//   const response = await fetch(`${baseUrl}userasset/assetmapping`,requestOptions);
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const userAssetUnmapping = async (obj) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(obj),
//   };
//   const response = await fetch(`${baseUrl}userasset/assetunmapping`,requestOptions);
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const getAllUserAsset = async () => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(
//     `${baseUrl}userasset/getalluserassets`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

  

// export const getUserAssetsById = async (id,menuId) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   let response = await fetch(
//     `${baseUrl}userasset/getuserassetsbyid/${id}?menuId=${menuId}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };
// //  ******************** StoreAsset Api's ***********************
// export const newStoreAsset = async (body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(`${baseUrl}assets/creatstoreasset`, requestOptions);
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const getAllStoreAssets = async () => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(`${baseUrl}assets/getallstoreassets`, requestOptions);
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// export const updateStoreAsset = async (id, body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}assets/updatestoreasset?id=${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };



// //  ******************** Food Token Request Api's ***********************

// export const createFoodRequest = async (body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}request/createfoodreq`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// }

// export const getAllFoodRequest = async () => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(
//     `${baseUrl}request/getallfoodreq`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// }

// export const getUserFoodRequests = async () => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(
//     `${baseUrl}request/getuserfoodreq`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// }


// export const updateFoodRequest = async (id,body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}request/updatefoodreq?id=${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// }

// export const cancelFoodRequest = async (id,body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   } 
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}request/cancelfoodreq?id=${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// }

// //  ******************** Food Request && Category Api's ***********************
// export const createFoodcategory = async (body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//    token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}request/createfoodcat`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// }
// export const updateFoodCategory = async (id,body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//    token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}request/updatefoodcat?id=${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// }

// export const getuserByIdFoodrequest= async (id) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//    token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(
//     `${baseUrl}request/getallfoodreqbyuserid?id=${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// }

// export const getAllFoodCategory = async () => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//    token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(
//     `${baseUrl}request/getallfoodcat`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };
// export const getFoodCategoryById = async (id) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//     token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   let response = await fetch(
//     `${baseUrl}request/getbyidfoodcat/${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response?.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// };

// //  ******************** Food Shop Api's ***********************

// export const createFoodShop = async (id,body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//    token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}request/createfoodshop?categoryId=${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// }
// export const updateFoodShop = async (id) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//    token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}request/updatefoodshop?shopId=${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// }
// export const getAllFoodshop = async (id) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//    token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(
//     `${baseUrl}request/getallfoodshop`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// }
// export const getByIdFoodshop = async (id) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//    token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(
//     `${baseUrl}request/getbyidfoodshop/${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// }

// //  ******************** Asset request Api's ***********************

// export const createAssetRequest = async (body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//    token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "POST",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}request/createassetreq`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// }

// export const updateAssetRequest = async (id,body) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//    token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "PUT",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//     body: JSON.stringify(body),
//   };
//   const response = await fetch(
//     `${baseUrl}request/updateassetreq?id=${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// }


// export const getAllAssetRequest = async () => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//    token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(
//     `${baseUrl}request/getallassetreq`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// }

// export const getByIdAssetRequest = async (id) => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//    token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(
//     `${baseUrl}request/getbyidassetreq/${id}`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// }

// export const getUserAssetRequests= async () => {
//   let token = localStorage.getItem("hrmsv2-token");
//   if (token) {
//    token = JSON.parse(token);
//   }
//   const requestOptions = {
//     method: "GET",
//     mode: "cors",
//     headers: {
//       "Content-Type": "application/json",
//       "hrms-auth-token": token,
//     },
//   };
//   const response = await fetch(
//     `${baseUrl}request/getuserassetreq`,
//     requestOptions
//   );
//   if (!response.ok) {
//     let data = await response.json();
//     return { data: data, ok: false };
//   }
//   let data = await response?.json();
//   return { data: data, ok: true };
// }