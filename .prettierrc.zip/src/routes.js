import React from 'react'
// import { RoleMenuAccessContext } from './context/roleMenuContext'
import _ from "lodash";

const Ass = React.lazy(() => import('./Assiganment/createAss.js'))
const ques = React.lazy(() => import('./Assiganment/createque.js'))
const All = React.lazy(() => import('./Assiganment/Allassignment.js'))

// const CreateAsset = React.lazy(() => import('./views/assetsmenu/createAsset'))
// const Request = React.lazy(() => import('./views/request'))
// const Dashboard = React.lazy(() => import('./Assiganment/Allassignment.js'))
// const Profile = React.lazy(() => import('./views/profile/index'))

// const Role = React.lazy(() => import('./views/organization/role'))
// const Menu = React.lazy(() => import('./views/organization/menu'))
// const Mapping = React.lazy(() => import('./views/mapping/roleMenuMapping'))
// const Department = React.lazy(() => import('./views/organization/department'))
// const Designation = React.lazy(() => import('./views/organization/designation'))
// const CreateEmployee = React.lazy(() => import('./views/createEmployee'))

const routers=()=>{
  // const roleMenuAccess=useContext(RoleMenuAccessContext)

  // let defaultRoute=[
  //   { path: '/dashboard', name: 'Dashboard', element: Dashboard },
  //   {path:'/profile',name:'profile', element:Profile}
  // ]
  const routes = [
    { path: '/', exact: true, name: 'Home' },
    { path: '/Assiganment', name: 'Assignment', element: Ass },
    { path: '/Question', name: 'ques', element: ques },
    // {path:'/profile',name:'profile', element:Profile},  
    { path: '/dashboard', name: 'Dashboard', element: All },
    // { path: '/organization', name: 'Organization', element: null, exact: true },
    // { path: '/organization/role', name: 'Role', element: Role },
    // { path: '/organization/menu', name: 'Menu', element: Menu },
    // { path: '/mapping', name: 'Mapping', element: null, exact: true },
    // { path: '/mapping/roleMenuMapping', name: 'Role Menu', element: Mapping },
    // { path: '/organization/department', name: 'Department', element: Department },
    // { path: '/organization/designation', name: 'Designation', element: Designation },
    // { path: '/createemployee', name: 'Employee', element: CreateEmployee   },
    // { path: '/assets', name: 'Assets', element: null, exact: true  },
    // { path: '/assets/assetmapping', name: 'Asset Mapping', element: Assets   },
    // { path: '/assets/createassets', name: 'Store', element: CreateAsset },
    // { path: '/request', name: 'Request', element: null, exact: true  },
    // { path: '/request/allrequest', name: 'View Request', element: Request },
  ]

  return routes;

}

export default routers
