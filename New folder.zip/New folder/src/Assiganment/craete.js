import React from 'react';
import { Divider } from 'antd';
import { cilChevronLeft } from "@coreui/icons";
import { cilChevronRight } from "@coreui/icons";
import CIcon from "@coreui/icons-react";
import { MDBContainer, MDBRow, MDBCol, MDBInput, MDBIcon } from 'mdb-react-ui-kit';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import Craeteque from './craeteque.js';

const Create=()=>{
  const [title,setTitel]=useState('');
  const [subject,setSubject]=useState('');
  const [cls,setCls]=useState('');
  let navigate = useNavigate();

  const hadele=()=>{
    
    console.log(title);
    navigate('/Question')
  }

  const back=()=>navigate('/Assiganment')
    return(
        <>
        <CIcon
              icon={cilChevronLeft}
              size="xl"
              style={{
                marginTop: "1rem",
                marginLeft: "1rem",
                cursor: "pointer",
              }}
              onClick={back}
              />
         <h1 style={{marginLeft:"3rem", marginTop: "-3rem"}}>craete Assiganment</h1>
        <Divider style={{backgroundColor:'black'}}/>
        <MDBContainer>
        <MDBRow >
        <MDBCol size='6'>
        <MDBInput placeholder='Assiganment Title' id='form1' type='text' 
        onChange={(e)=>setTitel(e.target.value)}/>
        </MDBCol>
        <MDBCol size='6'>
        <MDBInput placeholder='Subject' id='form1' type='text'
         onChange={(e)=>setSubject(e.target.value)} />
        </MDBCol>
      </MDBRow>
      <br/>
        <MDBRow >
        <MDBCol size='6'>
        <MDBInput placeholder='class' id='form1' type='text'
         onChange={(e)=>setCls(e.target.value)} />
        </MDBCol>
        <MDBCol size='6'>
        <MDBInput placeholder='Assiganment Name' id='form1' type='text' />
        </MDBCol>
      </MDBRow>
    </MDBContainer>
     <br/>
    <MDBIcon fas icon="angle-right"/>
    <Craeteque 
    AssignmentTitle={title}/>
        <Button variant="contained" style={{marginTop:"20%",marginLeft:"90%"}} onClick={hadele}>Next <CIcon
              icon={cilChevronRight}
              size="xl"
              style={{
                marginTop: "0rem",
                marginLeft: "1rem",
                cursor: "pointer",
              }}/></Button> 

    </>
    // margin-top: 40%;
    // margin-left: 90%;
    )
}

export default Create;



// import React from 'react';
// import { MDBContainer, MDBRow, MDBCol } from 'mdb-react-ui-kit';

// export default function App() {
//   return (

//   );
// }