import React from 'react';
import { Divider } from 'antd';
import { cilChevronLeft } from "@coreui/icons";
import CIcon from "@coreui/icons-react";
import { MDBContainer, MDBRow, MDBCol, MDBInput, MDBIcon } from 'mdb-react-ui-kit';
import { Button, FormLabel } from '@mui/material';
import { useNavigate } from 'react-router-dom';

export default function Craeteque({AssignmentTitle})
{
  console.log(AssignmentTitle);
    let navigate = useNavigate();
    const back=()=>navigate('/dashboard')
    return(
        <>
         <CIcon
              icon={cilChevronLeft}
              size="xl"
              style={{
                marginTop: "1rem",
                marginLeft: "1rem",
                cursor: "pointer",
              }}
              onClick={back}
              />
         <h1 style={{marginLeft:"3rem", marginTop: "-3rem"}}>craete Question</h1>
        <Divider style={{backgroundColor:'black'}}/>
        <MDBContainer className="shadow-inner" style={{backgroundColor:'white',height:'390px'}} >
        <MDBRow> 
        <MDBCol size='1' style={{marginTop:"8px",width:"10%"}}>
        <MDBInput placeholder='No' id='form1' type='Number' />
        </MDBCol>
        <MDBCol size='12' style={{marginTop:"25px"}}>
        <MDBInput placeholder='Question No' id='form1' type='text' />
        </MDBCol>
      </MDBRow>
      <br/>
        <MDBRow >
        <MDBCol size='5'>
        <MDBInput placeholder='Option A' id='form1' type='text' />
        </MDBCol>
        <MDBCol size='5' style={{marginLeft:"12%"}}>
        <MDBInput placeholder='Option B' id='form1' type='text' />
        </MDBCol>
        </MDBRow >
        <br/>
        <MDBRow >
        <MDBCol size='5'>
        <MDBInput placeholder='Option C' id='form1' type='text' />
        </MDBCol>
        <MDBCol size='5' style={{marginLeft:"12%"}}>
        <MDBInput placeholder='Option D' id='form1' type='text' />
        </MDBCol>
        <MDBCol size='5' style={{marginTop:"25px"}} >
        <MDBInput placeholder='Answer' id='form1' type='text' />
        </MDBCol>
       </MDBRow>
       <MDBRow>
        <MDBCol size='5' style={{marginTop:"25px"}} >
        <MDBInput placeholder='Totaltest mark' id='form1' type='text' />
        </MDBCol>
       </MDBRow>
    </MDBContainer>
     <br/>
    <Button variant="contained" style={{marginTop:"10%",marginLeft:"90%"}}>Submit
    </Button> 
    </>
    )
}
